import {
  distance,
  poi,
  tripPlans,
  type Plan,
  type Place,
  type Stop,
  w,
  onAsianSide,
} from './guide';
import { infoFor } from './practical';
export type CustomPlace = Place & {
  custom: true;
  imageUrl?: string;
  hoursText?: string;
  priceText?: string;
};
export type Edits = {
  trash: string[];
  additions: Record<string, string[]>;
  custom: CustomPlace[];
};
export const emptyEdits: Edits = { trash: [], additions: {}, custom: [] };
export const initialPlans: Plan[] = [
  { ...tripPlans[0], id: '2026-10-21', date: '2026-10-21' },
  ...tripPlans.slice(2),
].map((p) => ({ ...p, stops: p.stops.map((s) => ({ ...s })) }));
// Keep opening-day constraints intact; the nearby Galata morning moves to the extra day.
initialPlans.find((p) => p.id === '2026-11-02')!.stops = [
  { id: 'saint', time: '10:00' },
  { id: 'camondo', time: '11:00' },
  { id: 'beyzade', time: '12:00' },
  { id: 'namli', time: '14:00' },
  { id: 'hamam', time: '—' },
];
initialPlans.find((p) => p.id === '2026-11-02')!.title = w(
  'Galata, sabores & hamam',
  'Galata, flavors & hamam',
  'Galata, lezzetler ve hamam',
);
initialPlans.find((p) => p.id === '2026-10-31')!.number = 10;
initialPlans.forEach((p, i) => {
  if (i > 0 && i <= 10) p.number = i;
});
const asian = onAsianSide;
export function travelMinutes(a: Place, b: Place) {
  if (a.unmapped || b.unmapped) return 0;
  const km = distance(a, b);
  if (asian(a) !== asian(b)) return Math.ceil(35 + km * 3);
  if (km > 2) return Math.ceil(15 + km * 4);
  return Math.max(3, Math.ceil(((km * 1.3) / 4.2) * 60));
}
const hhmm = (m: number) =>
  `${Math.floor(m / 60)
    .toString()
    .padStart(2, '0')}:${(m % 60).toString().padStart(2, '0')}`;
export type Planned = Plan & {
  skipped: { id: string; reason: 'closed' | 'late' }[];
  ordered: boolean;
};
export function optimizePlan(
  plan: Plan,
  edits: Edits,
  lookup: Record<string, Place> = poi,
): Planned {
  const ids = Array.from(
    new Set([
      ...plan.stops.map((s) => s.id),
      ...(edits.additions[plan.id] ?? []),
    ]),
  ).filter((id) => lookup[id] && !edits.trash.includes(id));
  const weekday = plan.date
    ? new Date(plan.date + 'T12:00:00Z').getUTCDay()
    : -1;
  const skipped: Planned['skipped'] = [],
    remaining: string[] = [];
  for (const id of ids) {
    if (infoFor(lookup[id]).closed?.includes(weekday))
      skipped.push({ id, reason: 'closed' });
    else remaining.push(id);
  }
  let current = lookup[plan.start],
    clock = plan.id === '2026-10-21' ? 17 * 60 : 9 * 60;
  const stops: Stop[] = [];
  if (plan.budget) {
    return {
      ...plan,
      stops: remaining.map((id) => ({ id, time: '—' })),
      skipped,
      ordered: false,
    };
  }
  while (remaining.length) {
    const choices = remaining.map((id) => {
      const p = lookup[id],
        info = infoFor(p),
        travel = travelMinutes(current, p),
        earliest =
          info.open ??
          (p.kind === 'food'
            ? ['dogaciyiz', 'hafiz', 'beyzade'].includes(id)
              ? 540
              : 690
            : 540);
      const arrival = clock + travel;
      const originalTime = plan.stops.find((s) => s.id === id)?.time;
      const dinner =
        p.kind === 'food' &&
        originalTime &&
        Number(originalTime.split(':')[0]) >= 18;
      const start = Math.max(arrival, earliest, dinner ? 18 * 60 : 0);
      return {
        id,
        p,
        info,
        travel,
        start,
        wait: start - arrival,
        km: distance(current, p),
      };
    });
    const feasible = choices.filter(
      (c) => !c.info.close || c.start + c.info.duration <= c.info.close,
    );
    if (!feasible.length) {
      skipped.push(...remaining.map((id) => ({ id, reason: 'late' as const })));
      break;
    }
    // A currently open nearby stop wins; wait only when no remaining stop is open yet.
    const open = feasible.filter((c) => c.wait === 0);
    const pool = open.length ? open : feasible;
    pool.sort((a, b) =>
      open.length
        ? a.km - b.km || a.travel - b.travel
        : a.start - b.start || a.km - b.km,
    );
    const chosen = pool[0];
    stops.push({
      id: chosen.id,
      time:
        chosen.p.unmapped || chosen.info.reservation ? '—' : hhmm(chosen.start),
    });
    clock = chosen.start + chosen.info.duration;
    current = chosen.p;
    remaining.splice(remaining.indexOf(chosen.id), 1);
  }
  return { ...plan, stops, skipped, ordered: true };
}
export function validateCustom(value: unknown): value is CustomPlace {
  if (!value || typeof value !== 'object') return false;
  const p = value as CustomPlace;
  return (
    typeof p.id === 'string' &&
    /^custom-[a-z0-9-]{8,64}$/.test(p.id) &&
    typeof p.name === 'string' &&
    p.name.trim().length >= 2 &&
    p.name.length <= 120 &&
    typeof p.address === 'string' &&
    p.address.length <= 300 &&
    typeof p.lat === 'number' &&
    Number.isFinite(p.lat) &&
    p.lat >= 40.6 &&
    p.lat <= 41.6 &&
    typeof p.lng === 'number' &&
    Number.isFinite(p.lng) &&
    p.lng >= 28.3 &&
    p.lng <= 29.7 &&
    ['food', 'sight', 'shop'].includes(p.kind) &&
    p.custom === true &&
    (p.kind !== 'food' ||
      (typeof p.rating === 'number' && p.rating > 4.6 && p.rating <= 5)) &&
    (!p.imageUrl ||
      (typeof p.imageUrl === 'string' &&
        p.imageUrl.length <= 2048 &&
        p.imageUrl.startsWith('https://'))) &&
    (!p.hoursText ||
      (typeof p.hoursText === 'string' && p.hoursText.length <= 250)) &&
    (!p.priceText ||
      (typeof p.priceText === 'string' && p.priceText.length <= 250)) &&
    typeof p.area === 'string' &&
    p.area.length <= 120 &&
    !!p.description &&
    ['pt', 'en', 'tr'].every(
      (l) =>
        typeof p.description[l as 'pt'] === 'string' &&
        p.description[l as 'pt'].length <= 1000,
    )
  );
}

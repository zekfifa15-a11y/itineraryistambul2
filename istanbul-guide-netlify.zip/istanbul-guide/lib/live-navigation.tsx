'use client';
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import {
  compassHeading,
  validFix,
  shouldRefreshRoute,
  type LiveFix,
} from './navigation';
type LiveNavigation = {
  enabled: boolean;
  fix?: LiveFix;
  routeFix?: LiveFix;
  heading: number | null;
  headingSource: 'phone' | 'movement' | 'none';
  error: string;
  compassError: string;
  stale: boolean;
  start: () => void;
  stop: () => void;
  enableCompass: () => Promise<void>;
};
const Context = createContext<LiveNavigation | null>(null);
export function LiveNavigationProvider({ children }: { children: ReactNode }) {
  const [enabled, setEnabled] = useState(false),
    [fix, setFix] = useState<LiveFix>(),
    [routeFix, setRouteFix] = useState<LiveFix>(),
    [sensor, setSensor] = useState<{ heading: number; at: number }>(),
    [error, setError] = useState(''),
    [compassError, setCompassError] = useState(''),
    [now, setNow] = useState(0);
  const watch = useRef<number | null>(null),
    orientationCleanup = useRef<() => void>(() => {}),
    generation = useRef(0);
  const clear = useCallback(() => {
    generation.current++;
    if (watch.current !== null) {
      navigator.geolocation.clearWatch(watch.current);
      watch.current = null;
    }
    orientationCleanup.current();
    orientationCleanup.current = () => {};
  }, []);
  const stop = useCallback(() => {
    clear();
    setEnabled(false);
    setFix(undefined);
    setRouteFix(undefined);
    setSensor(undefined);
    setError('');
    setCompassError('');
  }, [clear]);
  const start = useCallback(() => {
    if (watch.current !== null) return;
    if (!window.isSecureContext) {
      setError('secure');
      return;
    }
    if (!navigator.geolocation) {
      setError('unsupported');
      return;
    }
    setError('');
    setEnabled(true);
    setNow(Date.now());
    const run = ++generation.current;
    watch.current = navigator.geolocation.watchPosition(
      (p) => {
        if (run !== generation.current) return;
        const next: LiveFix = {
          lat: p.coords.latitude,
          lng: p.coords.longitude,
          accuracy: p.coords.accuracy,
          timestamp: p.timestamp,
          heading:
            p.coords.speed !== null &&
            p.coords.speed > 0.5 &&
            p.coords.heading !== null &&
            Number.isFinite(p.coords.heading)
              ? p.coords.heading
              : null,
        };
        if (!validFix(next)) return;
        setFix(next);
        setRouteFix((previous) =>
          shouldRefreshRoute(previous, next) ? next : previous,
        );
        setNow(Date.now());
        setError('');
      },
      (e) => {
        if (run !== generation.current) return;
        setError(
          e.code === 1 ? 'denied' : e.code === 3 ? 'timeout' : 'unavailable',
        );
        if (e.code === 1) {
          clear();
          setEnabled(false);
          setFix(undefined);
          setRouteFix(undefined);
        }
      },
      { enableHighAccuracy: true, timeout: 20000, maximumAge: 3000 },
    );
  }, [clear]);
  const enableCompass = useCallback(async () => {
    setCompassError('');
    if (!window.isSecureContext) {
      setCompassError('secure');
      return;
    }
    const Sensor =
      window.DeviceOrientationEvent as typeof DeviceOrientationEvent & {
        requestPermission?: (absolute?: boolean) => Promise<string>;
      };
    if (!Sensor) {
      setCompassError('unsupported');
      return;
    }
    const run = generation.current;
    try {
      if (
        Sensor.requestPermission &&
        (await Sensor.requestPermission(true)) !== 'granted'
      ) {
        setCompassError('denied');
        return;
      }
      if (run !== generation.current) return;
      orientationCleanup.current();
      let last = 0;
      const receive = (e: DeviceOrientationEvent) => {
        if (Date.now() - last < 200) return;
        const heading = compassHeading(e, screen.orientation?.angle ?? 0);
        if (heading !== null) {
          last = Date.now();
          setSensor({ heading, at: last });
          setCompassError('');
        }
      };
      window.addEventListener('deviceorientationabsolute', receive);
      window.addEventListener('deviceorientation', receive);
      orientationCleanup.current = () => {
        window.removeEventListener('deviceorientationabsolute', receive);
        window.removeEventListener('deviceorientation', receive);
      };
      setCompassError('waiting');
    } catch {
      setCompassError('unavailable');
    }
  }, []);
  useEffect(() => clear, [clear]);
  useEffect(() => {
    if (!enabled) return;
    const timer = setInterval(() => setNow(Date.now()), 5000);
    return () => clearInterval(timer);
  }, [enabled]);
  const stale = !!fix && now - fix.timestamp > 30000;
  const phone = sensor && now - sensor.at < 10000;
  const heading = phone
    ? sensor.heading
    : !stale && fix?.heading !== undefined
      ? fix.heading
      : null;
  const headingSource: LiveNavigation['headingSource'] = phone
    ? 'phone'
    : heading !== null
      ? 'movement'
      : 'none';
  const value = useMemo(
    () => ({
      enabled,
      fix,
      routeFix,
      heading,
      headingSource,
      error,
      compassError,
      stale,
      start,
      stop,
      enableCompass,
    }),
    [
      enabled,
      fix,
      routeFix,
      heading,
      headingSource,
      error,
      compassError,
      stale,
      start,
      stop,
      enableCompass,
    ],
  );
  return <Context.Provider value={value}>{children}</Context.Provider>;
}
export function useLiveNavigation() {
  const value = useContext(Context);
  if (!value) throw Error('Navigation provider missing');
  return value;
}

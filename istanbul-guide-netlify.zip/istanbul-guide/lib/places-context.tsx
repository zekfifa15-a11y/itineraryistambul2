'use client';
import { createContext, useContext } from 'react';
import { poi, type Place } from './guide';
export const PlacesContext = createContext<Record<string, Place>>(poi);
export const usePlaces = () => useContext(PlacesContext);

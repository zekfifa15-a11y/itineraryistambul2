import { w, type Place } from './trip';
export const extraPlaces: Place[] = [
  {
    id: 'laleli',
    name: 'Laleli Camii',
    area: 'Laleli',
    address: 'Kemal Paşa, Ordu Caddesi, Fatih',
    lat: 41.01,
    lng: 28.9567,
    kind: 'sight',
    source: 'https://mapcarta.com/fr/26241024',
    description: w(
      'Uma mesquita barroca otomana a uma curta caminhada da faculdade. Comece pelo pátio; entre apenas fora das orações.',
      'An Ottoman baroque mosque a short walk from the faculty. Start with the courtyard; enter outside prayer times.',
      'Fakülteye kısa yürüyüş mesafesinde Osmanlı barok camisi. Avludan başlayın; namaz saatleri dışında içeri girin.',
    ),
  },
  {
    id: 'valens',
    name: 'Bozdoğan Kemeri · Valens Aqueduct',
    area: 'Saraçhane',
    address: 'Kalenderhane, Atatürk Bulvarı, Fatih',
    lat: 41.015884,
    lng: 28.955925,
    kind: 'sight',
    source:
      'https://www.e-sehir.com/turkey-map/valens-aqueduct-location-map.html',
    description: w(
      'Arcos romanos monumentais vistos dos passeios e do parque ao lado. Faça fotos sem atravessar as pistas do boulevard; use as passagens de pedestres.',
      'Monumental Roman arches viewed from adjacent pavements and park. Take photos from the side; use pedestrian crossings for the boulevard.',
      'Roma su kemerini yanındaki kaldırım ve parktan görün. Fotoğrafı yol kenarından çekin; bulvarda yaya geçitlerini kullanın.',
    ),
  },
  {
    id: 'beyazit',
    name: 'Beyazıt Camii',
    area: 'Beyazıt',
    address: 'Beyazıt Meydanı, Fatih',
    lat: 41.01012,
    lng: 28.96551,
    kind: 'sight',
    source: 'https://mapcarta.com/36879600',
    description: w(
      'Mesquita imperial junto à praça de Beyazıt. Um circuito curto para apreciar o pátio e a arquitetura, sem se perder dentro dos bazares.',
      'An imperial mosque beside Beyazıt Square. A short loop for the courtyard and architecture without getting lost in the bazaars.',
      'Beyazıt Meydanı yanındaki selatin camisi. Çarşılara dalmadan avluyu ve mimariyi görmek için kısa bir tur.',
    ),
  },
];
export const extraPlans = [
  {
    id: 'u-laleli',
    title: w(
      'Laleli, pertinho da faculdade',
      'Laleli, close to the faculty',
      'Fakültenin yanı başında Laleli',
    ),
    area: 'Laleli',
    start: 'university',
    stops: [{ id: 'laleli', time: '—' }],
    end: 'university',
    budget: { walk: 15, visit: 35, buffer: 30 },
    note: w(
      'A opção mais tranquila para o primeiro intervalo. Combine o portão de encontro e comece a voltar no minuto 45. Se estiver em oração, fique no exterior.',
      'An easy first break. Agree on the meeting gate and start returning by minute 45. During prayers, stay outside.',
      'İlk ara için rahat bir seçenek. Buluşma kapısını belirleyin ve 45. dakikada dönüşe başlayın. Namaz varsa dışarıda kalın.',
    ),
  },
  {
    id: 'u-valens',
    title: w(
      'Arcos romanos de Valens',
      'Roman arches of Valens',
      'Bozdoğan’ın Roma kemerleri',
    ),
    area: 'Saraçhane',
    start: 'university',
    stops: [{ id: 'valens', time: '—' }],
    end: 'university',
    budget: { walk: 30, visit: 25, buffer: 25 },
    note: w(
      'Caminhe até o parque junto ao aqueduto. Visita externa, sem bilheteria. Comece a voltar no minuto 40; confirme o tempo de caminhada no Maps.',
      'Walk to the park beside the aqueduct. An outdoor visit with no ticket office. Start returning by minute 40; check walking time in Maps.',
      'Kemerin yanındaki parka yürüyün. Biletsiz açık alan ziyareti. 40. dakikada dönün; yürüyüş süresini Maps’ten kontrol edin.',
    ),
  },
  {
    id: 'u-beyazit',
    title: w(
      'Praça & mesquita de Beyazıt',
      'Beyazıt square & mosque',
      'Beyazıt Meydanı ve camisi',
    ),
    area: 'Beyazıt',
    start: 'university',
    stops: [{ id: 'beyazit', time: '—' }],
    end: 'university',
    budget: { walk: 25, visit: 30, buffer: 25 },
    note: w(
      'Um passeio simples pela praça e pelo pátio da mesquita. Comece a voltar no minuto 45. Deixe o Grand Bazaar para um dia sem limite de tempo.',
      'A simple walk around the square and mosque courtyard. Start returning by minute 45. Save the Grand Bazaar for a day without a time limit.',
      'Meydan ve cami avlusunda kolay bir yürüyüş. 45. dakikada dönün. Kapalıçarşı’yı zamanınızın bol olduğu güne bırakın.',
    ),
  },
];

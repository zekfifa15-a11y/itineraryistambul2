import { legsFor, type Place, type Plan } from './guide';
import { infoFor } from './practical';

export type RouteMode = 'walking' | 'transit' | 'unknown';
export type JourneyLeg = {
  id: string;
  index: number;
  from: Place;
  to: Place;
  mode: RouteMode;
};
export type RouteSection = {
  id: string;
  mode: RouteMode;
  points: Place[];
  legs: JourneyLeg[];
};

export function mapPointLabel(id: string, points: Place[]) {
  if (id === 'base') return '⌂';
  if (id === 'university') return 'U';
  if (id === 'current') return '◎';
  const index = points.findIndex((point) => point.id === id);
  return index > 0 ? String(index) : index === 0 ? 'S' : '';
}

export function sectionDepartureTime(
  plan: Plan,
  section?: Pick<RouteSection, 'points'>,
) {
  const from = section?.points[0];
  const stop = plan.stops.find((item) => item.id === from?.id);
  if (from && stop && /^\d{2}:\d{2}$/.test(stop.time)) {
    const [hour, minute] = stop.time.split(':').map(Number);
    const total = Math.min(1439, hour * 60 + minute + infoFor(from).duration);
    return `${Math.floor(total / 60)
      .toString()
      .padStart(2, '0')}:${(total % 60).toString().padStart(2, '0')}`;
  }
  // A reservation without a time cannot imply a morning departure after the visit.
  if (stop) return '';
  return plan.startTime ?? (plan.date === '2026-10-21' ? '17:00' : '09:00');
}

/** Preserve the displayed itinerary order, including the return and unknown stops. */
export function routeForPlan(
  plan: Plan,
  lookup: Record<string, Place>,
  origin: Place | undefined,
  mode: 'auto' | 'walking' | 'transit' = 'auto',
  completed?: Record<string, boolean>,
) {
  if (!origin) return { points: [], legs: [], sections: [] };
  const points = [origin];
  const ids = plan.stops.filter((s) => !completed?.[s.id]).map((s) => s.id);
  if (ids.length || origin.id !== plan.end) ids.push(plan.end);
  for (const id of ids) {
    const place = lookup[id];
    if (place && place.id !== points.at(-1)?.id) points.push(place);
  }
  const legs: JourneyLeg[] = points.slice(1).map((to, index) => {
    const from = points[index];
    const suggested =
      legsFor(
        { ...plan, start: from.id, stops: [], end: to.id },
        { ...lookup, [from.id]: from, [to.id]: to },
      )[0]?.mode || 'unknown';
    return {
      id: `${from.id}__${to.id}`,
      index,
      from,
      to,
      mode:
        suggested === 'unknown'
          ? 'unknown'
          : mode === 'auto'
            ? suggested
            : mode,
    };
  });
  const sections: RouteSection[] = [];
  for (const leg of legs) {
    const previous = sections.at(-1);
    // Public transport must be requested per leg; Google does not offer transit waypoints.
    // Limit walking chains to 20 intermediates for the supported Google Embed API.
    if (
      leg.mode === 'walking' &&
      previous?.mode === 'walking' &&
      previous.points.length < 22
    ) {
      previous.points.push(leg.to);
      previous.legs.push(leg);
    } else {
      sections.push({
        id: leg.id,
        mode: leg.mode,
        points: [leg.from, leg.to],
        legs: [leg],
      });
    }
  }
  return { points, legs, sections };
}

export function googleRouteEmbed(
  section: RouteSection,
  key: string,
  lang: string,
) {
  if (!key.trim() || section.mode === 'unknown') return undefined;
  const address = (p: Place) => `${p.lat},${p.lng}`;
  const params = new URLSearchParams({
    key: key.trim(),
    origin: address(section.points[0]),
    destination: address(section.points.at(-1)!),
    mode: section.mode,
    language: lang,
    region: 'TR',
  });
  if (section.points.length > 2)
    params.set(
      'waypoints',
      section.points
        .slice(1, -1)
        .map((p) => `${p.name}, ${p.address}, İstanbul, Türkiye`)
        .join('|'),
    );
  return `https://www.google.com/maps/embed/v1/directions?${params}`;
}

/** Mobile Maps URLs allow at most three intermediate stops. Never silently drop any. */
export function googleRouteLinks(section: RouteSection) {
  const chunks: Place[][] = [];
  for (let start = 0; start < section.points.length - 1; start += 4)
    chunks.push(section.points.slice(start, start + 5));
  return chunks.map((points) => {
    const address = (p: Place) => `${p.lat},${p.lng}`;
    const params = new URLSearchParams({
      api: '1',
      origin: address(points[0]),
      destination: address(points.at(-1)!),
      travelmode: section.mode === 'transit' ? 'transit' : 'walking',
    });
    if (points.length > 2)
      params.set('waypoints', points.slice(1, -1).map(address).join('|'));
    return { points, url: `https://www.google.com/maps/dir/?${params}` };
  });
}

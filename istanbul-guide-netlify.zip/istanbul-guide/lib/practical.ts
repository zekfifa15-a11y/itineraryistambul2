import { w, type Words, type Place } from './guide';
export type Practical = {
  hours: Words;
  price: Words;
  ticket: Words;
  duration: number;
  open?: number;
  close?: number;
  closed?: number[];
  priceKind: 'free' | 'ticket' | 'meal' | 'shopping' | 'unknown';
  source?: string;
  priceEstimated?: boolean;
  reservation?: boolean;
};
const free = w('Grátis', 'Free', 'Ücretsiz');
const noTicket = w('Sem ingresso', 'No ticket', 'Bilet yok');
const outdoor = w(
  'Espaço externo · prefira luz do dia',
  'Outdoor space · visit in daylight',
  'Açık alan · gündüz tercih edin',
);
const prayer = w(
  'Fora das orações · confirme acesso',
  'Outside prayers · check access',
  'Namaz saatleri dışında · girişi kontrol edin',
);
export const practical: Record<string, Practical> = {};
for (const id of [
  'camondo',
  'arasta',
  'gulhane',
  'grand',
  'tahta',
  'spice',
  'akaretler',
  'kadikoy',
  'uskudar',
  'salacak',
  'istiklal',
  'moda',
  'kuzguncuk',
  'balat',
  'galataport',
  'sahaf',
])
  practical[id] = {
    hours: outdoor,
    price: free,
    ticket: noTicket,
    duration: 45,
    open: 9 * 60,
    close: 19 * 60,
    priceKind: 'free',
  };
for (const id of ['blue', 'suleymaniye', 'kalender', 'sehzade', 'ortakoy'])
  practical[id] = {
    hours: prayer,
    price: free,
    ticket: noTicket,
    duration: 40,
    open: 9 * 60,
    close: 17 * 60,
    priceKind: 'free',
  };
for (const id of ['saint', 'antoine', 'iron'])
  practical[id] = {
    hours: w(
      'Acesso pode variar com missas · confirmar',
      'Access varies with services · check first',
      'Giriş ayinlere göre değişir · kontrol edin',
    ),
    price: free,
    ticket: noTicket,
    duration: 35,
    priceKind: 'free',
  };
practical.draperis = {
  hours: w(
    'Visita: confirmar com a igreja · missas seg–sáb às 08:00',
    'Visitor hours: confirm with the church · Mon–Sat Mass at 08:00',
    'Ziyaret saati: kiliseden teyit edin · Pzt–Cmt ayin 08.00',
  ),
  price: w(
    'Tarifa de visita não publicada',
    'Visitor fee not published',
    'Ziyaret ücreti yayımlanmamış',
  ),
  ticket: w(
    'Acesso sujeito à abertura e às celebrações',
    'Access depends on opening and services',
    'Giriş, açılış ve ayinlere bağlıdır',
  ),
  duration: 25,
  priceKind: 'unknown',
  source: 'https://www.istanbulofm.org/p/schedule.html',
};
practical.grand = {
  ...practical.grand,
  hours: w(
    'Seg–sáb · 09:00–19:00; domingo fechado',
    'Mon–Sat · 09:00–19:00; closed Sunday',
    'Pzt–Cmt · 09.00–19.00; pazar kapalı',
  ),
  closed: [0],
  duration: 90,
};
practical.topkapi = {
  hours: w(
    '09:00–17:00 · terça fechado',
    '09:00–17:00 · closed Tuesday',
    '09.00–17.00 · salı kapalı',
  ),
  price: w(
    '2.750 ₺ / adulto estrangeiro',
    '₺2,750 / foreign adult',
    '2.750 ₺ / yabancı yetişkin',
  ),
  ticket: w(
    'Ingresso · palácio + harém + Aya İrini',
    'Ticket · palace + harem + Hagia Irene',
    'Bilet · saray + harem + Aya İrini',
  ),
  duration: 240,
  open: 540,
  close: 1020,
  closed: [2],
  priceKind: 'ticket',
  source: 'https://www.millisaraylar.gov.tr/',
};
practical.dolma = {
  hours: w(
    '09:00–17:00 · segunda fechado',
    '09:00–17:00 · closed Monday',
    '09.00–17.00 · pazartesi kapalı',
  ),
  price: w(
    '2.000 ₺ / adulto estrangeiro',
    '₺2,000 / foreign adult',
    '2.000 ₺ / yabancı yetişkin',
  ),
  ticket: w('Ingresso combinado', 'Combined ticket', 'Kombine bilet'),
  duration: 180,
  open: 540,
  close: 1020,
  closed: [1],
  priceKind: 'ticket',
  source: 'https://www.millisaraylar.gov.tr/',
};
practical.modern = {
  hours: w(
    'Ter–dom · 10:00–18:00; sexta até 20:00',
    'Tue–Sun · 10:00–18:00; Friday until 20:00',
    'Sal–Paz · 10.00–18.00; cuma 20.00’ye kadar',
  ),
  price: w(
    '1.000 ₺ / adulto estrangeiro',
    '₺1,000 / foreign adult',
    '1.000 ₺ / yabancı yetişkin',
  ),
  ticket: w('Ingresso de museu', 'Museum ticket', 'Müze bileti'),
  duration: 120,
  open: 600,
  close: 1080,
  closed: [1],
  priceKind: 'ticket',
  source: 'https://www.istanbulmodern.org/',
};
practical.hamam = {
  hours: w(
    'Horário reservado · sessões por gênero',
    'Booked slot · separate gender sessions',
    'Rezervasyon saati · ayrı seanslar',
  ),
  price: w(
    '4.300 ₺ / ritual tradicional',
    '₺4,300 / traditional ritual',
    '4.300 ₺ / geleneksel hamam',
  ),
  ticket: w(
    'Reserva obrigatória',
    'Reservation required',
    'Rezervasyon gerekli',
  ),
  duration: 90,
  priceKind: 'ticket',
  reservation: true,
  source: 'https://kilicalipasahamami.com/',
};
practical.hagia = {
  hours: w(
    'Horário turístico: confirmar antes da visita',
    'Tourist access hours: confirm before visiting',
    'Turistik ziyaret saatini gitmeden doğrulayın',
  ),
  price: w(
    'Tarifa atual a confirmar',
    'Current price to confirm',
    'Güncel ücret doğrulanmalı',
  ),
  ticket: w(
    'Galeria turística paga',
    'Paid visitor gallery',
    'Ziyaretçi galerisi ücretli',
  ),
  duration: 90,
  priceKind: 'ticket',
  open: 540,
  close: 1140,
};
practical.cistern = {
  hours: w(
    'Confira a sessão diurna/noturna no bilhete',
    'Check daytime/evening session on ticket',
    'Bilette gündüz/gece seansını kontrol edin',
  ),
  price: w(
    'Tarifa atual a confirmar',
    'Current price to confirm',
    'Güncel ücret doğrulanmalı',
  ),
  ticket: w('Ingresso obrigatório', 'Ticket required', 'Bilet gerekli'),
  duration: 60,
  priceKind: 'ticket',
};
practical.cruise = {
  hours: w(
    'Horário e píer no voucher',
    'Time and pier on voucher',
    'Saat ve iskele kuponda',
  ),
  price: w(
    'Valor da reserva · veja o voucher',
    'Booking price · see voucher',
    'Rezervasyon bedeli · kupona bakın',
  ),
  ticket: w('Reserva do passeio', 'Tour reservation', 'Tur rezervasyonu'),
  duration: 150,
  priceKind: 'ticket',
  reservation: true,
};
practical.buyukada = {
  hours: w(
    'Conforme balsas de ida e volta',
    'According to outbound and return ferries',
    'Gidiş ve dönüş vapurlarına göre',
  ),
  price: w(
    'Ilha grátis · transporte à parte',
    'Island free · transport extra',
    'Ada ücretsiz · ulaşım ayrı',
  ),
  ticket: w('Bilhete de balsa', 'Ferry ticket', 'Vapur bileti'),
  duration: 300,
  priceKind: 'ticket',
};
practical.university = {
  hours: w(
    'Acesso conforme a faculdade',
    'Faculty access rules apply',
    'Fakülte giriş kuralları geçerli',
  ),
  price: free,
  ticket: w('Ponto de encontro', 'Meeting point', 'Buluşma noktası'),
  duration: 0,
  priceKind: 'free',
};
export function infoFor(p: Place): Practical {
  return (
    practical[p.id] ?? {
      hours: w(
        'Horário ainda não confirmado',
        'Hours not yet confirmed',
        'Saatler henüz doğrulanmadı',
      ),
      price: w(
        'Preço ainda não confirmado',
        'Price not yet confirmed',
        'Fiyat henüz doğrulanmadı',
      ),
      ticket:
        p.kind === 'food'
          ? w('Refeição por pessoa', 'Meal per person', 'Kişi başı yemek')
          : p.kind === 'shop'
            ? w('Compras à parte', 'Pay for purchases', 'Alışveriş ayrı')
            : w('Confirmar ingresso', 'Check ticket', 'Bileti kontrol edin'),
      duration: p.kind === 'food' ? 60 : 40,
      priceKind:
        p.kind === 'food' ? 'meal' : p.kind === 'shop' ? 'shopping' : 'unknown',
    }
  );
}
// Restaurant amounts are planning ranges from published listings/recent customer bills,
// not fixed menu prices or a statistically measured average. Checked 9 September 2026.
const meals: [string, string, number, number, string, string, number[]?][] = [
  [
    'fb',
    '12:00–01:00',
    720,
    1500,
    '~2.000 ₺',
    'https://restaurantguru.com/amp/FandB-CULTURE-Istanbul',
  ],
  [
    'pera-antakya',
    '12:00–00:00',
    720,
    1440,
    '1.000–2.000+ ₺',
    'https://restaurantguru.com/Pera-Antakya-Istanbul',
  ],
  [
    'tomtom',
    '13:00–22:00',
    780,
    1320,
    '400–800 ₺',
    'https://restaurantguru.com/Tomtom-Cafe-Istanbul',
    [0],
  ],
  [
    'dogaciyiz',
    '08:00–18:00',
    480,
    1080,
    '400–1.200 ₺',
    'https://restaurantguru.com/Dogaciyiz-Gourmet-Istanbul',
  ],
  [
    'beyzade',
    '08:00–01:30',
    510,
    1530,
    '400–1.200 ₺',
    'https://restaurantguru.com/Beyzade-Istanbul-10',
  ],
  [
    'mivan',
    '08:30–00:00',
    510,
    1440,
    '600–1.600 ₺',
    'https://restaurantguru.com/Mivan-Restaurant-Cafe-Istanbul',
  ],
  [
    'sahan',
    '07:00–20:00',
    420,
    1200,
    '400–600 ₺',
    'https://restaurantguru.com/Sahan-Lokantasi-Istanbul',
  ],
  [
    'patata',
    '11:00–04:00',
    660,
    1680,
    '400–1.000 ₺',
    'https://restaurantguru.com/Patata-Kumpir-Cengelkoy-Istanbul',
  ],
  [
    'cisterna-food',
    '12:00–22:30',
    720,
    1350,
    '800–1.600 ₺',
    'https://restaurantguru.com/Cisterna-Brasserie-Istanbul',
  ],
  [
    'semolina',
    '13:30–23:00',
    810,
    1380,
    '1.000–1.200 ₺',
    'https://restaurantguru.com/Semolina-Kafe-and-Restoran-Istanbul',
  ],
  [
    'hafiz',
    '08:00–01:30',
    480,
    1530,
    '100–300 ₺',
    'https://restaurantguru.com/Hafiz-Mustafa-1864-Eminonu-Istanbul',
  ],
];
for (const [id, hours, open, close, price, source, closed] of meals)
  practical[id] = {
    hours: w(
      `Diariamente · ${hours}`,
      `Daily · ${hours}`,
      `Her gün · ${hours}`,
    ),
    price: w(`${price} / pessoa`, `${price} / person`, `${price} / kişi`),
    ticket: w(
      'Sem ingresso · consumo à parte',
      'No entry ticket · pay for food',
      'Giriş bileti yok · yemek ayrıca',
    ),
    duration: id === 'hafiz' ? 35 : 65,
    open,
    close,
    closed,
    priceKind: 'meal',
    source,
    priceEstimated: true,
  };
practical.tomtom.hours = w(
  'Seg–sáb · 13:00–22:00; domingo fechado',
  'Mon–Sat · 13:00–22:00; closed Sunday',
  'Pzt–Cmt · 13.00–22.00; pazar kapalı',
);
practical.beyzade.hours = w(
  '08:00–01:30 · quarta abre 08:30',
  '08:00–01:30 · Wednesday opens 08:30',
  '08.00–01.30 · çarşamba 08.30’da açılır',
);
practical['cisterna-food'].hours = w(
  '12:00–22:30 · sex/sáb até 23:00',
  '12:00–22:30 · Fri/Sat until 23:00',
  '12.00–22.30 · cuma/cumartesi 23.00’e kadar',
);
practical.semolina.hours = w(
  '13:30–23:00 · sex/sáb até 23:30',
  '13:30–23:00 · Fri/Sat until 23:30',
  '13.30–23.00 · cuma/cumartesi 23.30’a kadar',
);
practical.hafiz.ticket = w(
  'Sobremesa / lanche · pedido pequeno',
  'Dessert / snack · small order',
  'Tatlı / atıştırmalık · küçük sipariş',
);
for (const id of ['laleli', 'beyazit'])
  practical[id] = {
    hours: prayer,
    price: free,
    ticket: noTicket,
    duration: 35,
    open: 540,
    close: 1020,
    priceKind: 'free',
  };
practical.valens = {
  hours: outdoor,
  price: free,
  ticket: noTicket,
  duration: 25,
  open: 540,
  close: 1080,
  priceKind: 'free',
};
for (const id of ['carrefour', 'macro', 'namli'])
  practical[id] = {
    hours: w(
      'Confirme o horário desta unidade no Maps',
      'Check this branch’s opening hours in Maps',
      'Bu şubenin saatini Maps’ten kontrol edin',
    ),
    price: w(
      'Produtos por unidade ou peso',
      'Products priced by item or weight',
      'Ürünler adet veya kilo fiyatıyla',
    ),
    ticket: noTicket,
    duration: 30,
    priceKind: 'shopping',
  };
practical.namli.hours = w(
  'Diariamente · 07:00–22:00',
  'Daily · 07:00–22:00',
  'Her gün · 07.00–22.00',
);
practical.namli.open = 420;
practical.namli.close = 1320;
practical.namli.source = 'https://www.namligurmeonline.com/iletisim';
practical.modern.source = 'https://bilet.istanbulmodern.org/en';
practical.hamam.source = 'https://kilicalipasahamami.com/en/reservation';
practical.hamam.hours = w(
  'Mulheres 08:00–16:00 · homens 16:45–23:30; reservar',
  'Women 08:00–16:00 · men 16:45–23:30; book ahead',
  'Kadınlar 08.00–16.00 · erkekler 16.45–23.30; rezervasyon',
);
practical.hagia.price = w(
  '25 € / adulto estrangeiro · referência',
  '€25 / foreign adult · reference',
  '25 € / yabancı yetişkin · referans',
);
practical.hagia.source = 'https://muze.gen.tr/muze-detay/ayasofya';
practical.cistern.hours = w(
  '09:00–22:00 publicado · reconfirme sessão e acesso',
  'Published 09:00–22:00 · reconfirm session and access',
  'Yayımlanan 09.00–22.00 · seans ve girişi doğrulayın',
);
practical.cistern.open = 540;
practical.cistern.close = 1320;
practical.cistern.source = 'https://kultur.istanbul/yerebatan-sarnici-muzesi/';
practical.sahaf.hours = w(
  'Sebos: horários individuais · visite de dia',
  'Bookshops: individual hours · visit by day',
  'Sahaflar: dükkâna göre saatler · gündüz gidin',
);
practical.macro.hours = w(
  'Referência 10:00–22:00 · confirme esta unidade',
  'Reference 10:00–22:00 · confirm this branch',
  'Referans 10.00–22.00 · şubeden doğrulayın',
);
practical.macro.open = 600;
practical.macro.close = 1320;
practical.macro.source =
  'https://yandex.com/maps/org/macrocenter/209762687128/';
practical.carrefour.hours = w(
  'Diariamente · 07:30–21:00',
  'Daily · 07:30–21:00',
  'Her gün · 07.30–21.00',
);
practical.carrefour.open = 450;
practical.carrefour.close = 1260;
practical.carrefour.source =
  'https://www.menu-tr.com/istanbul/beyoglu/market/carrefoursa-68';

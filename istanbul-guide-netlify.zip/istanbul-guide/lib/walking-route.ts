export type RoutePoint = { lat: number; lng: number };
export type WalkingRoute = {
  coordinates: [number, number][];
  distance: number;
  duration: number;
  legs?: {
    coordinates: [number, number][];
    distance: number;
    duration: number;
  }[];
};
const cache = new Map<string, WalkingRoute>();
let nextRequestAt = 0;
export async function getWalkingRoute(
  from: RoutePoint,
  to: RoutePoint,
  signal: AbortSignal,
): Promise<WalkingRoute> {
  return getWalkingRouteThrough([from, to], signal);
}
export async function getWalkingRouteThrough(
  points: RoutePoint[],
  signal: AbortSignal,
): Promise<WalkingRoute> {
  signal.throwIfAborted();
  if (
    points.length < 2 ||
    points.length > 22 ||
    points.some(
      (p) =>
        !Number.isFinite(p.lat) ||
        !Number.isFinite(p.lng) ||
        Math.abs(p.lat) > 90 ||
        Math.abs(p.lng) > 180,
    )
  )
    throw Error('Invalid route points');
  const key = points
    .map((p) => `${p.lat.toFixed(5)},${p.lng.toFixed(5)}`)
    .join(';');
  const cached = cache.get(key);
  if (cached) return cached;
  const slot = Math.max(Date.now(), nextRequestAt);
  nextRequestAt = slot + 1200;
  await new Promise<void>((resolve, reject) => {
    const abort = () => {
      clearTimeout(timer);
      reject(new DOMException('Aborted', 'AbortError'));
    };
    const timer = setTimeout(() => {
      signal.removeEventListener('abort', abort);
      resolve();
    }, slot - Date.now());
    if (signal.aborted) abort();
    else signal.addEventListener('abort', abort, { once: true });
  });
  const res = await fetch(
    `https://routing.openstreetmap.de/routed-foot/route/v1/driving/${points.map((p) => `${p.lng},${p.lat}`).join(';')}?overview=full&geometries=geojson&steps=true`,
    { signal: AbortSignal.any([signal, AbortSignal.timeout(15000)]) },
  );
  if (!res.ok) throw Error('Route unavailable');
  const data = (await res.json()) as {
    code: string;
    routes?: {
      distance: number;
      duration: number;
      geometry: { coordinates: [number, number][] };
      legs?: {
        distance: number;
        duration: number;
        steps: { geometry: { coordinates: [number, number][] } }[];
      }[];
    }[];
    waypoints?: { distance: number }[];
  };
  const r = data.routes?.[0];
  if (
    data.code !== 'Ok' ||
    !r ||
    !Number.isFinite(r.distance) ||
    !Number.isFinite(r.duration) ||
    !Array.isArray(r.geometry?.coordinates) ||
    r.geometry.coordinates.length < 2 ||
    data.waypoints?.length !== points.length ||
    data.waypoints.some(
      (p) => !Number.isFinite(p.distance) || p.distance > 150,
    ) ||
    (points.length > 2 && r.legs?.length !== points.length - 1)
  )
    throw Error('Route unavailable');
  const invalidGeometry = (coordinates: [number, number][]) =>
    !Array.isArray(coordinates) ||
    coordinates.length < 2 ||
    coordinates.some(
      (c) =>
        !Array.isArray(c) ||
        c.length !== 2 ||
        !c.every(Number.isFinite) ||
        Math.abs(c[0]) > 180 ||
        Math.abs(c[1]) > 90,
    );
  if (
    invalidGeometry(r.geometry.coordinates) ||
    r.distance < 0 ||
    r.duration < 0
  )
    throw Error('Invalid geometry');
  const legs = r.legs?.map((leg) => {
    if (
      !Number.isFinite(leg.distance) ||
      !Number.isFinite(leg.duration) ||
      leg.distance < 0 ||
      leg.duration < 0 ||
      !Array.isArray(leg.steps)
    )
      throw Error('Invalid route leg');
    const coordinates = leg.steps.flatMap((s) => s.geometry?.coordinates || []);
    if (invalidGeometry(coordinates)) throw Error('Invalid leg geometry');
    return { distance: leg.distance, duration: leg.duration, coordinates };
  });
  const route = {
    distance: r.distance,
    duration: r.duration,
    coordinates: r.geometry.coordinates,
    legs,
  };
  cache.set(key, route);
  if (cache.size > 80) cache.delete(cache.keys().next().value!);
  return route;
}

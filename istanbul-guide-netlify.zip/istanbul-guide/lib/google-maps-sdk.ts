export type Coordinate = { lat: number; lng: number };
export type GoogleMap = {
  fitBounds: (bounds: unknown, padding?: number) => void;
  panTo: (point: Coordinate) => void;
  setZoom: (zoom: number) => void;
  addListener: (event: string, handler: () => void) => { remove: () => void };
};
export type Overlay = {
  setMap: (map: GoogleMap | null) => void;
  setOptions: (options: Record<string, unknown>) => void;
  addListener: (event: string, handler: () => void) => { remove: () => void };
};
export type TransitStep = {
  path?: Coordinate[];
  instructions?: string;
  travelMode?: string;
  staticDurationMillis?: number;
  distanceMeters?: number;
  startLocation?: Coordinate;
  endLocation?: Coordinate;
  transitDetails?: {
    departureStop?: { name?: string; location?: Coordinate };
    arrivalStop?: { name?: string; location?: Coordinate };
    departureTime?: Date;
    arrivalTime?: Date;
    headsign?: string;
    stopCount?: number;
    transitLine?: {
      name?: string;
      shortName?: string;
      color?: string;
      vehicle?: { name?: string; vehicleType?: string };
      agencies?: { name?: string; url?: string }[];
    };
  };
};
export type GoogleRoute = {
  path?: Coordinate[];
  viewport?: unknown;
  legs?: { path?: Coordinate[]; steps?: TransitStep[] }[];
  durationMillis?: number;
  distanceMeters?: number;
  localizedValues?: {
    duration?: string;
    distance?: string;
    transitFare?: string;
  };
  warnings?: string[];
};
export type GoogleSdk = {
  Map: new (host: HTMLElement, options: Record<string, unknown>) => GoogleMap;
  Polyline: new (options: Record<string, unknown>) => Overlay;
  Marker: new (options: Record<string, unknown>) => Overlay;
  Circle: new (options: Record<string, unknown>) => Overlay;
  LatLngBounds: new () => { extend: (point: Coordinate) => void };
  SymbolPath: { CIRCLE: number; FORWARD_CLOSED_ARROW: number };
  event: { clearInstanceListeners: (object: unknown) => void };
  importLibrary: (library: string) => Promise<unknown>;
};
export type GoogleRoutesLibrary = {
  Route: {
    computeRoutes: (
      request: Record<string, unknown>,
    ) => Promise<{ routes?: GoogleRoute[] }>;
  };
};
type GoogleWindow = Window & {
  google?: { maps: GoogleSdk };
  initIstanbulGoogleMap?: () => void;
  gm_authFailure?: () => void;
};
let pending: Promise<GoogleSdk> | undefined;
const authListeners = new Set<() => void>();
export function onGoogleAuthError(listener: () => void) {
  authListeners.add(listener);
  return () => {
    authListeners.delete(listener);
  };
}

export function loadGoogleMaps(key: string, lang: string): Promise<GoogleSdk> {
  const target = window as GoogleWindow;
  if (target.google?.maps?.Map) return Promise.resolve(target.google.maps);
  if (pending) return pending;
  pending = new Promise((resolve, reject) => {
    const script = document.createElement('script');
    const timeout = window.setTimeout(() => fail(), 20000);
    const fail = () => {
      clearTimeout(timeout);
      script.remove();
      pending = undefined;
      reject(new Error('google-load'));
    };
    target.initIstanbulGoogleMap = () => {
      clearTimeout(timeout);
      if (target.google?.maps) resolve(target.google.maps);
      else fail();
    };
    target.gm_authFailure = () => {
      authListeners.forEach((listener) => listener());
      fail();
    };
    const params = new URLSearchParams({
      key,
      v: 'beta',
      loading: 'async',
      callback: 'initIstanbulGoogleMap',
      language: lang === 'pt' ? 'pt-BR' : lang,
      region: 'TR',
    });
    script.src = 'https://maps.googleapis.com/maps/api/js?' + params;
    script.async = true;
    script.referrerPolicy = 'strict-origin-when-cross-origin';
    script.onerror = fail;
    document.head.appendChild(script);
  });
  return pending;
}

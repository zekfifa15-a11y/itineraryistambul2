import type { Lang } from './guide';
import type { RouteSection } from './route-plan';
import type { GoogleRoute } from './google-maps-sdk';
export type TransitPreference =
  | 'ALL'
  | 'BUS'
  | 'TRAIN'
  | 'SUBWAY'
  | 'LIGHT_RAIL';

export function matchesTransitPreference(
  route: GoogleRoute,
  preference: TransitPreference,
) {
  if (preference === 'ALL') return true;
  return (
    route.legs?.some((leg) =>
      leg.steps?.some((step) => {
        const type =
          step.transitDetails?.transitLine?.vehicle?.vehicleType || '';
        if (preference === 'BUS') return type.includes('BUS');
        if (preference === 'SUBWAY')
          return type === 'SUBWAY' || type === 'METRO_RAIL';
        if (preference === 'LIGHT_RAIL')
          return type === 'TRAM' || type === 'LIGHT_RAIL';
        return [
          'COMMUTER_TRAIN',
          'HIGH_SPEED_TRAIN',
          'LONG_DISTANCE_TRAIN',
          'HEAVY_RAIL',
          'RAIL',
          'MONORAIL',
        ].includes(type);
      }),
    ) || false
  );
}

export function googleRouteRequest(
  section: RouteSection,
  lang: Lang,
  preference: TransitPreference,
  departure?: string,
) {
  if (section.mode === 'unknown' || section.points.length < 2) return undefined;
  const coordinate = (p: { lat: number; lng: number }) => ({
    lat: p.lat,
    lng: p.lng,
  });
  const request: Record<string, unknown> = {
    origin: coordinate(section.points[0]),
    destination: coordinate(section.points.at(-1)!),
    travelMode: section.mode === 'walking' ? 'WALKING' : 'TRANSIT',
    language: lang === 'pt' ? 'pt-BR' : lang,
    region: 'tr',
    fields: [
      'path',
      'legs',
      'durationMillis',
      'distanceMeters',
      'localizedValues',
      'viewport',
      'warnings',
    ],
  };
  if (section.mode === 'transit') {
    request.computeAlternativeRoutes = true;
    request.departureTime = departure
      ? new Date(departure + ':00+03:00')
      : new Date();
    if (preference !== 'ALL')
      request.transitPreference = { allowedTransitModes: [preference] };
  } else if (section.points.length > 2) {
    request.intermediates = section.points
      .slice(1, -1)
      .map((p) => ({ location: coordinate(p) }));
    request.optimizeWaypointOrder = false;
  }
  return request;
}

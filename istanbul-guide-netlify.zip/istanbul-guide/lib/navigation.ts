import { distance } from './guide';
export type LiveFix = {
  lat: number;
  lng: number;
  accuracy: number;
  timestamp: number;
  heading: number | null;
};
export function validFix(p: LiveFix) {
  return (
    Number.isFinite(p.lat) &&
    Number.isFinite(p.lng) &&
    Math.abs(p.lat) <= 90 &&
    Math.abs(p.lng) <= 180 &&
    Number.isFinite(p.accuracy) &&
    p.accuracy >= 0 &&
    Number.isFinite(p.timestamp)
  );
}
export function compassHeading(
  e: {
    webkitCompassHeading?: number;
    webkitCompassAccuracy?: number;
    absolute?: boolean;
    alpha: number | null;
  },
  screenAngle = 0,
) {
  if (
    typeof e.webkitCompassHeading === 'number' &&
    Number.isFinite(e.webkitCompassHeading) &&
    (e.webkitCompassAccuracy === undefined ||
      (e.webkitCompassAccuracy >= 0 && e.webkitCompassAccuracy <= 50))
  )
    return (e.webkitCompassHeading + screenAngle + 360) % 360;
  if (e.absolute && e.alpha !== null && Number.isFinite(e.alpha))
    return (360 - e.alpha + screenAngle + 360) % 360;
  return null;
}
export function shouldRefreshRoute(
  previous: LiveFix | undefined,
  next: LiveFix,
  now = Date.now(),
) {
  if (!validFix(next) || next.accuracy > 80 || now - next.timestamp > 30000)
    return false;
  if (!previous) return true;
  const moved = distance(previous, next) * 1000,
    elapsed = next.timestamp - previous.timestamp;
  return (elapsed >= 15000 && moved >= 20) || (elapsed >= 60000 && moved >= 5);
}
export function withinIstanbul(p: { lat: number; lng: number }) {
  return p.lat >= 40.6 && p.lat <= 41.6 && p.lng >= 28.3 && p.lng <= 29.7;
}

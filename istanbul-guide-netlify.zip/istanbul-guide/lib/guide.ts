import {
  places as originalPlaces,
  days as originalDays,
  w,
  distance,
  Place,
  Words,
} from './trip';
import { extraPlaces, extraPlans } from './university-extra';
export { w, distance };
export type { Place, Words, Lang } from './trip';
export const ratingThreshold = 4.6;
const mivan: Place = {
  id: 'mivan',
  name: 'Mivan Restaurant & Cafe',
  area: 'Beyazıt',
  lat: 41.0062206,
  lng: 28.9690295,
  kind: 'food',
  address: 'Emin Sinan, Piyer Loti Caddesi 34, Fatih',
  rating: 4.9,
  source:
    'https://www.google.com/maps/search/Mivan%2BRestaurant%2BCafe%2BIstanbul',
  description: w(
    'Kebab, grelhados e café. Para o intervalo da faculdade, escolha um lanche pronto e avise que precisa sair no horário.',
    'Kebab, grills and coffee. During the faculty break, choose a quick snack and explain when you need to leave.',
    'Kebap, ızgara ve kahve. Fakülte arasında hızlı bir atıştırmalık seçin ve ayrılmanız gereken saati söyleyin.',
  ),
};
export const excluded = originalPlaces.filter(
  (p) => p.kind === 'food' && (p.rating ?? 0) <= ratingThreshold,
);
const draperis: Place = {
  id: 'draperis',
  name: 'Santa Maria Draperis',
  area: 'Tomtom · İstiklal',
  lat: 41.03023,
  lng: 28.97572,
  kind: 'sight',
  address: 'Tomtom, İstiklal Caddesi 215, 34433 Beyoğlu, İstanbul',
  source: 'https://www.istanbulofm.org/p/schedule.html',
  saved: true,
  description: w(
    'Igreja católica no nº 215 da İstiklal, com entrada por uma escadaria. Uma pausa no passeio de Pera antes de seguir à Saint Anthony. Confirme o acesso para visita e respeite as missas.',
    'Catholic church at 215 İstiklal, reached by a staircase. A pause on your Pera walk before Saint Anthony. Confirm visitor access and respect services.',
    'İstiklal 215 numarada, merdivenle ulaşılan Katolik kilisesi. Sent Antuan öncesinde Pera yürüyüşünde bir mola. Ziyaret girişini teyit edin ve ayinlere saygı gösterin.',
  ),
};
export const guidePlaces: Place[] = [
  ...originalPlaces,
  mivan,
  draperis,
  ...extraPlaces,
]
  .filter(
    (p) =>
      p.id !== 'galata' &&
      p.id !== 'dukkan' &&
      p.id !== 'mero' &&
      p.id !== 'eminonu',
  )
  .filter((p) => p.kind !== 'food' || (p.rating ?? 0) > ratingThreshold)
  .map((p) => {
    const corrected: Record<string, [number, number]> = {
      patata: [41.050208, 29.053574],
      carrefour: [41.024143, 28.977489],
      'pera-antakya': [41.030989, 28.974758],
      macro: [41.027837, 28.984893],
      fb: [41.0271, 28.9742],
      beyzade: [41.023577, 28.9770972],
    };
    if (corrected[p.id])
      p = { ...p, lat: corrected[p.id][0], lng: corrected[p.id][1] };
    if (p.id === 'dogaciyiz')
      return {
        ...p,
        area: 'Cihangir',
        address: 'Akarsu Yokuşu Sokak 41A, Cihangir, Beyoğlu',
        lat: 41.030692,
        lng: 28.983035,
        source: 'https://dogaciyiz.com.tr/',
        description: w(
          'Kahvaltı em Cihangir, no endereço atual divulgado pelo próprio restaurante: Akarsu Yokuşu 41A. Depois, desça para Tophane.',
          'Breakfast in Cihangir at the restaurant’s current published address: Akarsu Yokuşu 41A. Then walk downhill to Tophane.',
          'Restoranın yayımladığı güncel adres Akarsu Yokuşu 41A’da kahvaltı. Ardından Tophane’ye yokuş aşağı yürüyün.',
        ),
      };
    if (p.id === 'sahan')
      return {
        ...p,
        lat: 41.032713,
        lng: 28.946551,
        address: 'Vodina Caddesi 184, Balat, Fatih',
        source: 'https://sahanlokantasi.eatbu.com/?lang=tr',
      };
    if (p.id === 'semolina')
      return {
        ...p,
        lat: 40.9856035,
        lng: 29.0256827,
        source: 'https://www.semolinaitalian.com/english.html',
      };
    if (p.id === 'tomtom') return { ...p, lat: 41.030944, lng: 28.978985 };
    if (p.id === 'base')
      return { ...p, name: 'Airbnb · Şair Ziya Paşa Caddesi' };
    if (p.id === 'carrefour')
      return {
        ...p,
        address: 'Kemankeş Karamustafa Paşa, Necatibey Caddesi 46/A, Beyoğlu',
      };
    return p;
  });
export const poi = Object.fromEntries(guidePlaces.map((p) => [p.id, p]));
export type Stop = { id: string; time: string };
export type Plan = {
  id: string;
  date?: string;
  startTime?: string;
  number?: number;
  title: Words;
  area: string;
  note: Words;
  start: string;
  stops: Stop[];
  end: string;
  budget?: { walk: number; visit: number; buffer: number };
};
const s = (...values: string[]) =>
  values.map((x) => {
    const [time, id] = x.split('@');
    return { time, id };
  });
const seqs: Stop[][] = [
  s('—@carrefour', '19:00@fb'),
  s('10:00@saint', '11:15@camondo', '12:00@beyzade', '19:00@fb'),
  s(
    '09:00@blue',
    '10:30@arasta',
    '12:00@cisterna-food',
    '14:00@hagia',
    '16:00@cistern',
  ),
  s('09:00@topkapi', '14:00@gulhane', '15:30@hafiz'),
  s(
    '09:30@sahaf',
    '10:30@grand',
    '13:30@suleymaniye',
    '15:00@tahta',
    '16:00@spice',
  ),
  s('09:00@dolma', '12:30@akaretler', '15:00@ortakoy', '19:00@pera-antakya'),
  s('10:00@kadikoy', '12:00@moda', '13:30@semolina'),
  s('09:30@salacak', '11:00@uskudar', '12:00@kuzguncuk', '14:00@patata'),
  s('10:00@balat', '12:30@sahan', '14:00@iron'),
  s(
    '10:00@draperis',
    '10:45@istiklal',
    '12:00@antoine',
    '13:00@tomtom',
    '19:00@pera-antakya',
  ),
  s('—@cruise'),
  s('09:30@dogaciyiz', '12:00@modern', '14:30@galataport', '16:00@macro'),
  s('—@buyukada'),
  s('10:00@namli', '—@hamam', '19:00@fb'),
  [],
];
export const tripPlans: Plan[] = originalDays.map((d, i) => ({
  id: d.date,
  date: d.date,
  number: d.number,
  title: d.title,
  area: d.area,
  note: d.description,
  start: 'base',
  stops: seqs[i],
  end: 'base',
}));
tripPlans[0].title = w(
  'Chegada & o básico',
  'Arrival & essentials',
  'Varış ve ihtiyaçlar',
);
tripPlans[1].title = w(
  'Galata, sem subir à torre',
  'Galata, without the tower',
  'Kule ziyareti olmadan Galata',
);
tripPlans[1].note = w(
  'Ruas históricas e uma manhã a pé perto do Airbnb. Confirme a abertura da Saint Pierre. Tarde livre; jantar ao voltar à base.',
  'Historic streets and a morning walk near your Airbnb. Check Saint Pierre access. Free afternoon; dinner near your base.',
  'Airbnb yakınında tarihi sokaklarda sabah yürüyüşü. Saint Pierre girişini kontrol edin. Öğleden sonra serbest; konaklama yakınında akşam yemeği.',
);
tripPlans[2].note = w(
  'Use o T1 até Sultanahmet. As visitas e o almoço ficam no mesmo bairro; entrada nas mesquitas fora das orações.',
  'Take T1 to Sultanahmet. Visits and lunch stay in one neighborhood; enter mosques outside prayer times.',
  'T1 ile Sultanahmet’e gidin. Geziler ve öğle yemeği aynı semtte; camilere namaz saatleri dışında girin.',
);
tripPlans[3].note = w(
  'Topkapı cedo; depois siga em direção a Gülhane e Eminönü, sem voltar pelo caminho. Almoce antes da sobremesa na região de Sirkeci.',
  'Topkapı early, then head toward Gülhane and Eminönü without backtracking. Have lunch around Sirkeci before dessert.',
  'Erken Topkapı, ardından geri dönmeden Gülhane ve Eminönü yönü. Tatlıdan önce Sirkeci civarında öğle yemeği yiyin.',
);
tripPlans[4].note = w(
  'Café no Airbnb. Bazar pela manhã, almoço no Mivan e depois desça pelas ruas comerciais até o Bazar das Especiarias.',
  'Breakfast at the Airbnb. Bazaar in the morning, Mivan lunch, then head downhill through shopping streets to the Spice Bazaar.',
  'Airbnb’de kahvaltı. Sabah çarşı, Mivan’da öğle yemeği; ardından alışveriş sokaklarından Mısır Çarşısı’na inin.',
);
tripPlans[6].note = w(
  'Balsa para Kadıköy, mercado e caminhada até Moda. Semolina abre às 13h30: faça um almoço tardio e volte de balsa. Mero foi retirado por ficar longe deste percurso.',
  'Ferry to Kadıköy, market and walk to Moda. Semolina opens at 13:30: have a late lunch and return by ferry. Mero was removed because it is far from this route.',
  'Kadıköy’e vapur, çarşı ve Moda’ya yürüyüş. Semolina 13.30’da açılır: geç öğle yemeği ve vapurla dönüş. Mero bu rotaya uzak olduğu için çıkarıldı.',
);
tripPlans[7].note = w(
  'Chegue de balsa a Üsküdar. Siga para o norte de ônibus até Kuzguncuk e Çengelköy; volte ao sul para a orla de Salacak. Os trechos longos não são caminhadas.',
  'Ferry to Üsküdar. Travel north by bus to Kuzguncuk and Çengelköy, then south to Salacak waterfront. Longer legs are not walks.',
  'Üsküdar’a vapur. Otobüsle kuzeye, Kuzguncuk ve Çengelköy’e; sonra güneye, Salacak sahiline dönün. Uzun etaplar yürüyüş değildir.',
);
tripPlans[8].area = 'Balat · Fener';
tripPlans[8].note = w(
  'Um único bairro por vez: T5 até Balat, almoço na Vodina Caddesi e Igreja de Ferro junto à orla. Süleymaniye fica nas opções perto da faculdade.',
  'One neighborhood at a time: T5 to Balat, lunch on Vodina Caddesi and the Iron Church by the waterfront. Süleymaniye is in the faculty options.',
  'Her seferinde tek semt: T5 ile Balat, Vodina Caddesi’nde öğle yemeği ve sahilde Demir Kilise. Süleymaniye fakülte seçeneklerinde.',
);
tripPlans[11].note = w(
  'Café em Cihangir; desça a pé para Tophane, visite o İstanbul Modern e termine no Galataport. Compras no Macrocenter antes de voltar.',
  'Breakfast in Cihangir; walk downhill to Tophane, visit İstanbul Modern and finish at Galataport. Macrocenter shopping before returning.',
  'Cihangir’de kahvaltı; Tophane’ye inip İstanbul Modern’i gezin ve Galataport’ta bitirin. Dönüş öncesi Macrocenter alışverişi.',
);
tripPlans[14].note = w(
  'Dia reservado ao check-out e ao aeroporto. O aeroporto e o voo ainda não foram informados; nenhum trajeto de transfer foi presumido.',
  'Reserved for check-out and the airport. Airport and flight details were not provided; no transfer route has been assumed.',
  'Çıkış ve havalimanına ayrılan gün. Havalimanı ve uçuş bilgileri verilmedi; transfer rotası varsayılmadı.',
);
export const universityPlans: Plan[] = [
  {
    id: 'u-kalender',
    title: w(
      'Kalenderhane, bem perto',
      'Kalenderhane, close by',
      'Yakındaki Kalenderhane',
    ),
    area: 'Vezneciler',
    start: 'university',
    stops: s('—@kalender'),
    end: 'university',
    budget: { walk: 20, visit: 35, buffer: 25 },
    note: w(
      'Visita curta à antiga igreja bizantina, hoje mesquita. É o circuito com menos deslocamento; se estiver fechada, aproveite apenas o exterior.',
      'A short visit to the former Byzantine church, now a mosque. The shortest walking option; if closed, enjoy the exterior.',
      'Eski Bizans kilisesi, bugünkü camiye kısa ziyaret. En kısa yürüyüşlü seçenek; kapalıysa dışını görün.',
    ),
  },
  {
    id: 'u-sehzade',
    title: w('Pátio da Şehzade', 'Şehzade courtyard', 'Şehzade avlusu'),
    area: 'Şehzadebaşı',
    start: 'university',
    stops: s('—@sehzade'),
    end: 'university',
    budget: { walk: 25, visit: 30, buffer: 25 },
    note: w(
      'Um passeio de arquitetura com retorno simples. Visite fora do horário de oração e combine antes o portão de encontro.',
      'An architecture walk with a simple return. Visit outside prayer times and agree on the meeting gate first.',
      'Kolay dönüşlü mimari yürüyüş. Namaz saatleri dışında gidin ve buluşma kapısını önceden belirleyin.',
    ),
  },
  {
    id: 'u-books',
    title: w('Livros & Beyazıt', 'Books & Beyazıt', 'Kitaplar ve Beyazıt'),
    area: 'Beyazıt',
    start: 'university',
    stops: s('—@sahaf'),
    end: 'university',
    budget: { walk: 30, visit: 30, buffer: 20 },
    note: w(
      'Passeie pelos sebos e pela praça. Evite entrar no Grand Bazaar durante este intervalo.',
      'Browse the bookshops and square. Avoid going into the Grand Bazaar during this break.',
      'Sahafları ve meydanı gezin. Bu arada Kapalıçarşı’ya girmeyin.',
    ),
  },
  {
    id: 'u-mivan',
    title: w(
      'Uma pausa no Mivan',
      'A Mivan food break',
      'Mivan’da yemek molası',
    ),
    area: 'Beyazıt',
    start: 'university',
    stops: s('—@mivan'),
    end: 'university',
    budget: { walk: 40, visit: 25, buffer: 15 },
    note: w(
      'Comida com nota 4,9. Peça um lanche de preparo rápido, confirme o tempo com o garçom e saia até o minuto 45. Se houver fila, escolha Kalenderhane.',
      'Food rated 4.9. Order a quick snack, check preparation time and leave by minute 45. If there is a queue, choose Kalenderhane.',
      '4,9 puanlı yemek molası. Hızlı hazırlanabilen bir şey isteyin, süreyi sorun ve 45. dakikaya kadar çıkın. Sıra varsa Kalenderhane’yi seçin.',
    ),
  },
  {
    id: 'u-view',
    title: w(
      'Vista da Süleymaniye',
      'Süleymaniye views',
      'Süleymaniye manzarası',
    ),
    area: 'Süleymaniye',
    start: 'university',
    stops: s('—@suleymaniye'),
    end: 'university',
    budget: { walk: 40, visit: 20, buffer: 20 },
    note: w(
      'A opção mais apertada. Só o pátio e a vista; escolha apenas se o Maps indicar até 20 minutos por trecho. Comece a voltar no minuto 40.',
      'The tightest option. Courtyard and views only; choose it only if Maps shows at most 20 minutes each way. Start returning at minute 40.',
      'En sıkışık seçenek. Yalnızca avlu ve manzara; Maps tek yön en fazla 20 dakika gösteriyorsa seçin. 40. dakikada dönüşe başlayın.',
    ),
  },
];
universityPlans.push(...extraPlans);
const asian = new Set([
  'uskudar',
  'kuzguncuk',
  'patata',
  'salacak',
  'kadikoy',
  'moda',
  'semolina',
  'buyukada',
]);
export type Leg = {
  id: string;
  from: string;
  to: string;
  mode: 'walking' | 'transit' | 'unknown';
  reason: Words;
};
export function onAsianSide(p: Place) {
  if (!p.id.startsWith('custom-') && p.id !== 'current') return asian.has(p.id);
  // Infer the shore from nearby curated places, not a longitude cutoff through the winding strait.
  // Transport remains a suggestion; the routing service supplies the actual path.
  const nearest = Object.values(poi)
    .filter((place) => !place.unmapped)
    .reduce(
      (best, place) =>
        !best || distance(p, place) < distance(p, best) ? place : best,
      undefined as Place | undefined,
    );
  return !!nearest && asian.has(nearest.id);
}
export function legsFor(
  plan: Plan,
  lookup: Record<string, Place> = poi,
): Leg[] {
  const ids = [plan.start, ...plan.stops.map((s) => s.id), plan.end];
  return ids.slice(1).flatMap((id, i) => {
    const a = lookup[ids[i]],
      b = lookup[id];
    if (!a || !b || a.id === b.id) return [];
    const crossing = onAsianSide(a) !== onAsianSide(b);
    const coastal = ['uskudar__kuzguncuk', 'kuzguncuk__patata'].includes(
      `${a.id}__${b.id}`,
    );
    const mode =
      a.unmapped || b.unmapped
        ? 'unknown'
        : crossing || coastal || distance(a, b) > 2
          ? 'transit'
          : 'walking';
    let reason =
      mode === 'walking'
        ? w('A pé pelas ruas', 'Walk along streets', 'Sokaklardan yürüyün')
        : w(
            'Transporte público · confira a conexão',
            'Public transport · check connection',
            'Toplu taşıma · aktarmayı kontrol edin',
          );
    if (crossing)
      reason = w(
        'Balsa + acesso ao píer · confira horários',
        'Ferry + pier access · check timetable',
        'Vapur ve iskeleye ulaşım · tarifeyi kontrol edin',
      );
    if (a.id === 'base' && ['blue', 'topkapi', 'cistern'].includes(b.id))
      reason = w(
        'Caminhe a Karaköy → T1 para Sultanahmet',
        'Walk to Karaköy → T1 to Sultanahmet',
        'Karaköy’e yürüyün → Sultanahmet yönüne T1',
      );
    if (coastal)
      reason = w(
        'Ônibus pela orla · confira sentido e parada',
        'Coastal bus · check direction and stop',
        'Sahil otobüsü · yönü ve durağı kontrol edin',
      );
    if (mode === 'unknown')
      reason = w(
        'Embarque pendente: confira o voucher',
        'Boarding point pending: check voucher',
        'Biniş yeri bekleniyor: kuponu kontrol edin',
      );
    return [{ id: `${a.id}__${b.id}`, from: a.id, to: b.id, mode, reason }];
  });
}
export function googleDirections(
  from: Place | string | undefined,
  to: Place,
  mode = 'walking',
) {
  const q = new URLSearchParams({
    api: '1',
    destination: to.id.startsWith('custom-')
      ? `${to.lat},${to.lng}`
      : to.id === 'base'
        ? `${to.address}, İstanbul, Türkiye`
        : `${to.name}, ${to.address}, İstanbul, Türkiye`,
    travelmode: mode === 'transit' ? 'transit' : 'walking',
  });
  if (from)
    q.set(
      'origin',
      typeof from === 'string'
        ? from
        : from.id.startsWith('custom-')
          ? `${from.lat},${from.lng}`
          : from.id === 'base'
            ? `${from.address}, İstanbul, Türkiye`
            : `${from.name}, ${from.address}, İstanbul, Türkiye`,
    );
  return `https://www.google.com/maps/dir/?${q}`;
}
export function googleEmbed(
  from: Place | string,
  to: Place,
  mode: string,
  lang: string,
) {
  const q = new URLSearchParams({
    saddr: typeof from === 'string' ? from : `${from.lat},${from.lng}`,
    daddr: `${to.lat},${to.lng}`,
    dirflg: mode === 'transit' ? 'r' : 'w',
    hl: lang,
    output: 'embed',
  });
  return `https://maps.google.com/maps?${q}`;
}
export function googlePlaceEmbed(to: Place, lang: string) {
  return `https://maps.google.com/maps?${new URLSearchParams({ q: to.id.startsWith('custom-') ? `${to.lat},${to.lng}` : to.kind === 'base' ? `${to.address}, İstanbul` : `${to.name}, ${to.address}, İstanbul`, z: '16', hl: lang, output: 'embed' })}`;
}

tripPlans[1].title = w(
  'Galata & Karaköy',
  'Galata & Karaköy',
  'Galata ve Karaköy',
);
tripPlans[4].note = w(
  'T1 até Beyazıt. Sebos, Grand Bazaar e Süleymaniye; depois desça até Tahtakale e o Bazar das Especiarias. Almoço livre em Beyazıt antes da mesquita.',
  'T1 to Beyazıt. Bookshops, Grand Bazaar and Süleymaniye, then downhill to Tahtakale and the Spice Bazaar. Lunch around Beyazıt before the mosque.',
  'T1 ile Beyazıt. Sahaflar, Kapalıçarşı ve Süleymaniye; ardından Tahtakale ve Mısır Çarşısı’na iniş. Camiden önce Beyazıt’ta öğle yemeği.',
);
tripPlans[7].note = w(
  'Balsa para Üsküdar e caminhada até Salacak primeiro. Volte a Üsküdar e siga de ônibus pela orla: Kuzguncuk → Çengelköy. Retorno de ônibus a Üsküdar e balsa a Karaköy.',
  'Ferry to Üsküdar and walk to Salacak first. Return to Üsküdar, then coastal bus: Kuzguncuk → Çengelköy. Return by bus to Üsküdar and ferry to Karaköy.',
  'Üsküdar’a vapur, önce Salacak’a yürüyüş. Üsküdar’a dönüp sahil otobüsüyle Kuzguncuk → Çengelköy. Dönüş otobüsle Üsküdar, vapurla Karaköy.',
);
tripPlans[10].note = w(
  'Manhã livre perto da base. Faça uma refeição antes do passeio. O horário e a rota até o embarque serão definidos pelo voucher; não há píer presumido no mapa.',
  'Free morning near your base. Eat before the trip. Your voucher determines the time and route to boarding; no pier is assumed on the map.',
  'Konaklama yakınında serbest sabah. Turdan önce yemek yiyin. Saat ve biniş rotası kupona göre; haritada iskele varsayılmadı.',
);

tripPlans[4].area = 'Beyazıt · Süleymaniye · Eminönü';
tripPlans[4].title = w(
  'Bazares & Süleymaniye',
  'Bazaars & Süleymaniye',
  'Çarşılar ve Süleymaniye',
);
tripPlans[10].area = 'Bosphorus';
tripPlans[10].title = w(
  'Seu cruzeiro no Bósforo',
  'Your Bosphorus cruise',
  'Boğaz turunuz',
);
tripPlans[11].area = 'Cihangir · Tophane · Galataport';
tripPlans[11].title = w(
  'Brunch, arte & compras',
  'Brunch, art & groceries',
  'Kahvaltı, sanat ve alışveriş',
);

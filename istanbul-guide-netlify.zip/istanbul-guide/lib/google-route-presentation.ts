import type { Coordinate, GoogleRoute, TransitStep } from './google-maps-sdk';

export const routeColors = {
  walking: '#72f0cf',
  transit: '#b28aff',
  unknown: '#a4b1bf',
};
export function stepMode(step: TransitStep) {
  if (step.transitDetails || step.travelMode === 'TRANSIT') return 'transit';
  if (step.travelMode === 'WALKING') return 'walking';
  return 'unknown';
}
export function groupRouteSteps(steps: TransitStep[]) {
  const groups: {
    mode: ReturnType<typeof stepMode>;
    steps: TransitStep[];
    index: number;
  }[] = [];
  steps.forEach((step, index) => {
    const mode = stepMode(step),
      previous = groups.at(-1);
    if (mode === 'walking' && previous?.mode === 'walking')
      previous.steps.push(step);
    else groups.push({ mode, steps: [step], index });
  });
  return groups;
}
function coordinate(...candidates: (Coordinate | undefined)[]) {
  const point = candidates.find(
    (p) => p && Number.isFinite(p.lat) && Number.isFinite(p.lng),
  );
  return point ? { lat: point.lat, lng: point.lng } : undefined;
}
function letter(index: number): string {
  return index < 26
    ? String.fromCharCode(65 + index)
    : letter(Math.floor(index / 26) - 1) + letter(index % 26);
}
export function transitStops(route: GoogleRoute) {
  let index = 0;
  return (route.legs ?? []).flatMap((leg, legIndex) =>
    (leg.steps ?? []).flatMap((step, stepIndex) => {
      if (stepMode(step) !== 'transit') return [];
      const transit = step.transitDetails;
      return [
        {
          legIndex,
          stepIndex,
          board: {
            label: letter(index++),
            name: transit?.departureStop?.name,
            time: transit?.departureTime,
            position: coordinate(
              transit?.departureStop?.location,
              step.startLocation,
              step.path?.[0],
            ),
          },
          alight: {
            label: letter(index++),
            name: transit?.arrivalStop?.name,
            time: transit?.arrivalTime,
            position: coordinate(
              transit?.arrivalStop?.location,
              step.endLocation,
              step.path?.at(-1),
            ),
          },
        },
      ];
    }),
  );
}
export type TransitStopPoint = ReturnType<typeof transitStops>[number]['board'];

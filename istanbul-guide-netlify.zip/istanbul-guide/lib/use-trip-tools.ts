'use client';
import { useEffect } from 'react';
import { guidePlaces, universityPlans, poi } from './guide';
import { initialPlans, optimizePlan, type Edits } from './planner';
type ToolContext = {
  registerTool: (
    tool: {
      name: string;
      title: string;
      description: string;
      inputSchema: object;
      annotations: object;
      execute: (input: unknown) => unknown;
    },
    options: { signal: AbortSignal },
  ) => unknown;
};
export function useTripTools(refresh: () => Promise<void>) {
  useEffect(() => {
    const context = (document as Document & { modelContext?: ToolContext })
      .modelContext;
    if (!context?.registerTool) return;
    const lifecycle = new AbortController();
    const tools = [
      {
        name: 'get_istanbul_trip',
        title: 'Read Istanbul itinerary',
        description:
          'Read the itinerary, places, faculty loops and saved checklist.',
        inputSchema: {
          type: 'object',
          properties: {},
          additionalProperties: false,
        },
        annotations: { readOnlyHint: true, untrustedContentHint: false },
        execute: async () => {
          const response = await fetch('/api/progress', { cache: 'no-store' });
          if (!response.ok) throw Error('Progress unavailable');
          const editResponse = await fetch('/api/planner', {
            cache: 'no-store',
          });
          if (!editResponse.ok) throw Error('Planner unavailable');
          const edits = (await editResponse.json()) as Edits;
          const lookup = {
            ...poi,
            ...Object.fromEntries(edits.custom.map((p) => [p.id, p])),
          };
          return {
            places: [...guidePlaces, ...edits.custom].filter(
              (p) => !edits.trash.includes(p.id),
            ),
            days: initialPlans.map((p) => optimizePlan(p, edits, lookup)),
            universityPlans: universityPlans.map((p) =>
              optimizePlan(p, edits, lookup),
            ),
            ...((await response.json()) as object),
          };
        },
      },
      {
        name: 'set_istanbul_place_visited',
        title: 'Mark an Istanbul place visited',
        description:
          'Save or undo a visit in the checklist shown in this guide.',
        inputSchema: {
          type: 'object',
          properties: { id: { type: 'string' }, done: { type: 'boolean' } },
          required: ['id', 'done'],
          additionalProperties: false,
        },
        annotations: { readOnlyHint: false, untrustedContentHint: false },
        execute: async (input: unknown) => {
          if (!input || typeof input !== 'object') throw Error('Invalid input');
          const { id, done } = input as { id: unknown; done: unknown };
          if (
            typeof id !== 'string' ||
            typeof done !== 'boolean' ||
            (Object.hasOwn(poi, id) && poi[id].kind === 'base')
          )
            throw Error('Invalid place');
          const response = await fetch('/api/progress', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, done }),
          });
          if (!response.ok) throw Error('Save failed');
          await refresh();
          return { id, done };
        },
      },
    ];
    for (const tool of tools) {
      try {
        void Promise.resolve(
          context.registerTool(tool, { signal: lifecycle.signal }),
        ).catch(() => {});
      } catch {}
    }
    return () => lifecycle.abort();
  }, [refresh]);
}

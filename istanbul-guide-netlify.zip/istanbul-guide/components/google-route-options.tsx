'use client';
import { Check, Footprints, ArrowRight, Clock, Route } from 'lucide-react';
import { w, type Lang } from '@/lib/guide';
import type { GoogleRoute } from '@/lib/google-maps-sdk';

export function GoogleRouteOptions({
  routes,
  selected,
  lang,
  onSelect,
}: {
  routes: GoogleRoute[];
  selected: number;
  lang: Lang;
  onSelect: (index: number) => void;
}) {
  const time = (date?: Date) =>
    date
      ? new Intl.DateTimeFormat(lang, {
          timeZone: 'Europe/Istanbul',
          hour: '2-digit',
          minute: '2-digit',
        }).format(date)
      : '—';
  return (
    <div className="google-alternatives">
      {routes.map((route, index) => {
        const steps = route.legs?.flatMap((leg) => leg.steps || []) || [];
        const rides = steps.flatMap((step) =>
          step.transitDetails ? [step.transitDetails] : [],
        );
        const walking = Math.ceil(
          steps
            .filter((step) => !step.transitDetails)
            .reduce(
              (total, step) => total + (step.staticDurationMillis || 0),
              0,
            ) / 60000,
        );
        const first = rides[0],
          last = rides.at(-1);
        const changes = Math.max(0, rides.length - 1);
        return (
          <button
            key={index}
            className="transport-option-card"
            aria-pressed={selected === index}
            onClick={() => onSelect(index)}
          >
            <span className="transport-option-top">
              <small>
                {
                  w(
                    `Opção ${index + 1}`,
                    `Option ${index + 1}`,
                    `Seçenek ${index + 1}`,
                  )[lang]
                }
              </small>
              {selected === index && (
                <em>
                  <Check size={15} />
                  {w('No mapa', 'On map', 'Haritada')[lang]}
                </em>
              )}
            </span>
            <strong>
              {route.localizedValues?.duration ||
                `${Math.ceil((route.durationMillis || 0) / 60000)} min`}
            </strong>
            <span className="transport-option-lines">
              {rides.length ? (
                rides.map((ride, i) => (
                  <span className="transport-service" key={i}>
                    {ride.transitLine?.vehicle?.name ||
                      w('Transporte', 'Transit', 'Ulaşım')[lang]}{' '}
                    <b>
                      {ride.transitLine?.shortName || ride.transitLine?.name}
                    </b>
                  </span>
                ))
              ) : (
                <span className="transport-service">
                  <Footprints size={16} />
                  {w('A pé', 'Walking', 'Yürüyüş')[lang]}
                </span>
              )}
            </span>
            {first && last && (
              <span className="transport-option-stations">
                {first.departureStop?.name}
                <ArrowRight size={14} />
                {last.arrivalStop?.name}
              </span>
            )}
            {rides.length > 0 && (
              <span className="transport-option-facts">
                {first && (
                  <span>
                    <Clock size={15} />
                    {w('Embarque', 'Board', 'Biniş')[lang]}{' '}
                    <b>{time(first.departureTime)}</b>
                  </span>
                )}
                {last && (
                  <span>
                    {w('Desembarque', 'Alight', 'İniş')[lang]}{' '}
                    <b>{time(last.arrivalTime)}</b>
                  </span>
                )}
                <span>
                  <Footprints size={15} />
                  {walking} min {w('a pé', 'walking', 'yürüyüş')[lang]}
                </span>
                {rides.length > 0 && (
                  <span>
                    <Route size={15} />
                    {changes
                      ? w(
                          `${changes} ${changes === 1 ? 'troca' : 'trocas'}`,
                          `${changes} ${changes === 1 ? 'transfer' : 'transfers'}`,
                          `${changes} aktarma`,
                        )[lang]
                      : w('Sem trocas', 'No transfers', 'Aktarmasız')[lang]}
                  </span>
                )}
              </span>
            )}
            <small className="transport-option-bottom">
              {route.localizedValues?.distance ||
                `${((route.distanceMeters || 0) / 1000).toFixed(1)} km`}
              {route.localizedValues?.transitFare
                ? ` · ${w('Tarifa estimada', 'Estimated fare', 'Tahmini ücret')[lang]} ${route.localizedValues.transitFare}`
                : ''}
            </small>
          </button>
        );
      })}
    </div>
  );
}

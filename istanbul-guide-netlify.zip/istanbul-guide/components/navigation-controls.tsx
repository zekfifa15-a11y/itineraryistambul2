'use client';
import { Compass, LocateFixed, Pause } from 'lucide-react';
import { useLiveNavigation } from '@/lib/live-navigation';
import { w, type Lang } from '@/lib/guide';
export function NavigationControls({
  lang,
  onStart,
  onStop,
}: {
  lang: Lang;
  onStart: () => void;
  onStop: () => void;
}) {
  const nav = useLiveNavigation();
  const errors: Record<string, Record<Lang, string>> = {
    secure: w(
      'Abra o guia por HTTPS para usar a localização e os sensores.',
      'Open the guide over HTTPS to use location and sensors.',
      'Konum ve sensörler için rehberi HTTPS üzerinden açın.',
    ),
    unsupported: w(
      'Este navegador não disponibiliza o sensor. Use o Google Maps.',
      'This browser does not provide the sensor. Use Google Maps.',
      'Tarayıcı bu sensörü desteklemiyor. Google Maps’i kullanın.',
    ),
    denied: w(
      'Permissão recusada. Habilite localização/sensores nas configurações do navegador e tente novamente.',
      'Permission denied. Enable location/sensors in browser settings and try again.',
      'İzin reddedildi. Tarayıcı ayarlarından konum/sensör iznini açıp tekrar deneyin.',
    ),
    timeout: w(
      'O GPS está demorando. Aguardando um novo sinal…',
      'GPS is taking longer. Waiting for a new fix…',
      'GPS gecikiyor. Yeni sinyal bekleniyor…',
    ),
    unavailable: w(
      'Sinal indisponível. Confira as permissões e tente ao ar livre.',
      'Signal unavailable. Check permissions and try outdoors.',
      'Sinyal yok. İzinleri kontrol edip açık havada deneyin.',
    ),
    waiting: w(
      'Aguardando bússola. Em alguns celulares este sensor não está disponível no navegador.',
      'Waiting for compass. Some phones do not expose this sensor to browsers.',
      'Pusula bekleniyor. Bazı telefonlar bu sensörü tarayıcıya açmaz.',
    ),
  };
  return (
    <div className="live-controls">
      <div className="live-actions">
        <button
          className={`button ${nav.enabled ? 'live-active' : 'subtle'}`}
          onClick={nav.enabled ? onStop : onStart}
        >
          {nav.enabled ? <Pause size={17} /> : <LocateFixed size={17} />}{' '}
          {nav.enabled
            ? w('Pausar GPS', 'Pause GPS', 'GPS’i duraklat')[lang]
            : w('Iniciar acompanhamento', 'Start following', 'Takibi başlat')[
                lang
              ]}
        </button>
        {nav.enabled && (
          <button
            className="button subtle"
            onClick={() => void nav.enableCompass()}
          >
            <Compass size={17} />
            {w('Bússola', 'Compass', 'Pusula')[lang]}
          </button>
        )}
      </div>
      {nav.enabled && (
        <output className="live-status">
          <span className={`signal-dot ${nav.stale ? 'stale' : ''}`} />
          {!nav.fix
            ? w('Buscando posição…', 'Finding position…', 'Konum aranıyor…')[
                lang
              ]
            : nav.stale
              ? w(
                  'GPS sem atualização recente',
                  'GPS has no recent update',
                  'GPS güncellemesi gecikti',
                )[lang]
              : `${w('GPS ativo', 'GPS active', 'GPS etkin')[lang]} · ±${Math.ceil(nav.fix.accuracy)} m`}
          {nav.heading !== null &&
            ` · ${Math.round(nav.heading)}° ${nav.headingSource === 'phone' ? w('celular', 'phone', 'telefon')[lang] : w('movimento', 'movement', 'hareket')[lang]}`}
        </output>
      )}
      {(nav.error || nav.compassError) && (
        <p className="navigation-hint">
          {errors[nav.error || nav.compassError]?.[lang]}
        </p>
      )}
      {nav.enabled && (
        <p className="navigation-hint">
          {
            w(
              'Mantenha a página aberta. A seta depende da bússola ou da direção de movimento informada pelo celular.',
              'Keep this page open. The arrow depends on the compass or movement heading supplied by your phone.',
              'Sayfayı açık tutun. Ok, telefonun pusula veya hareket yönü verisine bağlıdır.',
            )[lang]
          }
        </p>
      )}
    </div>
  );
}

'use client';
import { useEffect, useRef, useState } from 'react';
import type { Map as LeafletMap, LayerGroup } from 'leaflet';
import { Place, Lang, mapsUrl, byId } from '@/lib/trip';
import 'leaflet/dist/leaflet.css';
type Props = {
  places: Place[];
  active: string;
  visited: Record<string, boolean>;
  lang: Lang;
  onSelect: (id: string) => void;
  location?: { lat: number; lng: number };
  sequence: boolean;
};
export default function TripMap({
  places,
  active,
  visited,
  lang,
  onSelect,
  location,
  sequence,
}: Props) {
  const el = useRef<HTMLElement>(null);
  const map = useRef<LeafletMap | null>(null);
  const group = useRef<LayerGroup | null>(null);
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);
  const select = useRef(onSelect);
  useEffect(() => {
    select.current = onSelect;
  }, [onSelect]);
  useEffect(() => {
    let canceled = false;
    let observer: ResizeObserver | undefined;
    import('leaflet')
      .then((L) => {
        if (canceled || !el.current) return;
        map.current = L.map(el.current, {
          scrollWheelZoom: false,
          zoomControl: false,
        }).setView([41.024, 28.979], 13);
        L.control.zoom({ position: 'bottomright' }).addTo(map.current);
        const tiles = L.tileLayer(
          'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
          {
            attribution:
              '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
            maxZoom: 19,
          },
        ).addTo(map.current);
        tiles.on('tileerror', () => setFailed(true));
        tiles.on('load', () => setFailed(false));
        group.current = L.layerGroup().addTo(map.current);
        observer = new ResizeObserver(() => map.current?.invalidateSize());
        observer.observe(el.current);
        setReady(true);
      })
      .catch(() => setFailed(true));
    return () => {
      canceled = true;
      observer?.disconnect();
      map.current?.remove();
      map.current = null;
      group.current = null;
    };
  }, []);
  useEffect(() => {
    if (!ready || !map.current) return;
    let canceled = false;
    void import('leaflet').then((L) => {
      if (canceled || !map.current || !group.current) return;
      group.current.clearLayers();
      const valid = places.filter((p) => !p.unmapped);
      valid.forEach((p, i) => {
        const node = document.createElement('div');
        const title = document.createElement('strong');
        title.textContent = p.name;
        node.appendChild(title);
        const link = document.createElement('a');
        link.href = mapsUrl(p);
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        link.textContent = {
          pt: 'Ir com Google Maps ↗',
          en: 'Go with Google Maps ↗',
          tr: 'Google Maps ile git ↗',
        }[lang];
        node.appendChild(document.createElement('br'));
        node.appendChild(link);
        const marker = L.marker([p.lat, p.lng], {
          title: p.name,
          icon: L.divIcon({
            className: '',
            html: `<span class="map-pin ${p.kind === 'base' ? 'home-pin' : ''} ${visited[p.id] ? 'done-pin' : ''}">${p.kind === 'base' ? '⌂' : visited[p.id] ? '✓' : i + 1}</span>`,
            iconSize: [32, 40],
            iconAnchor: [16, 35],
          }),
        }).addTo(group.current!);
        marker.bindPopup(node);
        marker.on('click', () => select.current(p.id));
      });
      if (sequence && valid.length > 1)
        L.polyline(
          valid.map((p) => [p.lat, p.lng] as [number, number]),
          { color: '#2459d6', weight: 3, opacity: 0.45, dashArray: '6,9' },
        ).addTo(group.current);
      if (
        location &&
        location.lat > 40 &&
        location.lat < 42 &&
        location.lng > 28 &&
        location.lng < 30
      )
        L.circleMarker([location.lat, location.lng], {
          radius: 8,
          color: '#fff',
          fillColor: '#2474ef',
          fillOpacity: 1,
          weight: 3,
        })
          .addTo(group.current)
          .bindTooltip(
            { pt: 'Você está aqui', en: 'You are here', tr: 'Buradasınız' }[
              lang
            ],
          );
      if (valid.length)
        map.current.fitBounds(
          L.latLngBounds(valid.map((p) => [p.lat, p.lng] as [number, number])),
          { padding: [42, 42], maxZoom: 16, animate: false },
        );
    });
    return () => {
      canceled = true;
    };
  }, [places, ready, visited, lang, location, sequence]);
  useEffect(() => {
    if (!ready) return;
    const p = byId[active];
    if (p && !p.unmapped) map.current?.panTo([p.lat, p.lng], { animate: true });
  }, [active, ready]);
  return (
    <div className="map-surface">
      <section
        ref={el}
        className="leaflet-host"
        aria-label={
          {
            pt: 'Mapa interativo dos lugares',
            en: 'Interactive places map',
            tr: 'Yerlerin etkileşimli haritası',
          }[lang]
        }
      />
      {failed && (
        <div className="map-fallback">
          {
            {
              pt: 'Mapa indisponível. As rotas do Google Maps continuam disponíveis nos cartões.',
              en: 'Map unavailable. Google Maps directions remain available on the cards.',
              tr: 'Harita kullanılamıyor. Kartlardaki Google Maps yol tarifleri kullanılabilir.',
            }[lang]
          }
        </div>
      )}
    </div>
  );
}

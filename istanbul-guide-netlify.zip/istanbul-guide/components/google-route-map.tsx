'use client';
import { useEffect, useState } from 'react';
import { MapPin, RefreshCw } from 'lucide-react';
import { w, type Lang, type Place } from '@/lib/guide';
import type { RouteSection } from '@/lib/route-plan';
import { GoogleInteractiveMap } from './google-interactive-map';

export function GoogleRouteMap(props: {
  section?: RouteSection;
  lang: Lang;
  points: Place[];
  selected?: string;
  live: boolean;
  onSelect: (id: string) => void;
  tripDate: string;
  suggestedTime: string;
}) {
  const { section, lang } = props;
  const [key, setKey] = useState('');
  const [loading, setLoading] = useState(true);
  const [retry, setRetry] = useState(0);
  useEffect(() => {
    const controller = new AbortController();
    void fetch('/api/maps-config', {
      signal: controller.signal,
      cache: 'no-store',
    })
      .then(async (response) =>
        response.ok
          ? ((await response.json()) as { googleEmbedKey?: string })
          : null,
      )
      .catch(() => null)
      .then((config) => {
        if (controller.signal.aborted) return;
        setKey(config?.googleEmbedKey || '');
        setLoading(false);
      });
    return () => controller.abort();
  }, [retry]);
  if (!section || loading || !key)
    return (
      <div className="map-empty" aria-live="polite">
        <MapPin size={30} />
        <p>
          {!section
            ? w(
                'Adicione uma parada para ver o trajeto.',
                'Add a stop to see the route.',
                'Rotayı görmek için durak ekleyin.',
              )[lang]
            : loading
              ? w(
                  'Conectando ao Google Maps…',
                  'Connecting to Google Maps…',
                  'Google Maps’e bağlanıyor…',
                )[lang]
              : w(
                  'O mapa está temporariamente indisponível. Você ainda pode abrir o trajeto no aplicativo Google Maps abaixo.',
                  'The map is temporarily unavailable. You can still open the route in the Google Maps app below.',
                  'Harita geçici olarak kullanılamıyor. Aşağıdan rotayı Google Maps uygulamasında açabilirsiniz.',
                )[lang]}
        </p>
        {section && !loading && !key && (
          <button
            className="button subtle"
            onClick={() => {
              setLoading(true);
              setRetry((n) => n + 1);
            }}
          >
            <RefreshCw size={17} />
            {w('Tentar novamente', 'Try again', 'Tekrar dene')[lang]}
          </button>
        )}
      </div>
    );
  return (
    <div className="google-route-container">
      <GoogleInteractiveMap {...props} section={section} apiKey={key} />
    </div>
  );
}

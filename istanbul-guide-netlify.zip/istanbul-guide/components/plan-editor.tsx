'use client';
import { useEffect, useRef, useState } from 'react';
import {
  CalendarDays,
  Plus,
  Trash2,
  Undo2,
  MapPin,
  Search,
  Check,
  Ticket,
  Clock,
  Wallet,
  ExternalLink,
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Calendar } from '@/components/ui/calendar';
import { GuideSelect as NativeSelect } from '@/components/guide-select';
import { Input } from '@/components/ui/input';
import { ptBR, enGB, tr } from 'date-fns/locale';
import { w, type Lang, type Place, type Plan } from '@/lib/guide';
import { infoFor } from '@/lib/practical';
import { type Edits, type CustomPlace } from '@/lib/planner';
import type { Map as LMap, Marker } from 'leaflet';
import 'leaflet/dist/leaflet.css';
export type EditAction = {
  action: 'trash' | 'restore' | 'add' | 'create';
  id?: string;
  plan?: string;
  place?: CustomPlace;
};
export function PlaceFacts({
  place,
  lang,
  date,
}: {
  place: Place;
  lang: Lang;
  date?: string;
}) {
  const info = infoFor(place),
    custom = place as CustomPlace;
  const closed =
    !!date && info.closed?.includes(new Date(date + 'T12:00:00Z').getUTCDay());
  return (
    <div
      className={`place-facts ${place.kind === 'shop' ? 'shopping-facts' : ''}`}
    >
      <div className={`fact hours ${closed ? 'closed' : ''}`}>
        <Clock size={18} />
        <span>
          <small>
            {closed
              ? w('Fechado neste dia', 'Closed this day', 'Bu gün kapalı')[lang]
              : w('Funcionamento', 'Opening hours', 'Çalışma saatleri')[lang]}
          </small>
          <b>{custom.hoursText || info.hours[lang]}</b>
        </span>
      </div>
      <div className={`fact price ${info.priceKind}`}>
        <Wallet size={18} />
        <span>
          <small>
            {info.priceEstimated
              ? w('Estimativa / pessoa', 'Estimate / person', 'Tahmin / kişi')[
                  lang
                ]
              : w('Custo', 'Cost', 'Ücret')[lang]}
          </small>
          <b>{custom.priceText || info.price[lang]}</b>
        </span>
      </div>
      {place.kind !== 'shop' && (
        <div className="fact ticket">
          <Ticket size={18} />
          <span>
            <small>
              {
                w(
                  'Entrada / reserva',
                  'Entry / booking',
                  'Giriş / rezervasyon',
                )[lang]
              }
            </small>
            <b>{info.ticket[lang]}</b>
          </span>
        </div>
      )}
      {info.source && (
        <a
          className="fact-link"
          href={info.source}
          target="_blank"
          rel="noreferrer"
        >
          {
            w(
              'Ver horário e preço atual',
              'Check current hours & price',
              'Güncel saat ve ücreti gör',
            )[lang]
          }
          <ExternalLink size={14} />
        </a>
      )}
    </div>
  );
}
function PinPicker({
  value,
  onChange,
  lang,
}: {
  value?: { lat: number; lng: number };
  onChange: (p: { lat: number; lng: number }) => void;
  lang: Lang;
}) {
  const host = useRef<HTMLDivElement>(null),
    map = useRef<LMap | null>(null),
    marker = useRef<Marker | null>(null),
    callback = useRef(onChange);
  useEffect(() => {
    callback.current = onChange;
  }, [onChange]);
  useEffect(() => {
    let disposed = false;
    void import('leaflet').then((L) => {
      if (disposed || !host.current) return;
      const m = L.map(host.current, { scrollWheelZoom: false }).setView(
        [41.026, 28.977],
        14,
      );
      map.current = m;
      L.tileLayer(
        'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
        {
          attribution:
            '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> © CARTO',
          maxZoom: 19,
        },
      ).addTo(m);
      m.on('click', (e) => {
        if (
          e.latlng.lat >= 40.6 &&
          e.latlng.lat <= 41.6 &&
          e.latlng.lng >= 28.3 &&
          e.latlng.lng <= 29.7
        )
          callback.current({ lat: e.latlng.lat, lng: e.latlng.lng });
      });
      setTimeout(() => m.invalidateSize(), 150);
    });
    return () => {
      disposed = true;
      map.current?.remove();
      map.current = null;
    };
  }, []);
  useEffect(() => {
    let disposed = false;
    void import('leaflet').then((L) => {
      if (disposed || !value || !map.current) return;
      marker.current?.remove();
      marker.current = L.marker([value.lat, value.lng], {
        icon: L.divIcon({
          className: 'journey-pin-wrap',
          html: '<span class="journey-pin selected">+</span>',
          iconSize: [36, 36],
        }),
      }).addTo(map.current);
      map.current.panTo([value.lat, value.lng]);
    });
    return () => {
      disposed = true;
    };
  }, [value]);
  return (
    <div>
      <p className="secondary">
        {
          w(
            'Toque no local exato no mapa. Você também pode colar as coordenadas abaixo.',
            'Tap the exact place on the map. You can also paste coordinates below.',
            'Haritada tam konuma dokunun. Koordinatları aşağıya da yapıştırabilirsiniz.',
          )[lang]
        }
      </p>
      <div ref={host} className="pin-picker" />
    </div>
  );
}
export function PlanEditor({
  lang,
  plans,
  day,
  onDay,
  edits,
  places,
  save,
  busy,
  ready,
}: {
  lang: Lang;
  plans: Plan[];
  day: number;
  onDay: (index: number) => void;
  edits: Edits;
  places: Place[];
  save: (action: EditAction) => Promise<boolean>;
  busy: boolean;
  ready: boolean;
}) {
  const [modal, setModal] = useState<'calendar' | 'add' | 'trash' | null>(null),
    [mode, setMode] = useState('existing'),
    [query, setQuery] = useState(''),
    [name, setName] = useState(''),
    [address, setAddress] = useState(''),
    [kind, setKind] = useState('sight'),
    [rating, setRating] = useState(''),
    [photo, setPhoto] = useState(''),
    [hours, setHours] = useState(''),
    [price, setPrice] = useState(''),
    [pin, setPin] = useState<{ lat: number; lng: number }>(),
    [coordinate, setCoordinate] = useState(''),
    [formError, setFormError] = useState('');
  const selected = plans[day],
    currentIds = new Set(selected.stops.map((s) => s.id));
  const available = places.filter(
    (p) =>
      p.kind !== 'base' &&
      (p.name + ' ' + p.area).toLowerCase().includes(query.toLowerCase()),
  );
  function parseCoordinate(v: string) {
    setCoordinate(v);
    const match =
      v.match(/!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/) ||
      v.match(/^\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*$/);
    if (
      match &&
      Number(match[1]) >= 40.6 &&
      Number(match[1]) <= 41.6 &&
      Number(match[2]) >= 28.3 &&
      Number(match[2]) <= 29.7
    )
      setPin({ lat: Number(match[1]), lng: Number(match[2]) });
    else setPin(undefined);
  }
  async function create() {
    setFormError('');
    if (
      name.trim().length < 2 ||
      !pin ||
      pin.lat < 40.6 ||
      pin.lat > 41.6 ||
      pin.lng < 28.3 ||
      pin.lng > 29.7
    ) {
      setFormError(
        w(
          'Informe um nome e marque a localização em Istambul.',
          'Enter a name and mark the location in Istanbul.',
          'Adı girin ve İstanbul’daki konumu işaretleyin.',
        )[lang],
      );
      return;
    }
    if (kind === 'food' && (!(Number(rating) > 4.6) || Number(rating) > 5)) {
      setFormError(
        w(
          'Informe a nota Google acima de 4,6 para o restaurante.',
          'Enter a Google rating above 4.6 for the restaurant.',
          'Restoran için 4,6 üzerindeki Google puanını girin.',
        )[lang],
      );
      return;
    }
    if (photo && !photo.startsWith('https://')) {
      setFormError(
        w(
          'A foto precisa de um link HTTPS.',
          'Photo needs an HTTPS link.',
          'Fotoğraf HTTPS bağlantısı gerektirir.',
        )[lang],
      );
      return;
    }
    const place: CustomPlace = {
      id: 'custom-' + crypto.randomUUID(),
      custom: true,
      name: name.trim(),
      address: address.trim(),
      lat: pin.lat,
      lng: pin.lng,
      kind: kind as Place['kind'],
      area: 'İstanbul',
      description: w(
        'Adicionado por vocês. Confirme os detalhes antes de sair.',
        'Added by you. Confirm details before setting out.',
        'Sizin eklediğiniz yer. Çıkmadan ayrıntıları doğrulayın.',
      ),
      rating: kind === 'food' ? Number(rating) : undefined,
      imageUrl: photo || undefined,
      hoursText: hours || undefined,
      priceText: price || undefined,
    };
    if (await save({ action: 'create', plan: selected.id, place })) {
      setModal(null);
      setName('');
      setAddress('');
      setPin(undefined);
      setCoordinate('');
      setPhoto('');
      setHours('');
      setPrice('');
    } else
      setFormError(
        w(
          'Não foi possível salvar. Seus dados continuam aqui; tente novamente.',
          'Could not save. Your details are still here; try again.',
          'Kaydedilemedi. Bilgileriniz burada; tekrar deneyin.',
        )[lang],
      );
  }
  return (
    <>
      <div className="planner-toolbar">
        <button
          className="button calendar-button"
          onClick={() => setModal('calendar')}
        >
          <CalendarDays size={19} />
          {w('Calendário', 'Calendar', 'Takvim')[lang]}
        </button>
        <button
          disabled={!ready || busy}
          className="button add-button"
          onClick={() => setModal('add')}
        >
          <Plus size={19} />
          {w('Adicionar lugar', 'Add place', 'Yer ekle')[lang]}
        </button>
        <button
          disabled={!ready}
          className="button trash-button"
          onClick={() => setModal('trash')}
        >
          <Trash2 size={18} />
          {w('Lixeira', 'Trash', 'Çöp kutusu')[lang]}
          {edits.trash.length > 0 && <b>{edits.trash.length}</b>}
        </button>
      </div>
      <Dialog
        open={modal !== null}
        onOpenChange={(open) => {
          if (!open) setModal(null);
        }}
      >
        <DialogContent
          className={`planner-dialog ${modal === 'calendar' ? 'calendar-dialog' : ''}`}
        >
          <DialogTitle>
            {modal === 'calendar'
              ? w(
                  'Escolha o dia da viagem',
                  'Choose your travel day',
                  'Gezi gününü seçin',
                )[lang]
              : modal === 'trash'
                ? w(
                    'Lugares na lixeira',
                    'Places in trash',
                    'Çöp kutusundaki yerler',
                  )[lang]
                : w('Adicionar ao dia', 'Add to this day', 'Bu güne ekle')[
                    lang
                  ]}
          </DialogTitle>
          <DialogDescription>
            {modal === 'calendar'
              ? '21.10 — 03.11.2026'
              : modal === 'trash'
                ? w(
                    'Restaure um lugar quando quiser. Seu check de visita é preservado.',
                    'Restore a place any time. Your visit check is preserved.',
                    'İstediğiniz zaman geri yükleyin. Ziyaret işareti korunur.',
                  )[lang]
                : w(
                    'A ordem e os trajetos do dia serão atualizados automaticamente.',
                    'The day’s order and routes update automatically.',
                    'Günün sırası ve rotaları otomatik güncellenir.',
                  )[lang]}
          </DialogDescription>
          {modal === 'add' && (
            <p className="notice">
              {selected.date!.slice(8)}/{selected.date!.slice(5, 7)} ·{' '}
              {selected.title[lang]}
            </p>
          )}
          {modal === 'calendar' && (
            <>
              <Calendar
                mode="single"
                className="trip-calendar"
                locale={{ pt: ptBR, en: enGB, tr }[lang]}
                defaultMonth={new Date(selected.date! + 'T12:00:00')}
                selected={new Date(selected.date! + 'T12:00:00')}
                startMonth={new Date(2026, 9, 1)}
                endMonth={new Date(2026, 10, 30)}
                disabled={(date) =>
                  date < new Date(2026, 9, 21) ||
                  date > new Date(2026, 10, 3, 23, 59)
                }
                onSelect={(date) => {
                  if (!date) return;
                  const str = `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')}`;
                  const i = plans.findIndex((p) => p.date === str);
                  if (i >= 0) {
                    onDay(i);
                    setModal(null);
                  }
                }}
              />
              <div className="calendar-agenda">
                {plans.map((p, i) => (
                  <button
                    key={p.id}
                    className={i === day ? 'active' : ''}
                    onClick={() => {
                      onDay(i);
                      setModal(null);
                    }}
                  >
                    <b>
                      {p.date!.slice(8)}/{p.date!.slice(5, 7)}
                    </b>
                    <span>
                      {p.title[lang]}
                      <small>
                        {p.stops.length} {w('paradas', 'stops', 'durak')[lang]}
                      </small>
                    </span>
                  </button>
                ))}
              </div>
            </>
          )}
          {modal === 'trash' && (
            <div className="editor-results">
              {edits.trash.length === 0 ? (
                <p className="notice">
                  {
                    w(
                      'Sua lixeira está vazia.',
                      'Your trash is empty.',
                      'Çöp kutunuz boş.',
                    )[lang]
                  }
                </p>
              ) : (
                edits.trash.map((id) => {
                  const p = places.find((x) => x.id === id);
                  return (
                    p && (
                      <div className="editor-result" key={id}>
                        <span>
                          <strong>{p.name}</strong>
                          <small>{p.area}</small>
                        </span>
                        <button
                          disabled={busy}
                          className="button"
                          onClick={() => void save({ action: 'restore', id })}
                        >
                          <Undo2 size={17} />
                          {w('Restaurar', 'Restore', 'Geri yükle')[lang]}
                        </button>
                      </div>
                    )
                  );
                })
              )}
            </div>
          )}
          {modal === 'add' && (
            <>
              <NativeSelect
                value={mode}
                onChange={(e) => setMode(e.target.value)}
                aria-label={
                  w('Tipo de inclusão', 'Add method', 'Ekleme yöntemi')[lang]
                }
              >
                <option value="existing">
                  {
                    w('Escolher do guia', 'Choose from guide', 'Rehberden seç')[
                      lang
                    ]
                  }
                </option>
                <option value="new">
                  {
                    w(
                      'Criar um novo lugar',
                      'Create a new place',
                      'Yeni yer oluştur',
                    )[lang]
                  }
                </option>
              </NativeSelect>
              {mode === 'existing' ? (
                <>
                  <div className="search-with-icon">
                    <Search size={18} />
                    <Input
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      placeholder={
                        w('Nome ou bairro', 'Name or area', 'Ad veya semt')[
                          lang
                        ]
                      }
                    />
                  </div>
                  <div className="editor-results">
                    {available.map((p) => (
                      <div key={p.id} className="editor-result">
                        <span>
                          <strong>{p.name}</strong>
                          <small>{p.area}</small>
                        </span>
                        <button
                          className="button"
                          disabled={
                            busy ||
                            (currentIds.has(p.id) &&
                              !edits.trash.includes(p.id))
                          }
                          onClick={() =>
                            void save({
                              action: 'add',
                              id: p.id,
                              plan: selected.id,
                            })
                          }
                        >
                          {currentIds.has(p.id) &&
                          !edits.trash.includes(p.id) ? (
                            <Check size={18} />
                          ) : (
                            <Plus size={18} />
                          )}
                          <span>
                            {currentIds.has(p.id) && !edits.trash.includes(p.id)
                              ? w('No dia', 'In this day', 'Bu günde')[lang]
                              : w('Adicionar', 'Add', 'Ekle')[lang]}
                          </span>
                        </button>
                      </div>
                    ))}
                  </div>
                </>
              ) : (
                <div className="custom-form">
                  <label>
                    {w('Nome do lugar', 'Place name', 'Yer adı')[lang]}
                    <Input
                      value={name}
                      maxLength={120}
                      onChange={(e) => setName(e.target.value)}
                    />
                  </label>
                  <label>
                    {w('Endereço', 'Address', 'Adres')[lang]}
                    <Input
                      value={address}
                      maxLength={300}
                      onChange={(e) => setAddress(e.target.value)}
                    />
                  </label>
                  <NativeSelect
                    value={kind}
                    onChange={(e) => setKind(e.target.value)}
                    aria-label={w('Categoria', 'Category', 'Kategori')[lang]}
                  >
                    <option value="sight">
                      {w('Atração', 'Attraction', 'Gezilecek yer')[lang]}
                    </option>
                    <option value="food">
                      {w('Restaurante', 'Restaurant', 'Restoran')[lang]}
                    </option>
                    <option value="shop">
                      {
                        w('Mercado / loja', 'Market / shop', 'Market / mağaza')[
                          lang
                        ]
                      }
                    </option>
                  </NativeSelect>
                  {kind === 'food' && (
                    <label htmlFor="custom-rating">
                      Google · &gt; 4.6
                      <Input
                        id="custom-rating"
                        type="number"
                        min="4.7"
                        max="5"
                        step="0.1"
                        value={rating}
                        onChange={(e) => setRating(e.target.value)}
                      />
                    </label>
                  )}
                  <PinPicker
                    lang={lang}
                    value={pin}
                    onChange={(p) => {
                      setPin(p);
                      setCoordinate(`${p.lat.toFixed(6)}, ${p.lng.toFixed(6)}`);
                    }}
                  />
                  <label>
                    {
                      w(
                        'Coordenadas ou link completo do Google Maps',
                        'Coordinates or full Google Maps link',
                        'Koordinatlar veya tam Google Maps bağlantısı',
                      )[lang]
                    }
                    <Input
                      value={coordinate}
                      onChange={(e) => parseCoordinate(e.target.value)}
                      placeholder="41.026000, 28.977000"
                    />
                  </label>
                  {pin && (
                    <span className="pin-confirmed">
                      <MapPin size={16} />
                      {
                        w(
                          'Localização marcada',
                          'Location marked',
                          'Konum işaretlendi',
                        )[lang]
                      }
                    </span>
                  )}
                  <label>
                    {
                      w(
                        'Foto do lugar · link HTTPS (opcional)',
                        'Place photo · HTTPS link (optional)',
                        'Yer fotoğrafı · HTTPS bağlantısı (isteğe bağlı)',
                      )[lang]
                    }
                    <Input
                      value={photo}
                      onChange={(e) => setPhoto(e.target.value)}
                    />
                  </label>
                  <div className="form-columns">
                    <label>
                      {
                        w(
                          'Horário (opcional)',
                          'Hours (optional)',
                          'Saatler (isteğe bağlı)',
                        )[lang]
                      }
                      <Input
                        value={hours}
                        onChange={(e) => setHours(e.target.value)}
                      />
                    </label>
                    <label>
                      {
                        w(
                          'Preço / pessoa (opcional)',
                          'Price / person (optional)',
                          'Fiyat / kişi (isteğe bağlı)',
                        )[lang]
                      }
                      <Input
                        value={price}
                        onChange={(e) => setPrice(e.target.value)}
                      />
                    </label>
                  </div>
                  {formError && <p className="error-banner">{formError}</p>}
                  <button
                    className="button primary"
                    disabled={busy}
                    onClick={() => void create()}
                  >
                    <Plus size={18} />
                    {
                      w(
                        'Adicionar e atualizar rota',
                        'Add and update route',
                        'Ekle ve rotayı güncelle',
                      )[lang]
                    }
                  </button>
                </div>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

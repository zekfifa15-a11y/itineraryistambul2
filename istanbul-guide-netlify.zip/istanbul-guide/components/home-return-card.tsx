'use client';
import { Home, ArrowRight, LocateFixed, Map, ArrowUpRight } from 'lucide-react';
import { googleDirections, w, type Lang, type Place } from '@/lib/guide';
import { usePlaces } from '@/lib/places-context';

export function HomeReturnCard({
  from,
  lang,
  afterFaculty,
  onShow,
}: {
  from?: Place;
  lang: Lang;
  afterFaculty?: boolean;
  onShow?: (from: string) => void;
}) {
  const poi = usePlaces();
  return (
    <section
      className="home-return-card"
      aria-label={
        w('Voltar ao Airbnb', 'Return to Airbnb', 'Airbnb’ye dön')[lang]
      }
    >
      <div className="home-return-icon">
        <Home size={25} />
      </div>
      <div className="home-return-content">
        <small>
          {afterFaculty
            ? w(
                'DEPOIS DE BUSCAR A ZEYNEP',
                'AFTER MEETING ZEYNEP',
                'ZEYNEP’İ ALDIKTAN SONRA',
              )[lang]
            : w('FINAL DO DIA', 'END OF THE DAY', 'GÜNÜN SONU')[lang]}
        </small>
        <h3>
          {
            w('De volta ao Airbnb', 'Back to the Airbnb', 'Airbnb’ye dönüş')[
              lang
            ]
          }
        </h3>
        <p>
          {from && from.id !== 'base' ? (
            <>
              {from.name} <ArrowRight size={14} /> Airbnb
            </>
          ) : (
            w(
              'Volte de onde estiver, quando encerrar o passeio.',
              'Head back from wherever you are when your outing ends.',
              'Geziniz bitince bulunduğunuz yerden dönün.',
            )[lang]
          )}
        </p>
        <div className="home-return-actions">
          {from && !from.unmapped && from.id !== 'base' && onShow && (
            <button
              className="button home-primary"
              onClick={() => onShow(from.id)}
            >
              <Map size={18} />
              {
                w(
                  'Ver caminho de volta',
                  'View the return route',
                  'Dönüş rotasını gör',
                )[lang]
              }
            </button>
          )}
          <a
            className="button subtle"
            href={googleDirections(undefined, poi.base, 'transit')}
            target="_blank"
            rel="noreferrer"
          >
            <LocateFixed size={18} />
            {
              w(
                'Voltar de onde estou',
                'Return from my location',
                'Konumumdan dön',
              )[lang]
            }
            <ArrowUpRight size={16} />
          </a>
        </div>
        {afterFaculty && (
          <small className="home-return-note">
            {
              w(
                'Esse trajeto é feito depois dos 80 minutos na faculdade.',
                'Take this route after the 80-minute faculty outing.',
                'Bu rota, fakültedeki 80 dakikalık geziden sonradır.',
              )[lang]
            }
          </small>
        )}
      </div>
    </section>
  );
}

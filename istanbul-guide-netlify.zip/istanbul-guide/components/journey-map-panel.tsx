'use client';
import { useMemo, useState } from 'react';
import {
  Map,
  Route,
  ArrowUpRight,
  ArrowRight,
  Footprints,
  TramFront,
  Check,
} from 'lucide-react';
import { GuideSelect } from './guide-select';
import { GoogleRouteMap } from './google-route-map';
import { NavigationControls } from './navigation-controls';
import { HomeReturnCard } from './home-return-card';
import { usePlaces } from '@/lib/places-context';
import { useLiveNavigation } from '@/lib/live-navigation';
import { w, type Lang, type Plan, type Leg, type Place } from '@/lib/guide';
import {
  routeForPlan,
  googleRouteLinks,
  mapPointLabel,
  sectionDepartureTime,
} from '@/lib/route-plan';
import { withinIstanbul } from '@/lib/navigation';

export default function MapPanel({
  plan,
  leg,
  lang,
  visited,
  onSelect,
  tripDate,
  onReturnHome,
}: {
  plan: Plan;
  leg?: Leg;
  lang: Lang;
  visited: Record<string, boolean>;
  onSelect: (id: string) => void;
  tripDate: string;
  onReturnHome: (from: string) => void;
}) {
  const poi = usePlaces();
  const nav = useLiveNavigation();
  const [origin, setOrigin] = useState(nav.enabled ? 'current' : 'planned');
  const [mode, setMode] = useState<'auto' | 'walking' | 'transit'>('auto');
  const start = useMemo(() => {
    if (origin === 'current') {
      if (!nav.enabled || !nav.routeFix) return undefined;
      return {
        ...poi.base,
        id: 'current',
        name: w('Minha localização', 'My location', 'Konumum')[lang],
        ...nav.routeFix,
      } as Place;
    }
    return poi[origin === 'planned' ? plan.start : origin];
  }, [origin, nav.enabled, nav.routeFix, poi, plan.start, lang]);
  const completed = origin === 'current' ? visited : undefined;
  const route = useMemo(
    () => routeForPlan(plan, poi, start, mode, completed),
    [plan, poi, start, mode, completed],
  );
  const active = route.legs.find((l) => l.to.id === leg?.to) || route.legs[0];
  const section = route.sections.find((s) =>
    s.legs.some((l) => l.id === active?.id),
  );
  const links =
    section && section.mode !== 'unknown' ? googleRouteLinks(section) : [];
  const locate = () => {
    nav.start();
    setOrigin('current');
  };
  const paused =
    origin === 'current' &&
    (!nav.enabled || nav.stale || !nav.fix || nav.fix.accuracy > 80);
  return (
    <section
      className="map-panel"
      aria-label={w('Mapa do roteiro', 'Itinerary map', 'Gezi haritası')[lang]}
    >
      <div className="map-heading">
        <span className="eyebrow">
          <Map size={16} />
          {w('SEU CAMINHO', 'YOUR WAY', 'ROTANIZ')[lang]}
        </span>
      </div>
      <div className="google-provider-label">
        <span className="google-letter">G</span>
        <b>Google Maps</b>
        <span>
          {
            w(
              'Paradas numeradas · rotas reais',
              'Numbered stops · real routes',
              'Numaralı duraklar · gerçek rotalar',
            )[lang]
          }
        </span>
      </div>
      <div className="route-addresses">
        <div>
          <span className="point start" />
          <div>
            <small>{w('Saída', 'Start', 'Başlangıç')[lang]}</small>
            <b>
              {origin === 'current'
                ? w('Minha localização', 'My location', 'Konumum')[lang]
                : start?.name}
            </b>
          </div>
        </div>
        <div>
          <span className="point end" />
          <div>
            <small>
              {
                w(
                  'Retorno após as paradas',
                  'Return after all stops',
                  'Duraklardan sonra dönüş',
                )[lang]
              }
            </small>
            <b>{poi[plan.end]?.name}</b>
          </div>
        </div>
      </div>
      <div className="route-preferences">
        <label>
          <span>
            {
              w(
                'De onde vamos sair?',
                'Where do we start?',
                'Nereden başlayalım?',
              )[lang]
            }
          </span>
          <GuideSelect
            value={origin}
            aria-label={
              w('Local de saída', 'Starting location', 'Başlangıç konumu')[lang]
            }
            onChange={(e) =>
              e.target.value === 'current'
                ? locate()
                : setOrigin(e.target.value)
            }
          >
            <option value="planned">
              {
                w('Saída do roteiro', 'Itinerary origin', 'Gezi başlangıcı')[
                  lang
                ]
              }
            </option>
            <option value="base">Airbnb</option>
            <option value="university">
              {
                w(
                  'Faculdade da Zeynep',
                  'Zeynep’s faculty',
                  'Zeynep’in fakültesi',
                )[lang]
              }
            </option>
            <option value="current">
              {w('Minha localização', 'My location', 'Konumum')[lang]}
            </option>
          </GuideSelect>
        </label>
        <label>
          <span>
            {w('Como vamos?', 'How do we travel?', 'Nasıl gidelim?')[lang]}
          </span>
          <GuideSelect
            value={mode}
            aria-label={w('Transporte', 'Transport', 'Ulaşım')[lang]}
            onChange={(e) => setMode(e.target.value as typeof mode)}
          >
            <option value="auto">
              {
                w(
                  'Sugestão por trecho',
                  'Suggested for each leg',
                  'Her etap için öneri',
                )[lang]
              }
            </option>
            <option value="walking">
              {w('A pé', 'Walking', 'Yürüyüş')[lang]}
            </option>
            <option value="transit">
              {
                w('Transporte público', 'Public transport', 'Toplu taşıma')[
                  lang
                ]
              }
            </option>
          </GuideSelect>
        </label>
      </div>
      <NavigationControls
        lang={lang}
        onStart={locate}
        onStop={() => {
          nav.stop();
          if (origin === 'current') setOrigin('planned');
        }}
      />
      {start && !withinIstanbul(start) ? (
        <div className="map-empty">
          <p>
            {
              w(
                'Você está fora de Istambul. Escolha Airbnb ou faculdade como saída para planejar este passeio.',
                'You are outside Istanbul. Choose Airbnb or faculty as your origin to plan this trip.',
                'İstanbul dışındasınız. Bu geziyi planlamak için başlangıç olarak Airbnb veya fakülteyi seçin.',
              )[lang]
            }
          </p>
        </div>
      ) : paused ? (
        <div className="map-empty">
          <p>
            {
              w(
                'Aguardando uma posição recente e precisa para atualizar o Google Maps.',
                'Waiting for a recent, accurate position to update Google Maps.',
                'Google Maps’i güncellemek için güncel ve doğru konum bekleniyor.',
              )[lang]
            }
          </p>
        </div>
      ) : section?.mode === 'unknown' ? (
        <div className="map-empty">
          <h3>
            {
              w(
                'Embarque a confirmar',
                'Boarding to confirm',
                'Biniş yeri doğrulanacak',
              )[lang]
            }
          </h3>
          <p>
            {
              w(
                'Confira o local e o horário no voucher do cruzeiro.',
                'Check the location and time on your cruise voucher.',
                'Tur kuponundaki yer ve saati kontrol edin.',
              )[lang]
            }
          </p>
        </div>
      ) : (
        <>
          {section && (
            <div className="google-section-note">
              <Route size={17} />
              <span>
                {
                  w(
                    'Exibindo trecho(s)',
                    'Showing leg(s)',
                    'Gösterilen etap(lar)',
                  )[lang]
                }{' '}
                {section.legs[0].index + 1}–{section.legs.at(-1)!.index + 1} ·{' '}
                {section.mode === 'walking'
                  ? w(
                      'todas as paradas da caminhada',
                      'all walking stops',
                      'tüm yürüyüş durakları',
                    )[lang]
                  : w(
                      'conexão de transporte público',
                      'public transport connection',
                      'toplu taşıma bağlantısı',
                    )[lang]}
              </span>
            </div>
          )}
          <GoogleRouteMap
            section={section}
            lang={lang}
            points={route.points}
            selected={active?.id}
            live={origin === 'current'}
            onSelect={onSelect}
            tripDate={tripDate}
            suggestedTime={sectionDepartureTime(plan, section)}
          />
        </>
      )}
      <div className="route-sequence">
        <div className="route-sequence-heading">
          <h3>
            {
              w(
                'Seu trajeto, passo a passo',
                'Your route, step by step',
                'Adım adım rotanız',
              )[lang]
            }
          </h3>
          <span>
            {route.legs.length} {w('trechos', 'legs', 'etap')[lang]}
          </span>
        </div>
        <p>
          {origin === 'current'
            ? w(
                'Segue para as paradas ainda não visitadas, na ordem do roteiro.',
                'Continues through unvisited stops in itinerary order.',
                'Gezi sırasıyla ziyaret edilmemiş duraklara devam eder.',
              )[lang]
            : w(
                'A mesma ordem do roteiro. Adicionar ou remover um lugar atualiza este caminho.',
                'The same order as your itinerary. Adding or removing a place updates this route.',
                'Gezi planınızla aynı sıra. Yer eklemek veya kaldırmak bu rotayı günceller.',
              )[lang]}
        </p>
        <ol>
          {route.legs.map((l) => (
            <li key={l.id}>
              <button
                className={`sequence-leg ${active?.id === l.id ? 'active' : ''} ${l.mode}`}
                aria-pressed={active?.id === l.id}
                onClick={() => onSelect(l.to.id)}
              >
                <span className="sequence-number">{l.index + 1}</span>
                <span className="sequence-destinations">
                  <small>{l.from.name}</small>
                  <b>
                    <ArrowRight size={14} />
                    {l.to.name}
                  </b>
                  <em>
                    {l.mode === 'walking' ? (
                      <>
                        <Footprints size={14} />
                        {w('A pé', 'Walking', 'Yürüyüş')[lang]}
                      </>
                    ) : l.mode === 'transit' ? (
                      <>
                        <TramFront size={14} />
                        {
                          w(
                            'Transporte público',
                            'Public transport',
                            'Toplu taşıma',
                          )[lang]
                        }
                      </>
                    ) : (
                      w(
                        'Confirmar endereço',
                        'Confirm address',
                        'Adresi doğrulayın',
                      )[lang]
                    )}
                    {visited[l.to.id] && <Check size={15} />}
                  </em>
                </span>
              </button>
            </li>
          ))}
        </ol>
      </div>
      {!!links.length && (
        <section className="map-footer map-handoff">
          <h3>
            {
              w(
                'Continuar no aplicativo Google Maps',
                'Continue in the Google Maps app',
                'Google Maps uygulamasında devam et',
              )[lang]
            }
          </h3>
          <p>
            {
              w(
                links.length > 1
                  ? 'Abra a Parte 1 primeiro. Ao chegar ao último lugar dela, abra a próxima parte para continuar. Assim, todas as paradas entram no caminho.'
                  : 'Este botão abre o caminho abaixo, com a saída e as paradas já preenchidas.',
                links.length > 1
                  ? 'Open Part 1 first. At its last stop, open the next part to continue. This keeps every stop in your route.'
                  : 'This button opens the route below with its start and stops already filled in.',
                links.length > 1
                  ? 'Önce 1. bölümü açın. Son durağına varınca sonraki bölümü açarak devam edin. Böylece tüm duraklar rotada kalır.'
                  : 'Bu düğme başlangıç ve durakları doldurulmuş aşağıdaki rotayı açar.',
              )[lang]
            }
          </p>
          <ol className="map-handoff-parts">
            {links.map((link, i) => (
              <li key={link.url}>
                <h4>
                  {links.length > 1
                    ? w(
                        `Parte ${i + 1} de ${links.length}`,
                        `Part ${i + 1} of ${links.length}`,
                        `Bölüm ${i + 1} / ${links.length}`,
                      )[lang]
                    : w(
                        'Caminho completo deste trecho',
                        'Complete route for this section',
                        'Bu etabın tam rotası',
                      )[lang]}
                </h4>
                <ol className="map-handoff-stops">
                  {link.points.map((point, pointIndex) => (
                    <li key={`${point.id}-${pointIndex}`}>
                      <span>{mapPointLabel(point.id, route.points)}</span>
                      <div>
                        <small>
                          {pointIndex === 0
                            ? w('Saída', 'Start', 'Başlangıç')[lang]
                            : pointIndex === link.points.length - 1
                              ? w('Chegada', 'Arrival', 'Varış')[lang]
                              : w('Parada', 'Stop', 'Durak')[lang]}
                        </small>
                        <b>{point.name}</b>
                      </div>
                    </li>
                  ))}
                </ol>
                <a
                  className="button primary"
                  href={link.url}
                  target="_blank"
                  rel="noreferrer"
                >
                  <Route size={18} />
                  {links.length > 1
                    ? w(
                        `Abrir Parte ${i + 1}`,
                        `Open Part ${i + 1}`,
                        `${i + 1}. bölümü aç`,
                      )[lang]
                    : w(
                        'Abrir este caminho no Google Maps',
                        'Open this route in Google Maps',
                        'Bu rotayı Google Maps’te aç',
                      )[lang]}
                  <ArrowUpRight size={18} />
                </a>
                {i < links.length - 1 && (
                  <p className="map-handoff-next">
                    {
                      w(
                        `Ao chegar em ${link.points.at(-1)!.name}, abra a Parte ${i + 2} abaixo.`,
                        `When you reach ${link.points.at(-1)!.name}, open Part ${i + 2} below.`,
                        `${link.points.at(-1)!.name} konumuna varınca aşağıdaki ${i + 2}. bölümü açın.`,
                      )[lang]
                    }
                  </p>
                )}
              </li>
            ))}
          </ol>
        </section>
      )}
      <HomeReturnCard
        from={
          poi[
            plan.end === 'university'
              ? 'university'
              : plan.stops.at(-1)?.id || plan.start
          ]
        }
        lang={lang}
        afterFaculty={plan.end === 'university'}
        onShow={onReturnHome}
      />
    </section>
  );
}

'use client';
import { ArrowRight, Footprints, MapPin, ChevronDown } from 'lucide-react';
import { w, type Lang, type Place } from '@/lib/guide';
import { mapPointLabel, type RouteSection } from '@/lib/route-plan';
import type { Coordinate, GoogleRoute } from '@/lib/google-maps-sdk';
import { TransitTimeline } from './transit-timeline';

export function GoogleJourneyDirections({
  route,
  section,
  points,
  lang,
  selected,
  onSelect,
  onFocus,
}: {
  route: GoogleRoute;
  section: RouteSection;
  points: Place[];
  lang: Lang;
  selected?: string;
  onSelect: (id: string) => void;
  onFocus: (point: Coordinate) => void;
}) {
  const time = (value?: Date) =>
    value
      ? new Intl.DateTimeFormat(lang, {
          timeZone: 'Europe/Istanbul',
          hour: '2-digit',
          minute: '2-digit',
        }).format(value)
      : '';
  return (
    <ol className="google-journey-legs">
      {route.legs?.map((leg, legIndex) => {
        const destination = section.points[legIndex + 1];
        const from = section.points[legIndex];
        if (!destination || !from) return null;
        const label = mapPointLabel(destination.id, points);
        return (
          <li
            key={section.legs[legIndex]?.id || legIndex}
            className="google-journey-leg"
          >
            <details
              open={
                section.mode === 'transit' ||
                selected === section.legs[legIndex]?.id
              }
            >
              <summary>
                <span>
                  <small>
                    {w('Saindo de', 'Leaving', 'Çıkış')[lang]} {from.name}
                  </small>
                  <b>
                    <ArrowRight size={14} />
                    {destination.name}
                  </b>
                </span>
                <ChevronDown size={18} />
              </summary>
              {section.mode === 'transit' ? (
                <TransitTimeline
                  route={route}
                  legIndex={legIndex}
                  destination={destination.name}
                  lang={lang}
                  onFocus={onFocus}
                />
              ) : (
                <ol className="google-step-list">
                  {leg.steps?.map((step, index) => {
                    const transit = step.transitDetails;
                    return (
                      <li
                        key={index}
                        className={transit ? 'transit' : 'walking'}
                      >
                        {transit ? (
                          <>
                            <span className="transit-line-badge">
                              {transit.transitLine?.shortName ||
                                transit.transitLine?.name}
                            </span>
                            <div>
                              <b>
                                {transit.departureStop?.name}{' '}
                                <ArrowRight size={14} />{' '}
                                {transit.arrivalStop?.name}
                              </b>
                              <span>
                                {time(transit.departureTime)} –{' '}
                                {time(transit.arrivalTime)} ·{' '}
                                {transit.transitLine?.vehicle?.name}
                                {transit.headsign
                                  ? ` · ${transit.headsign}`
                                  : ''}
                              </span>
                            </div>
                          </>
                        ) : (
                          <>
                            <Footprints size={18} />
                            <div>
                              <b>
                                {step.instructions ||
                                  w('Caminhada', 'Walk', 'Yürüyüş')[lang]}
                              </b>
                              <span>
                                {step.distanceMeters
                                  ? `${step.distanceMeters} m`
                                  : ''}
                                {step.staticDurationMillis
                                  ? ` · ${Math.ceil(step.staticDurationMillis / 60000)} min`
                                  : ''}
                              </span>
                            </div>
                          </>
                        )}
                      </li>
                    );
                  })}
                </ol>
              )}
            </details>
            <button
              className="destination-arrival"
              onClick={() => onSelect(destination.id)}
              aria-label={`${w('Ver chegada no mapa', 'View arrival on map', 'Varışı haritada gör')[lang]}: ${destination.name}`}
            >
              <span className="arrival-number">{label}</span>
              <span>
                <small>
                  {destination.id === 'base'
                    ? w(
                        'CHEGADA AO AIRBNB',
                        'ARRIVAL AT AIRBNB',
                        'AIRBNB’YE VARIŞ',
                      )[lang]
                    : w('CHEGADA À PARADA', 'ARRIVAL AT STOP', 'DURAĞA VARIŞ')[
                        lang
                      ]}
                </small>
                <strong>{destination.name}</strong>
              </span>
              <MapPin size={20} />
            </button>
          </li>
        );
      })}
    </ol>
  );
}

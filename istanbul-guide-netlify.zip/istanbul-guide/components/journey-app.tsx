'use client';
import { useCallback, useEffect, useMemo, useState } from 'react';
import Image from 'next/image';
import {
  ArrowUpRight,
  ArrowRight,
  MapPin,
  Map,
  Route,
  Compass,
  BookOpen,
  GraduationCap,
  ChevronLeft,
  ChevronRight,
  LocateFixed,
  Footprints,
  TramFront,
  Check,
  Home,
  Star,
  Clock,
  Utensils,
  ShoppingBag,
  RefreshCw,
  Trash2,
} from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { useTripTools } from '@/lib/use-trip-tools';
import { PlaceFacts, PlanEditor, type EditAction } from './plan-editor';
import { PlacesContext, usePlaces } from '@/lib/places-context';
import {
  initialPlans,
  optimizePlan,
  emptyEdits,
  type Edits,
  type CustomPlace,
} from '@/lib/planner';
import { GuideSelect as NativeSelect } from '@/components/guide-select';
import { Progress } from '@/components/ui/progress';
import MapPanel from './journey-map-panel';
import { HomeReturnCard } from './home-return-card';
import { sectionDepartureTime } from '@/lib/route-plan';
import { LiveNavigationProvider } from '@/lib/live-navigation';
import {
  poi as basePoi,
  universityPlans,
  legsFor,
  googleDirections,
  distance,
  excluded,
  w,
  type Lang,
  type Place,
  type Plan,
  type Leg,
} from '@/lib/guide';
import photoData from '@/lib/guide-photos.json';
type Photo = {
  url: string;
  source: string;
  credit: string;
  license: string;
  licenseUrl: string;
};
const photos = photoData as Record<string, Photo>;

type Visits = Record<string, boolean>;
const languageNames = { pt: 'Português', en: 'English', tr: 'Türkçe' };
const locale = { pt: 'pt-BR', en: 'en-GB', tr: 'tr-TR' };
const copy = {
  itinerary: w('Roteiro', 'Itinerary', 'Gezi planı'),
  map: w('Mapa', 'Map', 'Harita'),
  explore: w('Lugares', 'Places', 'Yerler'),
  university: w('80 minutos', '80 minutes', '80 dakika'),
  guide: w('Guia', 'Guide', 'Rehber'),
  from: w('Saída', 'From', 'Başlangıç'),
  to: w('Destino', 'To', 'Varış'),
  route: w('Ver rota', 'View route', 'Rotayı gör'),
  done: w('Visitado · desmarcar', 'Visited · undo', 'Ziyaret edildi · geri al'),
  todo: w('Marcar como visitado', 'Mark as visited', 'Ziyaret edildi işaretle'),
  google: w('Abrir no Google Maps', 'Open in Google Maps', 'Google Maps’te aç'),
  current: w('Da minha localização', 'From my location', 'Konumumdan'),
  back: w('Volta ao Airbnb', 'Return to Airbnb', 'Airbnb’ye dönüş'),

  food: w('Comida > 4,6', 'Food > 4.6', 'Yemek > 4,6'),
  sight: w('Atrações', 'Sights', 'Gezilecek yerler'),
  shop: w('Mercados', 'Groceries', 'Marketler'),
  all: w('Todos', 'All', 'Tümü'),
};
function dateLabel(date: string, lang: Lang) {
  return new Intl.DateTimeFormat(locale[lang], {
    day: 'numeric',
    month: 'short',
    weekday: 'short',
    timeZone: 'UTC',
  }).format(new Date(date + 'T12:00:00Z'));
}
function kindLabel(p: Place, lang: Lang) {
  return p.kind === 'food'
    ? w('Restaurante', 'Restaurant', 'Restoran')[lang]
    : p.kind === 'shop'
      ? w('Compras', 'Groceries', 'Alışveriş')[lang]
      : p.kind === 'transport'
        ? w('Passeio reservado', 'Selected experience', 'Seçilen deneyim')[lang]
        : w('Atração', 'Sight', 'Gezilecek yer')[lang];
}
function PlaceCard({
  place,
  lang,
  number,
  time,
  done,
  saving,
  ready,
  onToggle,
  onRoute,
  selected,
  onTrash,
  date,
}: {
  place: Place;
  onTrash?: () => void;
  date?: string;
  lang: Lang;
  number?: number;
  time?: string;
  done: boolean;
  saving: boolean;
  ready: boolean;
  onToggle: () => void;
  onRoute: () => void;
  selected?: boolean;
}) {
  const custom = place as CustomPlace;
  const photo = custom.imageUrl ? { url: custom.imageUrl } : photos[place.id];
  return (
    <article
      className={`place-card kind-${place.kind} ${done ? 'is-done' : ''} ${selected ? 'is-selected' : ''}`}
      id={'place-' + place.id}
    >
      <a
        className="place-image"
        href={
          place.unmapped ? place.source : googleDirections(undefined, place)
        }
        target="_blank"
        rel="noreferrer"
        aria-label={`${place.name} · ${copy.current[lang]}`}
      >
        {!photo && (
          <span className="custom-photo-empty">
            <MapPin size={40} />
            {
              w(
                'Seu lugar no mapa',
                'Your place on the map',
                'Haritadaki yeriniz',
              )[lang]
            }
          </span>
        )}
        {photo && (
          <Image
            src={photo.url}
            alt={place.name}
            width={900}
            height={600}
            unoptimized
            loading="lazy"
          />
        )}
        <span className="image-route">
          <LocateFixed size={16} />
          {place.unmapped
            ? w('Ver passeio', 'View experience', 'Turu gör')[lang]
            : copy.current[lang]}
          <ArrowUpRight size={16} />
        </span>
      </a>
      <div className="place-body">
        <div className="place-meta">
          <span>
            {number !== undefined && (
              <b className="stop-number">
                {number.toString().padStart(2, '0')}
              </b>
            )}
            {time && time !== '—' ? time : kindLabel(place, lang)}
          </span>
          {place.kind === 'food' && place.rating && (
            <span className="rating">
              <Star size={15} fill="currentColor" />
              {place.rating.toFixed(1)}
              {custom.custom && (
                <small>
                  {
                    w(' · sua nota', ' · your rating', ' · sizin puanınız')[
                      lang
                    ]
                  }
                </small>
              )}
            </span>
          )}
        </div>
        <div className="place-title-row">
          <h3>{place.name}</h3>
          {onTrash && (
            <button
              className="remove-place"
              onClick={onTrash}
              aria-label={`${w('Mover para lixeira', 'Move to trash', 'Çöp kutusuna taşı')[lang]}: ${place.name}`}
            >
              <Trash2 size={19} />
            </button>
          )}
        </div>
        <p className="area">
          <MapPin size={14} />
          {place.area}
        </p>
        <p className="description">{place.description[lang]}</p>
        <PlaceFacts place={place} lang={lang} date={date} />
        <div className="card-actions">
          <button className="button primary" onClick={onRoute}>
            <Route size={18} />
            {copy.route[lang]}
            <ArrowRight size={17} />
          </button>
          <label className={`check-action ${done ? 'checked' : ''}`}>
            <Checkbox
              className="visit-checkbox"
              checked={done}
              disabled={saving || !ready}
              onCheckedChange={onToggle}
              aria-label={`${copy.todo[lang]}: ${place.name}`}
            />
            <span>
              {saving
                ? w('Salvando…', 'Saving…', 'Kaydediliyor…')[lang]
                : done
                  ? copy.done[lang]
                  : copy.todo[lang]}
            </span>
          </label>
        </div>
      </div>
    </article>
  );
}
function LegCard({
  leg,
  lang,
  onClick,
  selected,
}: {
  leg: Leg;
  lang: Lang;
  onClick: () => void;
  selected: boolean;
}) {
  const poi = usePlaces();
  return (
    <button
      onClick={onClick}
      className={`leg-card ${selected ? 'active' : ''}`}
    >
      <span className="leg-icon">
        {leg.mode === 'walking' ? (
          <Footprints size={20} />
        ) : (
          <TramFront size={20} />
        )}
      </span>
      <span className="leg-text">
        <span>
          <b>{poi[leg.from].name}</b>
          <ArrowRight size={15} />
          <b>{poi[leg.to].name}</b>
        </span>
        <small>{leg.reason[lang]}</small>
      </span>
      <ArrowUpRight size={19} />
    </button>
  );
}
export default function JourneyApp() {
  const [lang, setLang] = useState<Lang>('pt'),
    [tab, setTab] = useState('itinerary'),
    [day, setDay] = useState(0),
    [uni, setUni] = useState(0),
    [mapContext, setMapContext] = useState<
      'trip' | 'university' | 'explore' | 'home'
    >('trip'),
    [exploreId, setExploreId] = useState('fb'),
    [homeFrom, setHomeFrom] = useState('university'),
    [selected, setSelected] = useState(''),
    [category, setCategory] = useState('food'),
    [search, setSearch] = useState(''),
    [pendingOnly, setPendingOnly] = useState(false),
    [near, setNear] = useState(true),
    [visited, setVisited] = useState<Visits>({}),
    [saving, setSaving] = useState<Record<string, boolean>>({}),
    [ready, setReady] = useState(false),
    [error, setError] = useState(''),
    [edits, setEdits] = useState<Edits>(emptyEdits),
    [editReady, setEditReady] = useState(false),
    [editBusy, setEditBusy] = useState(false),
    [editError, setEditError] = useState(''),
    [editNotice, setEditNotice] = useState(false);
  const poi = useMemo(
    () => ({
      ...basePoi,
      ...Object.fromEntries(edits.custom.map((p) => [p.id, p])),
    }),
    [edits.custom],
  );
  const allPlaces = useMemo(() => Object.values(poi), [poi]);
  const tripPlans = useMemo(
    () => initialPlans.map((p) => optimizePlan(p, edits, poi)),
    [edits, poi],
  );
  const plan = tripPlans[day];
  const uplan = useMemo(
    () => optimizePlan(universityPlans[uni], edits, poi),
    [uni, edits, poi],
  );
  const loadEdits = useCallback(async () => {
    try {
      const r = await fetch('/api/planner', { cache: 'no-store' });
      if (!r.ok) throw Error();
      setEdits((await r.json()) as Edits);
      setEditReady(true);
      setEditError('');
    } catch {
      setEditError('load');
    }
  }, []);
  useEffect(() => {
    queueMicrotask(() => void loadEdits());
  }, [loadEdits]);
  async function saveEdit(action: EditAction) {
    if (editBusy) return false;
    setEditBusy(true);
    setEditError('');
    try {
      const r = await fetch('/api/planner', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(action),
      });
      if (!r.ok) throw Error();
      setEdits((await r.json()) as Edits);
      setSelected('');
      setEditNotice(true);
      if (action.action === 'trash') setMapContext('trip');
      return true;
    } catch {
      setEditError('save');
      return false;
    } finally {
      setEditBusy(false);
    }
  }
  const explorePlan: Plan = useMemo(
    () => ({
      id: 'explore',
      title: w('Lugar selecionado', 'Selected place', 'Seçilen yer'),
      area: 'İstanbul',
      note: w('', '', ''),
      start: 'base',
      stops: [{ id: exploreId, time: '—' }],
      end: 'base',
    }),
    [exploreId],
  );
  const homePlan: Plan = useMemo(
    () => ({
      id: `home-${plan.id}-${homeFrom}`,
      date: plan.date,
      startTime:
        homeFrom === 'university'
          ? ''
          : sectionDepartureTime(plan, { points: [poi[homeFrom]] }),
      title: w('De volta ao Airbnb', 'Back to the Airbnb', 'Airbnb’ye dönüş'),
      area: poi[homeFrom]?.area || 'İstanbul',
      note: w('', '', ''),
      start: homeFrom,
      stops: [],
      end: 'base',
    }),
    [plan, homeFrom, poi],
  );
  const openReturn = (from: string) => {
    setHomeFrom(from);
    setMapContext('home');
    setSelected('');
    setTab('map');
  };
  const mapPlan =
    mapContext === 'home'
      ? homePlan
      : mapContext === 'university'
        ? uplan
        : mapContext === 'explore'
          ? explorePlan
          : plan;
  const mapLegs = useMemo(() => legsFor(mapPlan, poi), [mapPlan, poi]);
  const activeLeg = mapLegs.find((l) => l.id === selected) || mapLegs[0];
  const dayLegs = useMemo(() => legsFor(plan, poi), [plan, poi]);
  const uLegs = useMemo(() => legsFor(uplan, poi), [uplan, poi]);
  const total = allPlaces.filter(
      (p) => p.kind !== 'base' && !edits.trash.includes(p.id),
    ).length,
    completed = allPlaces.filter(
      (p) => p.kind !== 'base' && !edits.trash.includes(p.id) && visited[p.id],
    ).length;
  const refresh = useCallback(async () => {
    setError('');
    try {
      const response = await fetch('/api/progress', { cache: 'no-store' });
      if (!response.ok) throw new Error('progress');
      const data = (await response.json()) as { visited: Visits };
      setVisited(data.visited);
      setReady(true);
    } catch {
      setReady(false);
      setError('load');
    }
  }, []);
  useTripTools(refresh);
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [tab]);
  useEffect(() => {
    queueMicrotask(() => void refresh());
    try {
      const stored = localStorage.getItem('istanbul-language');
      if (stored === 'pt' || stored === 'en' || stored === 'tr')
        queueMicrotask(() => setLang(stored));
    } catch {}
  }, [refresh]);
  useEffect(() => {
    document.documentElement.lang = locale[lang];
    try {
      localStorage.setItem('istanbul-language', lang);
    } catch {}
  }, [lang]);
  async function toggle(id: string) {
    if (!ready || saving[id]) return;
    const previous = !!visited[id];
    setVisited((v) => ({ ...v, [id]: !previous }));
    setSaving((s) => ({ ...s, [id]: true }));
    setError('');
    try {
      const response = await fetch('/api/progress', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, done: !previous }),
      });
      if (!response.ok) throw new Error('save');
    } catch {
      setVisited((v) => ({ ...v, [id]: previous }));
      setError('save');
    } finally {
      setSaving((s) => ({ ...s, [id]: false }));
    }
  }
  function selectRoute(
    leg: Leg,
    context: 'trip' | 'university' | 'explore',
    open = true,
  ) {
    setMapContext(context);
    setSelected(leg.id);
    if (open) setTab('map');
  }
  function changeDay(n: number) {
    setDay(n);
    setMapContext('trip');
    setSelected('');
  }
  function card(
    p: Place,
    index?: number,
    time?: string,
    context: 'trip' | 'university' | 'explore' = 'trip',
  ) {
    const legs = context === 'university' ? uLegs : dayLegs;
    return (
      <PlaceCard
        date={context === 'trip' ? plan.date : undefined}
        onTrash={
          editReady
            ? () => void saveEdit({ action: 'trash', id: p.id })
            : undefined
        }
        key={p.id}
        place={p}
        lang={lang}
        number={index}
        time={time}
        done={!!visited[p.id]}
        saving={!!saving[p.id]}
        ready={ready}
        selected={activeLeg?.to === p.id}
        onToggle={() => void toggle(p.id)}
        onRoute={() => {
          if (context === 'explore') {
            setExploreId(p.id);
            setMapContext('explore');
            setSelected('');
            setTab('map');
          } else {
            const leg = legs.find((l) => l.to === p.id);
            if (leg) selectRoute(leg, context);
          }
        }}
      />
    );
  }
  const matching = allPlaces.filter(
    (p) =>
      p.kind !== 'base' &&
      !edits.trash.includes(p.id) &&
      (category === 'all' ||
        p.kind === category ||
        (category === 'saved' && p.saved)) &&
      (!pendingOnly || !visited[p.id]) &&
      (p.name + ' ' + p.area)
        .toLocaleLowerCase(locale[lang])
        .includes(search.toLocaleLowerCase(locale[lang])) &&
      (category !== 'food' || !near || distance(poi.base, p) <= 2),
  );
  const next = plan.stops.find((s) => !visited[s.id]);
  return (
    <PlacesContext.Provider value={poi}>
      <LiveNavigationProvider>
        <div className="journey-app">
          <header className="topbar">
            <div className="brand">
              <span className="brand-mark">
                <Compass size={25} />
              </span>
              <div>
                <strong>
                  İstanbul<span> / </span>A dois
                </strong>
                <small>Samuel & Zeynep · 21.10 — 03.11.2026</small>
              </div>
            </div>
            <div className="language-control">
              <Image
                src={`https://flagcdn.com/w40/${lang === 'pt' ? 'br' : lang === 'en' ? 'gb' : 'tr'}.png`}
                alt={
                  lang === 'pt'
                    ? 'Brasil'
                    : lang === 'en'
                      ? 'United Kingdom'
                      : 'Türkiye'
                }
                width={24}
                height={16}
                unoptimized
              />
              <NativeSelect
                className="language-select"
                aria-label="Idioma / Language / Dil"
                value={lang}
                onChange={(e) => setLang(e.target.value as Lang)}
              >
                {Object.entries(languageNames).map(([value, label]) => (
                  <option key={value} value={value}>
                    {label}
                  </option>
                ))}
              </NativeSelect>
            </div>
          </header>
          <Tabs
            value={tab}
            onValueChange={(value) => setTab(String(value))}
            className="app-tabs"
          >
            <TabsList className="main-nav">
              {[
                { id: 'itinerary', icon: Route, text: copy.itinerary },
                { id: 'map', icon: Map, text: copy.map },
                { id: 'explore', icon: Compass, text: copy.explore },
                {
                  id: 'university',
                  icon: GraduationCap,
                  text: copy.university,
                },
                { id: 'guide', icon: BookOpen, text: copy.guide },
              ].map(({ id, icon: Icon, text }) => (
                <TabsTrigger key={id} value={id}>
                  <Icon size={21} />
                  <span>{text[lang]}</span>
                </TabsTrigger>
              ))}
            </TabsList>
            <main className="app-main">
              {editError && (
                <div className="error-banner">
                  <span>
                    {
                      w(
                        'Não foi possível carregar ou salvar as alterações do roteiro.',
                        'Could not load or save itinerary changes.',
                        'Gezi değişiklikleri yüklenemedi veya kaydedilemedi.',
                      )[lang]
                    }
                  </span>
                  <button className="button" onClick={() => void loadEdits()}>
                    {w('Tentar novamente', 'Retry', 'Tekrar dene')[lang]}
                  </button>
                </div>
              )}
              {error && (
                <div className="error-banner">
                  <span>
                    {error === 'load'
                      ? w(
                          'Checklist sem conexão. Reconecte para carregar seus lugares visitados.',
                          'Checklist offline. Reconnect to load your visited places.',
                          'Kontrol listesi çevrimdışı. Ziyaretleri yüklemek için yeniden bağlanın.',
                        )[lang]
                      : w(
                          'Não foi possível salvar. A marcação foi desfeita; tente novamente.',
                          'Could not save. The change was undone; please retry.',
                          'Kaydedilemedi. Değişiklik geri alındı; tekrar deneyin.',
                        )[lang]}
                  </span>
                  <button
                    className="button subtle"
                    onClick={() => void refresh()}
                  >
                    <RefreshCw size={17} />
                    {w('Reconectar', 'Reconnect', 'Yeniden bağlan')[lang]}
                  </button>
                </div>
              )}
              <TabsContent value="itinerary">
                <div className="workspace-heading">
                  <div>
                    <span className="eyebrow">
                      {
                        w(
                          '10 DIAS PRINCIPAIS + EXTRAS',
                          '10 MAIN DAYS + EXTRAS',
                          '10 ANA GÜN + EK GÜNLER',
                        )[lang]
                      }
                    </span>
                    <h1>
                      {
                        w(
                          'Um dia de cada vez.',
                          'One day at a time.',
                          'Her seferinde bir gün.',
                        )[lang]
                      }
                    </h1>
                  </div>
                  <div className="trip-progress">
                    <span>
                      <Check size={16} />
                      {completed} / {total}{' '}
                      {w('visitados', 'visited', 'ziyaret')[lang]}
                    </span>
                    <Progress
                      value={(completed / total) * 100}
                      aria-label={
                        w(
                          'Progresso da viagem',
                          'Trip progress',
                          'Gezi ilerlemesi',
                        )[lang]
                      }
                    />
                  </div>
                </div>
                <PlanEditor
                  lang={lang}
                  plans={tripPlans}
                  day={day}
                  onDay={changeDay}
                  edits={edits}
                  places={allPlaces}
                  save={saveEdit}
                  busy={editBusy}
                  ready={editReady}
                />
                {editNotice && (
                  <output className="edit-notice">
                    <Check size={17} />
                    {
                      w(
                        'Alterações salvas · sequência e mapa atualizados',
                        'Changes saved · order and map updated',
                        'Değişiklikler kaydedildi · sıra ve harita güncellendi',
                      )[lang]
                    }
                  </output>
                )}
                <div className="day-picker">
                  <button
                    className="icon-button"
                    disabled={day === 0}
                    onClick={() => changeDay(day - 1)}
                    aria-label={
                      w('Dia anterior', 'Previous day', 'Önceki gün')[lang]
                    }
                  >
                    <ChevronLeft />
                  </button>
                  <NativeSelect
                    value={day}
                    onChange={(e) => changeDay(Number(e.target.value))}
                    aria-label={
                      w('Escolher dia', 'Choose day', 'Gün seçin')[lang]
                    }
                  >
                    {tripPlans.map((d, i) => (
                      <option key={d.id} value={i}>
                        {dateLabel(d.date!, lang)} · {d.title[lang]}
                      </option>
                    ))}
                  </NativeSelect>
                  <button
                    className="icon-button"
                    disabled={day === tripPlans.length - 1}
                    onClick={() => changeDay(day + 1)}
                    aria-label={
                      w('Próximo dia', 'Next day', 'Sonraki gün')[lang]
                    }
                  >
                    <ChevronRight />
                  </button>
                </div>
                <div className="day-grid">
                  <div className="itinerary-column">
                    <section className="day-intro">
                      <span className="pill">
                        <MapPin size={15} />
                        {plan.area}
                      </span>
                      <h2>{plan.title[lang]}</h2>
                      <p>
                        {plan.id === '2026-10-21'
                          ? w(
                              'Chegada em 21 de outubro. Compras e jantar flexíveis perto da base; ajuste ao horário de check-in.',
                              'Arrival on 21 October. Flexible shopping and dinner near your base; adapt to check-in.',
                              '21 Ekim varış. Konaklama yakınında esnek alışveriş ve akşam yemeği; giriş saatine göre ayarlayın.',
                            )[lang]
                          : w(
                              'A sequência prioriza as paradas abertas mais próximas. Os horários são estimativas com tempo de visita; confirme filas, orações e transporte no dia.',
                              'The sequence prioritizes the nearest open stops. Times allow for visits and are estimates; check queues, prayers and transport on the day.',
                              'Sıra, açık olan en yakın duraklara öncelik verir. Saatler ziyaret süresi içeren tahminlerdir; kuyruk, namaz ve ulaşımı o gün kontrol edin.',
                            )[lang]}
                      </p>
                      <div className="day-facts">
                        <span>
                          <Home size={17} />
                          Airbnb → {plan.stops.length}{' '}
                          {w('paradas', 'stops', 'durak')[lang]} → Airbnb
                        </span>
                        <span>
                          <Clock size={16} />
                          {
                            w(
                              'Horários sugeridos',
                              'Suggested times',
                              'Önerilen saatler',
                            )[lang]
                          }
                        </span>
                      </div>
                    </section>
                    {next && (
                      <button
                        className="next-stop"
                        onClick={() => {
                          const leg = dayLegs.find((l) => l.to === next.id);
                          if (leg) selectRoute(leg, 'trip');
                        }}
                      >
                        <span>
                          <small>
                            {
                              w(
                                'PRÓXIMA PARADA A FAZER',
                                'NEXT UNVISITED STOP',
                                'SIRADAKİ DURAK',
                              )[lang]
                            }
                          </small>
                          <strong>{poi[next.id].name}</strong>
                        </span>
                        <ArrowRight size={25} />
                      </button>
                    )}
                    {plan.skipped.length > 0 && (
                      <div className="schedule-conflicts">
                        <h3>
                          {
                            w(
                              'Reprogramar estas paradas',
                              'Reschedule these stops',
                              'Bu durakları yeniden planlayın',
                            )[lang]
                          }
                        </h3>
                        {plan.skipped.map((s) => (
                          <p key={s.id}>
                            <b>{poi[s.id].name}</b> ·{' '}
                            {s.reason === 'closed'
                              ? w(
                                  'fechado neste dia',
                                  'closed this day',
                                  'bu gün kapalı',
                                )[lang]
                              : w(
                                  'não cabe no horário de abertura',
                                  'does not fit opening hours',
                                  'açılış saatine sığmıyor',
                                )[lang]}
                          </p>
                        ))}
                        <small>
                          {
                            w(
                              'Use Adicionar lugar em outro dia para reagendar.',
                              'Use Add place on another day to reschedule.',
                              'Yeniden planlamak için başka günde Yer ekle’yi kullanın.',
                            )[lang]
                          }
                        </small>
                      </div>
                    )}
                    <div className="timeline">
                      {plan.stops.map((s, i) => {
                        const leg = dayLegs.find((l) => l.to === s.id);
                        return (
                          <div key={s.id} className="timeline-stop">
                            {leg && (
                              <LegCard
                                leg={leg}
                                lang={lang}
                                selected={activeLeg?.id === leg.id}
                                onClick={() => selectRoute(leg, 'trip')}
                              />
                            )}
                            {card(poi[s.id], i + 1, s.time)}
                          </div>
                        );
                      })}
                    </div>
                    <HomeReturnCard
                      from={poi[plan.stops.at(-1)?.id || 'base']}
                      lang={lang}
                      onShow={openReturn}
                    />
                  </div>
                  <aside className="desktop-map">
                    <MapPanel
                      key={`desktop-${mapPlan.id}`}
                      plan={mapPlan}
                      tripDate={mapPlan.date || plan.date!}
                      onReturnHome={openReturn}
                      leg={activeLeg}
                      lang={lang}
                      visited={visited}
                      onSelect={(id) => {
                        const leg = mapLegs.find((l) => l.to === id);
                        if (leg) setSelected(leg.id);
                      }}
                    />
                  </aside>
                </div>
              </TabsContent>
              <TabsContent value="map">
                <div className="map-page-heading">
                  <div>
                    <span className="eyebrow">{copy.route[lang]}</span>
                    <h1>{mapPlan.title[lang]}</h1>
                  </div>
                </div>
                <div className="map-page">
                  <MapPanel
                    key={mapPlan.id}
                    plan={mapPlan}
                    tripDate={mapPlan.date || plan.date!}
                    onReturnHome={openReturn}
                    leg={activeLeg}
                    lang={lang}
                    visited={visited}
                    onSelect={(id) => {
                      const leg = mapLegs.find((l) => l.to === id);
                      if (leg) setSelected(leg.id);
                    }}
                  />
                  <div className="map-stop-list">
                    <h2>
                      {
                        w(
                          'Paradas deste percurso',
                          'Stops on this route',
                          'Bu rotanın durakları',
                        )[lang]
                      }
                    </h2>
                    {mapPlan.stops.map((s, i) => (
                      <button
                        className={`map-stop ${activeLeg?.to === s.id ? 'active' : ''}`}
                        key={s.id}
                        onClick={() =>
                          setSelected(
                            mapLegs.find((l) => l.to === s.id)?.id || '',
                          )
                        }
                      >
                        <span className="stop-number">
                          {visited[s.id] ? <Check size={16} /> : i + 1}
                        </span>
                        <span>
                          <strong>{poi[s.id].name}</strong>
                          <small>{poi[s.id].area}</small>
                        </span>
                        <ArrowRight size={18} />
                      </button>
                    ))}
                    <p className="secondary">
                      {
                        w(
                          'Escolha Airbnb, faculdade ou sua localização como saída. Os números no Google Maps seguem as paradas do roteiro. Nos trechos de transporte público, compare ônibus, trem, metrô e bonde.',
                          'Choose Airbnb, faculty or your location as origin. Google Maps numbers follow your itinerary stops. For public transport legs, compare bus, train, metro and tram.',
                          'Başlangıç olarak Airbnb, fakülte veya konumunuzu seçin. Google Maps numaraları gezi duraklarını takip eder. Toplu taşıma etaplarında otobüs, tren, metro ve tramvayı karşılaştırın.',
                        )[lang]
                      }
                    </p>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="explore">
                <div className="workspace-heading">
                  <div>
                    <span className="eyebrow">
                      {w('SUA SELEÇÃO', 'YOUR SHORTLIST', 'SEÇİMİNİZ')[lang]}
                    </span>
                    <h1>
                      {
                        w(
                          'Lugares que valem a parada.',
                          'Places worth a stop.',
                          'Uğramaya değer yerler.',
                        )[lang]
                      }
                    </h1>
                  </div>
                  <span className="pill">
                    {matching.length} {w('lugares', 'places', 'yer')[lang]}
                  </span>
                </div>
                <div className="explore-controls">
                  <Input
                    className="place-search"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder={
                      w(
                        'Buscar lugar ou bairro',
                        'Search place or neighborhood',
                        'Yer veya semt ara',
                      )[lang]
                    }
                    aria-label={
                      w('Buscar lugares', 'Search places', 'Yer ara')[lang]
                    }
                  />
                  <NativeSelect
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    aria-label={w('Categoria', 'Category', 'Kategori')[lang]}
                  >
                    <option value="food">{copy.food[lang]}</option>
                    <option value="sight">{copy.sight[lang]}</option>
                    <option value="shop">{copy.shop[lang]}</option>
                    <option value="all">{copy.all[lang]}</option>
                    <option value="saved">
                      {w('Suas escolhas', 'Your choices', 'Seçimleriniz')[lang]}
                    </option>
                  </NativeSelect>
                  <label className="filter-check">
                    <Checkbox
                      checked={pendingOnly}
                      onCheckedChange={(v) => setPendingOnly(!!v)}
                    />
                    <span>
                      {
                        w(
                          'Só falta visitar',
                          'Not visited yet',
                          'Henüz ziyaret edilmedi',
                        )[lang]
                      }
                    </span>
                  </label>
                  {category === 'food' && (
                    <label className="filter-check">
                      <Checkbox
                        checked={near}
                        onCheckedChange={(v) => setNear(!!v)}
                      />
                      <span>
                        {
                          w(
                            'Até 2 km do Airbnb',
                            'Within 2 km of Airbnb',
                            'Airbnb’den 2 km içinde',
                          )[lang]
                        }
                      </span>
                    </label>
                  )}
                </div>
                <p className="section-note">
                  {
                    w(
                      'Restaurantes com nota Google acima de 4,6 nas fontes consultadas. O raio de 2 km é em linha reta; a distância caminhando aparece na rota. Mercados e atrações não usam esse filtro.',
                      'Restaurants with Google ratings above 4.6 in checked sources. The 2 km radius is straight-line distance; walking distance is in directions. Groceries and sights do not use this filter.',
                      'Kontrol edilen kaynaklarda Google puanı 4,6 üzerinde olan restoranlar. 2 km kuş uçuşu mesafedir; yürüyüş mesafesi rotadadır. Marketler ve turistik yerler bu filtreye dahil değildir.',
                    )[lang]
                  }
                </p>
                <div className="explore-grid">
                  {matching.map((p) =>
                    card(p, undefined, undefined, 'explore'),
                  )}
                </div>
                {matching.length === 0 && (
                  <p className="notice">
                    {
                      w(
                        'Nenhum lugar com esses filtros. Limpe a busca ou amplie a seleção.',
                        'No places match these filters. Clear the search or broaden your selection.',
                        'Bu filtrelere uygun yer yok. Aramayı temizleyin veya seçimi genişletin.',
                      )[lang]
                    }
                  </p>
                )}
              </TabsContent>
              <TabsContent value="university">
                <div className="workspace-heading">
                  <div>
                    <span className="eyebrow">ZEYNEP · EDEBİYAT FAKÜLTESİ</span>
                    <h1>
                      {
                        w(
                          '80 minutos, perto dela.',
                          '80 minutes, close to her.',
                          '80 dakika, ona yakın.',
                        )[lang]
                      }
                    </h1>
                  </div>
                  <span className="time-badge">
                    <Clock size={20} />
                    1h20
                  </span>
                </div>
                <p className="section-note">
                  {
                    w(
                      'Todos os circuitos começam e terminam na Faculdade de Letras, Ordu Caddesi 6. Combine o mesmo portão com a Zeynep. As durações são margens de planejamento; confira a caminhada no Maps antes de sair.',
                      'Every loop starts and ends at the Faculty of Letters, Ordu Caddesi 6. Agree on the same gate with Zeynep. Times are planning allowances; check the walk in Maps before leaving.',
                      'Tüm turlar Edebiyat Fakültesi, Ordu Caddesi 6’da başlayıp biter. Zeynep ile aynı kapıda anlaşın. Süreler planlama payıdır; ayrılmadan Maps’te yürüyüşü kontrol edin.',
                    )[lang]
                  }
                </p>
                <NativeSelect
                  className="uni-select"
                  value={uni}
                  onChange={(e) => {
                    setUni(Number(e.target.value));
                    setMapContext('university');
                    setSelected('');
                  }}
                  aria-label={
                    w(
                      'Passeio de 80 minutos',
                      '80-minute outing',
                      '80 dakikalık gezi',
                    )[lang]
                  }
                >
                  {universityPlans.map((p, i) => (
                    <option key={p.id} value={i}>
                      {p.title[lang]}
                    </option>
                  ))}
                </NativeSelect>
                <div
                  className="uni-options"
                  aria-label={
                    w(
                      'Oito opções de passeio',
                      'Eight outing options',
                      'Sekiz gezi seçeneği',
                    )[lang]
                  }
                >
                  {universityPlans.map((p, i) => (
                    <button
                      key={p.id}
                      className={i === uni ? 'active' : ''}
                      aria-pressed={i === uni}
                      onClick={() => {
                        setUni(i);
                        setMapContext('university');
                        setSelected('');
                      }}
                    >
                      <span className="uni-option-number">{i + 1}</span>
                      <span>
                        <strong>{p.title[lang]}</strong>
                        <small>
                          <Footprints size={13} />
                          {p.budget!.walk} min{' '}
                          {
                            w('ida + volta', 'out + back', 'gidiş + dönüş')[
                              lang
                            ]
                          }
                        </small>
                      </span>
                      {i === uni && <Check size={18} />}
                    </button>
                  ))}
                </div>
                <div className="university-grid">
                  <div>
                    <div className="time-budget">
                      <div>
                        <Footprints />
                        <strong>{uplan.budget!.walk} min</strong>
                        <span>
                          {
                            w('Ida + volta', 'Out + back', 'Gidiş + dönüş')[
                              lang
                            ]
                          }
                        </span>
                      </div>
                      <div>
                        <Compass />
                        <strong>{uplan.budget!.visit} min</strong>
                        <span>
                          {w('No lugar', 'At the place', 'Mekânda')[lang]}
                        </span>
                      </div>
                      <div>
                        <Clock />
                        <strong>{uplan.budget!.buffer} min</strong>
                        <span>{w('Folga', 'Buffer', 'Ek süre')[lang]}</span>
                      </div>
                    </div>
                    <p className="notice">{uplan.note[lang]}</p>
                    {uplan.stops.length === 0 && (
                      <p className="notice">
                        {
                          w(
                            'Este lugar está na lixeira. Restaure-o no Roteiro ou escolha outro passeio.',
                            'This place is in trash. Restore it in Itinerary or choose another outing.',
                            'Bu yer çöp kutusunda. Gezi planından geri yükleyin veya başka gezi seçin.',
                          )[lang]
                        }
                      </p>
                    )}
                    {uplan.stops.map((s, i) => (
                      <div key={s.id}>
                        <LegCard
                          leg={uLegs[i]}
                          lang={lang}
                          selected={false}
                          onClick={() => selectRoute(uLegs[i], 'university')}
                        />
                        {card(poi[s.id], i + 1, '—', 'university')}
                      </div>
                    ))}
                    <div className="return-block">
                      <h3>
                        <GraduationCap size={20} />
                        {
                          w(
                            'Voltar para buscar a Zeynep',
                            'Return to meet Zeynep',
                            'Zeynep’i almaya dön',
                          )[lang]
                        }
                      </h3>
                      {uLegs.length > 0 && (
                        <LegCard
                          leg={uLegs.at(-1)!}
                          lang={lang}
                          selected={false}
                          onClick={() =>
                            selectRoute(uLegs.at(-1)!, 'university')
                          }
                        />
                      )}
                      <a
                        className="button primary"
                        href={googleDirections(undefined, poi.university)}
                        target="_blank"
                        rel="noreferrer"
                      >
                        <LocateFixed size={18} />
                        {
                          w(
                            'Ir agora para a faculdade',
                            'Go to the faculty now',
                            'Şimdi fakülteye git',
                          )[lang]
                        }
                      </a>
                    </div>
                    <HomeReturnCard
                      from={poi.university}
                      lang={lang}
                      afterFaculty
                      onShow={openReturn}
                    />
                  </div>
                  <aside className="faculty-card">
                    <Image
                      src={photos.university.url}
                      width={900}
                      height={600}
                      alt="İstanbul Üniversitesi Edebiyat Fakültesi"
                      unoptimized
                    />
                    <div>
                      <span className="eyebrow">
                        {copy.from[lang]} + {copy.to[lang]}
                      </span>
                      <h2>
                        İstanbul Üniversitesi
                        <br />
                        Edebiyat Fakültesi
                      </h2>
                      <p>
                        Balabanağa, Ordu Caddesi 6<br />
                        Laleli · Fatih
                      </p>
                    </div>
                  </aside>
                </div>
              </TabsContent>
              <TabsContent value="guide">
                <PracticalGuide lang={lang} />
              </TabsContent>
            </main>
          </Tabs>
          <footer className="app-footer">
            İstanbul · A dois{' '}
            <span>
              09.09.2026 ·{' '}
              {
                w(
                  'Planejado para vocês',
                  'Planned for you',
                  'Sizin için planlandı',
                )[lang]
              }
            </span>
          </footer>
        </div>
      </LiveNavigationProvider>
    </PlacesContext.Provider>
  );
}
function PracticalGuide({ lang }: { lang: Lang }) {
  return (
    <div className="practical">
      <div className="workspace-heading">
        <div>
          <span className="eyebrow">
            {w('ANTES DE SAIR', 'BEFORE YOU GO', 'ÇIKMADAN ÖNCE')[lang]}
          </span>
          <h1>
            {
              w(
                'O que ajuda no caminho.',
                'Useful along the way.',
                'Yolda işinize yarayanlar.',
              )[lang]
            }
          </h1>
        </div>
      </div>
      <div className="practical-grid">
        <section className="info-card">
          <Utensils />
          <h2>
            {
              w(
                'Comer bem, sem frutos do mar',
                'Good food, no seafood',
                'Deniz ürünü olmadan iyi yemek',
              )[lang]
            }
          </h2>
          <p>
            {
              w(
                'Planejamento de até R$ 500 por dia para refeições do casal. O valor em liras varia com o câmbio; 5.000 ₺ é uma referência de orçamento, não uma conversão garantida. Ingressos, transporte e cruzeiro ficam à parte.',
                'Planning up to R$500 per day for meals for two. The lira amount changes with exchange rates; ₺5,000 is a budget reference, not a guaranteed conversion. Tickets, transport and the cruise are separate.',
                'İki kişilik yemek için günlük R$500’e kadar planlandı. Lira tutarı kura bağlıdır; ₺5.000 bütçe referansıdır, garantili dönüşüm değildir. Biletler, ulaşım ve tur ayrıdır.',
              )[lang]
            }
          </p>
          <div className="budget-row">
            <span>{w('Café da manhã', 'Breakfast', 'Kahvaltı')[lang]}</span>
            <b>20%</b>
          </div>
          <div className="budget-row">
            <span>{w('Almoço', 'Lunch', 'Öğle yemeği')[lang]}</span>
            <b>30%</b>
          </div>
          <div className="budget-row">
            <span>{w('Jantar', 'Dinner', 'Akşam yemeği')[lang]}</span>
            <b>40%</b>
          </div>
          <div className="budget-row">
            <span>
              {w('Café & doces', 'Coffee & sweets', 'Kahve ve tatlı')[lang]}
            </span>
            <b>10%</b>
          </div>
          <blockquote>
            “Balık ve deniz ürünü yemiyorum. Et veya sebze yemeği var mı?”
          </blockquote>
          <p className="secondary">
            {
              w(
                'Não como peixe nem frutos do mar. Tem prato de carne ou vegetais?',
                'I don’t eat fish or seafood. Do you have meat or vegetable dishes?',
                'Restoranda kullanabileceğiniz cümle.',
              )[lang]
            }
          </p>
        </section>
        <section className="info-card">
          <TramFront />
          <h2>
            {
              w(
                'Mover-se por Istambul',
                'Getting around Istanbul',
                'İstanbul’da ulaşım',
              )[lang]
            }
          </h2>
          <p>
            {
              w(
                'Use Istanbulkart no transporte público. Da base, caminhe até Karaköy: T1 para Sultanahmet, Beyazıt ou Kabataş. Para Kadıköy e Üsküdar, confira a balsa; para Balat, conecte ao T5 em Eminönü.',
                'Use Istanbulkart on public transport. Walk from your base to Karaköy: T1 for Sultanahmet, Beyazıt or Kabataş. Check ferries to Kadıköy and Üsküdar; for Balat, connect to T5 at Eminönü.',
                'Toplu taşımada İstanbulkart kullanın. Konaklamadan Karaköy’e yürüyün: Sultanahmet, Beyazıt veya Kabataş için T1. Kadıköy ve Üsküdar vapurlarını kontrol edin; Balat için Eminönü’nde T5’e geçin.',
              )[lang]
            }
          </p>
          <a
            href="https://www.metro.istanbul/Hatlarimiz/HatDetay?hat=T1"
            target="_blank"
            rel="noreferrer"
            className="resource-link"
          >
            Metro İstanbul · T1
            <ArrowUpRight />
          </a>
          <a
            href="https://sehirhatlari.istanbul/en/timetables/domestic-trips/inner-istanbul-ferry-lines-26"
            target="_blank"
            rel="noreferrer"
            className="resource-link"
          >
            Şehir Hatları · {w('balsas', 'ferries', 'vapurlar')[lang]}
            <ArrowUpRight />
          </a>
          <a
            href="https://iett.istanbul/"
            target="_blank"
            rel="noreferrer"
            className="resource-link"
          >
            İETT · {w('ônibus', 'buses', 'otobüsler')[lang]}
            <ArrowUpRight />
          </a>
          <p className="secondary">
            {
              w(
                'As rotas abrem por trecho, com saída e destino. Horários de transporte, trânsito, filas e acessibilidade podem mudar o melhor caminho.',
                'Directions open leg by leg, with origin and destination. Timetables, traffic, queues and accessibility can change the best route.',
                'Rotalar başlangıç ve varışla etap etap açılır. Tarifeler, trafik, sıralar ve erişilebilirlik en iyi yolu değiştirebilir.',
              )[lang]
            }
          </p>
        </section>
        <section className="info-card">
          <ShoppingBag />
          <h2>
            {w('Compras úteis', 'Useful shopping', 'Faydalı alışveriş')[lang]}
          </h2>
          <p>
            {
              w(
                'CarrefourSA na Necatibey para água, frutas e básicos; Macrocenter no Galataport para produtos especiais; Namlı Gurme para queijos, azeitonas e compras de delicatessen. Namlı está aqui como loja, sem recomendação de refeição com nota não confirmada.',
                'CarrefourSA on Necatibey for water, fruit and essentials; Macrocenter at Galataport for specialty products; Namlı Gurme for cheese, olives and deli shopping. Namlı is listed as a shop, without a dining recommendation based on an unconfirmed rating.',
                'Su, meyve ve ihtiyaçlar için Necatibey CarrefourSA; özel ürünler için Galataport Macrocenter; peynir, zeytin ve şarküteri için Namlı Gurme. Namlı, doğrulanmamış puanla yemek önerisi olarak değil, alışveriş yeri olarak listelenmiştir.',
              )[lang]
            }
          </p>
          <p>
            {
              w(
                'Tahtakale e as ruas entre os bazares são boas para comparar preços. A passagem sob a Ponte de Gálata não é garantia de compras mais baratas; a parte inferior da ponte reúne principalmente restaurantes.',
                'Tahtakale and the streets between the bazaars are useful for comparing prices. The Galata Bridge underpass does not guarantee cheaper shopping; the lower bridge deck is mainly restaurants.',
                'Tahtakale ve çarşılar arası sokaklar fiyat karşılaştırmak için uygundur. Galata Köprüsü alt geçidi daha ucuz alışveriş garantisi değildir; alt kat ağırlıklı olarak restoranlardan oluşur.',
              )[lang]
            }
          </p>
        </section>
        <section className="info-card">
          <Clock />
          <h2>
            {
              w(
                'Datas & reservas',
                'Dates & reservations',
                'Tarihler ve rezervasyonlar',
              )[lang]
            }
          </h2>
          <p>
            {
              w(
                'Topkapı em 23/10 (sexta); evite terça. Dolmabahçe em 25/10 (domingo); evite segunda. Grand Bazaar em 24/10 (sábado); evite domingo. İstanbul Modern em 31/10 (sábado); evite segunda. Confira abertura e ingressos nas fontes antes da visita.',
                'Topkapı on 23 Oct (Friday); avoid Tuesday. Dolmabahçe on 25 Oct (Sunday); avoid Monday. Grand Bazaar on 24 Oct (Saturday); avoid Sunday. İstanbul Modern on 31 Oct (Saturday); avoid Monday. Confirm opening and tickets at the sources before visiting.',
                'Topkapı 23 Ekim Cuma; salıdan kaçının. Dolmabahçe 25 Ekim Pazar; pazartesiden kaçının. Kapalıçarşı 24 Ekim Cumartesi; pazardan kaçının. İstanbul Modern 31 Ekim Cumartesi; pazartesiden kaçının. Gitmeden açılış ve biletleri kaynaklardan doğrulayın.',
              )[lang]
            }
          </p>
          <p>
            {
              w(
                '29 de outubro é o Dia da República: espere alterações de circulação e movimento maior. Nas mesquitas, visite fora das orações. Hamam exige reserva e tem sessões separadas para homens e mulheres. Büyükada depende do tempo e das balsas de retorno.',
                '29 October is Republic Day: expect circulation changes and crowds. Visit mosques outside prayer times. The hamam needs booking and has separate sessions for men and women. Büyükada depends on weather and return ferries.',
                '29 Ekim Cumhuriyet Bayramı: ulaşım değişiklikleri ve kalabalık bekleyin. Camileri namaz saatleri dışında gezin. Hamam rezervasyon ister, kadın ve erkek seansları ayrıdır. Büyükada hava ve dönüş vapurlarına bağlıdır.',
              )[lang]
            }
          </p>
        </section>
        <section className="info-card wide">
          <Star />
          <h2>
            {
              w(
                'Seu filtro, aplicado de verdade',
                'Your filter, strictly applied',
                'Filtreniz, kesin olarak uygulandı',
              )[lang]
            }
          </h2>
          <p>
            {
              w(
                'Só entram nas recomendações de comida notas acima de 4,6. Lugares com 4,6, abaixo disso ou sem nota confirmada foram retirados, mesmo quando estavam na lista inicial. Dükkan saiu por divergência entre as fontes.',
                'Only food recommendations rated above 4.6 are included. Places at 4.6, below it, or with unconfirmed ratings were removed, even if originally saved. Dükkan was removed because sources conflict.',
                'Yemek önerilerine yalnızca 4,6 üzerindeki puanlar dahildir. 4,6, daha düşük veya doğrulanmamış puanlar, ilk listede olsa da çıkarıldı. Kaynaklar çeliştiği için Dükkan çıkarıldı.',
              )[lang]
            }
          </p>
          <details>
            <summary>
              {
                w(
                  'Ver lugares que saíram do filtro',
                  'See places excluded by the filter',
                  'Filtre dışında kalan yerler',
                )[lang]
              }
            </summary>
            <p>{excluded.map((p) => p.name).join(' · ')} · Dükkan Galata</p>
          </details>
          <p className="secondary">
            {
              w(
                'Dados conferidos em 9 de setembro de 2026. Preços de restaurantes são faixas de planejamento por pessoa, sem garantia de bebida, serviço ou gorjeta. Confira o cardápio antes de pedir. Horários, tarifas e notas podem mudar até a viagem.',
                'Checked 9 September 2026. Restaurant prices are planning ranges per person; drinks, service and tips may be extra. Check the menu before ordering. Hours, fees and ratings may change before the trip.',
                '9 Eylül 2026’da kontrol edildi. Restoran fiyatları kişi başı planlama aralığıdır; içecek, servis ve bahşiş ek olabilir. Siparişten önce menüyü kontrol edin. Saat, ücret ve puanlar değişebilir.',
              )[lang]
            }
          </p>
        </section>
      </div>
    </div>
  );
}

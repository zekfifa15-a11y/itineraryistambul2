'use client';
import { useEffect, useId, useMemo, useRef, useState } from 'react';
import {
  BusFront,
  TrainFront,
  TramFront,
  Layers,
  LocateFixed,
  Maximize,
  RefreshCw,
  CalendarDays,
  Clock,
} from 'lucide-react';
import { w, type Lang, type Place } from '@/lib/guide';
import { mapPointLabel, type RouteSection } from '@/lib/route-plan';
import { GoogleJourneyDirections } from './google-journey-directions';
import { GoogleRouteOptions } from './google-route-options';
import {
  googleRouteRequest,
  matchesTransitPreference,
  type TransitPreference,
} from '@/lib/google-route-request';
import {
  loadGoogleMaps,
  onGoogleAuthError,
  type GoogleSdk,
  type GoogleMap,
  type GoogleRoute,
  type GoogleRoutesLibrary,
  type Overlay,
} from '@/lib/google-maps-sdk';
import { useLiveNavigation } from '@/lib/live-navigation';
import {
  routeColors,
  stepMode,
  transitStops,
} from '@/lib/google-route-presentation';

const preferences = [
  { id: 'ALL', icon: Layers, label: w('Todos', 'All', 'Tümü') },
  { id: 'BUS', icon: BusFront, label: w('Ônibus', 'Bus', 'Otobüs') },
  { id: 'TRAIN', icon: TrainFront, label: w('Trem', 'Train', 'Tren') },
  { id: 'SUBWAY', icon: TrainFront, label: w('Metrô', 'Metro', 'Metro') },
  { id: 'LIGHT_RAIL', icon: TramFront, label: w('Bonde', 'Tram', 'Tramvay') },
] as const;

const darkStyle = [
  { elementType: 'geometry', stylers: [{ color: '#172735' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#b8cdd8' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#10202c' }] },
  {
    featureType: 'water',
    elementType: 'geometry',
    stylers: [{ color: '#0b1829' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry',
    stylers: [{ color: '#324453' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry',
    stylers: [{ color: '#5e5e58' }],
  },
  {
    featureType: 'poi.park',
    elementType: 'geometry',
    stylers: [{ color: '#163e39' }],
  },
  {
    featureType: 'transit',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#a6b9ff' }],
  },
];

export function GoogleInteractiveMap({
  apiKey,
  section,
  points,
  selected,
  live,
  lang,
  onSelect,
  tripDate,
  suggestedTime,
}: {
  apiKey: string;
  section: RouteSection;
  points: Place[];
  selected?: string;
  live: boolean;
  lang: Lang;
  onSelect: (id: string) => void;
  tripDate: string;
  suggestedTime: string;
}) {
  const host = useRef<HTMLDivElement>(null);
  const timeInput = useRef<HTMLInputElement>(null);
  const engine = useRef<{ sdk: GoogleSdk; map: GoogleMap } | null>(null);
  const nav = useLiveNavigation();
  const select = useRef(onSelect);
  const follow = useRef(true);
  const timeId = useId();
  const [ready, setReady] = useState(0);
  const [failure, setFailure] = useState('');
  const [preference, setPreference] = useState<TransitPreference>('ALL');
  const departureContext = `${tripDate}:${section.id}:${suggestedTime}`;
  const [departureChoice, setDepartureChoice] = useState<{
    context: string;
    time: string;
  }>();
  const departureTime =
    departureChoice?.context === departureContext
      ? departureChoice.time
      : suggestedTime;
  const departure = departureTime ? `${tripDate}T${departureTime}` : undefined;
  const needsTime = section.mode === 'transit' && !departureTime;
  const [reload, setReload] = useState(0);
  const [packet, setPacket] = useState<{
    key: string;
    routes: GoogleRoute[];
    error?: string;
  }>();
  const [choice, setChoice] = useState<{ key: string; index: number }>();
  const routeKey = JSON.stringify([
    section.mode,
    section.points.map((p) => [p.id, p.lat, p.lng]),
    lang,
    preference,
    departure,
    reload,
  ]);
  const routes = useMemo(
    () => (packet?.key === routeKey ? packet.routes : []),
    [packet, routeKey],
  );
  const routeIndex = choice?.key === routeKey ? choice.index : 0;
  const chosen = routes[routeIndex];
  const currentError = packet?.key === routeKey ? packet.error : undefined;
  useEffect(() => {
    select.current = onSelect;
  }, [onSelect]);

  useEffect(() => {
    let active = true;
    let listener: { remove: () => void } | undefined;
    const unsubscribe = onGoogleAuthError(() => {
      if (active) setFailure('map');
    });
    void loadGoogleMaps(apiKey, lang)
      .then((sdk) => {
        if (!active || !host.current) return;
        const map = new sdk.Map(host.current, {
          center: { lat: 41.028, lng: 28.978 },
          zoom: 14,
          styles: darkStyle,
          mapTypeControl: false,
          streetViewControl: true,
          fullscreenControl: true,
          gestureHandling: 'cooperative',
          clickableIcons: true,
        });
        engine.current = { sdk, map };
        listener = map.addListener('dragstart', () => {
          follow.current = false;
        });
        setFailure('');
        setReady((v) => v + 1);
      })
      .catch(() => {
        if (active) setFailure('map');
      });
    return () => {
      active = false;
      unsubscribe();
      listener?.remove();
      if (engine.current)
        engine.current.sdk.event.clearInstanceListeners(engine.current.map);
      engine.current = null;
    };
  }, [apiKey, lang]);

  useEffect(() => {
    if (!ready || !engine.current || needsTime) return;
    let active = true;
    const request = googleRouteRequest(section, lang, preference, departure);
    if (!request) return;
    void engine.current.sdk
      .importLibrary('routes')
      .then(async (library) => {
        const result = await (
          library as GoogleRoutesLibrary
        ).Route.computeRoutes(request);
        if (!active) return;
        const values = result.routes || [];
        // Some transit schedules produce duplicate alternatives; keep distinct trips.
        const seen = new Set<string>();
        const unique = values.filter((route) => {
          const signature = JSON.stringify([
            route.durationMillis,
            route.distanceMeters,
            route.legs?.flatMap((l) =>
              l.steps?.map((s) => [
                s.transitDetails?.transitLine?.shortName,
                s.transitDetails?.departureTime,
                s.transitDetails?.departureStop?.name,
              ]),
            ),
          ]);
          if (seen.has(signature)) return false;
          seen.add(signature);
          return true;
        });
        if (section.mode === 'transit' && preference !== 'ALL')
          unique.sort(
            (a, b) =>
              Number(matchesTransitPreference(b, preference)) -
              Number(matchesTransitPreference(a, preference)),
          );
        setPacket({
          key: routeKey,
          routes: unique,
          error: unique.length ? undefined : 'empty',
        });
      })
      .catch(() => {
        if (active) setPacket({ key: routeKey, routes: [], error: 'route' });
      });
    return () => {
      active = false;
    };
  }, [ready, routeKey, section, lang, preference, departure, needsTime]);

  useEffect(() => {
    const value = engine.current;
    if (!ready || !value) return;
    const { sdk, map } = value;
    const markers: Overlay[] = [];
    const bounds = new sdk.LatLngBounds();
    const seen = new Set<string>();
    points.forEach((p) => {
      if (
        p.id === 'current' ||
        !Number.isFinite(p.lat) ||
        !Number.isFinite(p.lng) ||
        p.unmapped ||
        seen.has(p.id)
      )
        return;
      seen.add(p.id);
      const focused = section.points.some((s) => s.id === p.id);
      const marker = new sdk.Marker({
        map,
        position: { lat: p.lat, lng: p.lng },
        title: `${mapPointLabel(p.id, points)}. ${p.name}`,
        label: {
          text: mapPointLabel(p.id, points),
          color: '#07141d',
          fontWeight: '800',
          fontSize: '13px',
        },
        icon: {
          path: sdk.SymbolPath.CIRCLE,
          scale: focused ? 14 : 11,
          fillColor: focused ? '#72f0cf' : '#a4b1cf',
          fillOpacity: 1,
          strokeColor: '#0a1721',
          strokeWeight: 3,
        },
        zIndex: focused ? 10 : 1,
      });
      marker.addListener('click', () => select.current(p.id));
      markers.push(marker);
      bounds.extend({ lat: p.lat, lng: p.lng });
    });
    if (!live && seen.size) map.fitBounds(bounds, 45);
    return () => {
      markers.forEach((marker) => {
        sdk.event.clearInstanceListeners(marker);
        marker.setMap(null);
      });
    };
  }, [ready, points, section.points, live]);

  useEffect(() => {
    const value = engine.current;
    if (!ready || !value) return;
    const { sdk, map } = value;
    const lines: Overlay[] = [];
    const draw = (
      path: GoogleRoute['path'],
      color: string,
      dashed: boolean,
      width: number,
      index: number,
    ) => {
      if (!path?.length) return;
      const line = new sdk.Polyline({
        map,
        path: path.map((p) => ({ lat: p.lat, lng: p.lng })),
        strokeColor: color,
        strokeOpacity: dashed ? 0 : 1,
        strokeWeight: width,
        zIndex: index === routeIndex ? 5 : 2,
        icons: dashed
          ? [
              {
                icon: {
                  path: 'M 0,-1 0,1',
                  strokeWeight: width,
                  strokeOpacity: 1,
                  strokeColor: color,
                  scale: 2,
                },
                offset: '0',
                repeat: '14px',
              },
            ]
          : undefined,
      });
      line.addListener('click', () => setChoice({ key: routeKey, index }));
      lines.push(line);
    };
    if (chosen) {
      chosen.legs?.forEach((leg, i) => {
        if (section.mode === 'walking')
          draw(
            leg.path,
            routeColors.walking,
            true,
            section.legs[i]?.id === selected ? 7 : 4,
            routeIndex,
          );
        else
          leg.steps?.forEach((step) =>
            draw(
              step.path,
              routeColors[stepMode(step)],
              stepMode(step) === 'walking',
              stepMode(step) === 'walking' ? 5 : 7,
              routeIndex,
            ),
          );
      });
      if (!lines.length && section.mode === 'walking')
        draw(chosen.path, routeColors.walking, true, 6, routeIndex);
      for (const stop of transitStops(chosen)) {
        for (const [kind, point] of [
          ['board', stop.board],
          ['alight', stop.alight],
        ] as const) {
          if (!point.position) continue;
          const action =
            kind === 'board'
              ? w('Embarque aqui', 'Board here', 'Burada binin')[lang]
              : w('Desça aqui', 'Get off here', 'Burada inin')[lang];
          const marker = new sdk.Marker({
            map,
            position: point.position,
            title: `${point.label} · ${action}: ${point.name || ''}`,
            label: {
              text: point.label,
              color: '#1a1230',
              fontWeight: '800',
              fontSize: '13px',
            },
            icon: {
              path: sdk.SymbolPath.CIRCLE,
              scale: 12,
              fillColor: '#d2baff',
              fillOpacity: 1,
              strokeColor: routeColors.transit,
              strokeWeight: 3,
            },
            zIndex: 20,
          });
          marker.addListener('click', () =>
            document
              .getElementById(`transit-stop-${point.label}`)
              ?.scrollIntoView({ behavior: 'smooth', block: 'center' }),
          );
          lines.push(marker);
        }
      }
      if (chosen.viewport && !live) map.fitBounds(chosen.viewport, 50);
    }
    return () => {
      lines.forEach((line) => {
        sdk.event.clearInstanceListeners(line);
        line.setMap(null);
      });
    };
  }, [
    ready,
    routes,
    chosen,
    routeIndex,
    routeKey,
    selected,
    section,
    live,
    lang,
  ]);

  useEffect(() => {
    if (!ready || !engine.current || !live || !nav.fix || nav.stale) return;
    const { sdk, map } = engine.current;
    const position = { lat: nav.fix.lat, lng: nav.fix.lng };
    const circle = new sdk.Circle({
      map,
      center: position,
      radius: nav.fix.accuracy,
      fillColor: '#4ca5ff',
      fillOpacity: 0.12,
      strokeWeight: 1,
      strokeColor: '#68b9ff',
      clickable: false,
    });
    const pin = new sdk.Marker({
      map,
      position,
      title: w('Minha localização', 'My location', 'Konumum')[lang],
      icon: {
        path:
          nav.heading === null
            ? sdk.SymbolPath.CIRCLE
            : sdk.SymbolPath.FORWARD_CLOSED_ARROW,
        rotation: nav.heading || 0,
        scale: nav.heading === null ? 7 : 6,
        fillColor: '#52adff',
        fillOpacity: 1,
        strokeColor: '#ffffff',
        strokeWeight: 2,
      },
      zIndex: 100,
    });
    if (follow.current) map.panTo(position);
    return () => {
      circle.setMap(null);
      pin.setMap(null);
    };
  }, [ready, live, nav.fix, nav.heading, nav.stale, lang]);

  const fitAll = () => {
    if (!engine.current) return;
    const { sdk, map } = engine.current;
    const bounds = new sdk.LatLngBounds();
    points
      .filter((p) => !p.unmapped)
      .forEach((p) => bounds.extend({ lat: p.lat, lng: p.lng }));
    map.fitBounds(bounds, 45);
    follow.current = false;
  };
  return (
    <div className="google-interactive">
      <div
        className="route-map-legend"
        aria-label={
          w('Legenda do trajeto', 'Route legend', 'Rota açıklaması')[lang]
        }
      >
        <span>
          <i className="legend-walk" />
          {
            w('A pé · tracejado', 'Walk · dashed', 'Yürüyüş · kesik çizgi')[
              lang
            ]
          }
        </span>
        <span>
          <i className="legend-transit" />
          {
            w(
              'Transporte · roxo contínuo',
              'Transit · solid purple',
              'Toplu taşıma · düz mor',
            )[lang]
          }
        </span>
        {section.mode === 'transit' && (
          <small>
            {
              w(
                'Letras = embarque e desembarque. Números = lugares do roteiro.',
                'Letters = boarding and exit stops. Numbers = itinerary places.',
                'Harfler = biniş ve iniş durakları. Sayılar = gezilecek yerler.',
              )[lang]
            }
          </small>
        )}
      </div>
      {section.mode === 'transit' && (
        <div className="transit-options">
          <b>
            {
              w(
                'Preferência de transporte',
                'Transport preference',
                'Ulaşım tercihi',
              )[lang]
            }
          </b>
          <fieldset
            className="transit-pills"
            aria-label={
              w(
                'Preferência de transporte',
                'Transport preference',
                'Ulaşım tercihi',
              )[lang]
            }
          >
            {preferences.map((item) => (
              <button
                key={item.id}
                aria-pressed={preference === item.id}
                onClick={() => setPreference(item.id)}
              >
                <item.icon size={19} />
                {item.label[lang]}
              </button>
            ))}
          </fieldset>
          <p>
            {
              w(
                'Todos inclui os meios disponíveis, também balsas. Preferências podem exigir conexões com outros meios.',
                'All includes available services, including ferries. Preferences may require connections using other modes.',
                'Tümü, vapurlar dahil mevcut ulaşımı kapsar. Tercihler diğer araçlarla aktarma gerektirebilir.',
              )[lang]
            }
          </p>
          <div className="transit-day">
            <CalendarDays size={22} />
            <span>
              <small>
                {w('DATA DO ROTEIRO', 'ITINERARY DATE', 'GEZİ TARİHİ')[lang]}
              </small>
              <b>
                {new Intl.DateTimeFormat(lang, {
                  weekday: 'long',
                  day: 'numeric',
                  month: 'long',
                  year: 'numeric',
                  timeZone: 'Europe/Istanbul',
                }).format(new Date(tripDate + 'T12:00:00Z'))}
              </b>
            </span>
          </div>
          <label htmlFor={timeId}>
            {
              w(
                'A que horas vamos sair?',
                'What time shall we leave?',
                'Saat kaçta çıkalım?',
              )[lang]
            }
          </label>
          <div className="transit-time">
            <input
              key={departureContext}
              id={timeId}
              ref={timeInput}
              type="time"
              required
              step="60"
              defaultValue={departureTime}
            />
            <button
              className="button primary"
              onClick={() => {
                if (timeInput.current?.reportValidity()) {
                  setDepartureChoice({
                    context: departureContext,
                    time: timeInput.current.value,
                  });
                  setReload((value) => value + 1);
                }
              }}
            >
              <Clock size={18} />
              {
                w(
                  'Ver opções de transporte',
                  'See transport options',
                  'Ulaşım seçeneklerini gör',
                )[lang]
              }
            </button>
          </div>
          <small>
            {
              (departureTime
                ? w(
                    `Saída às ${departureTime}, no horário de Istambul. A data acompanha o dia selecionado no roteiro.`,
                    `Departure at ${departureTime}, Istanbul time. The date follows the selected itinerary day.`,
                    `Kalkış İstanbul saatiyle ${departureTime}. Tarih, seçili gezi gününü takip eder.`,
                  )
                : w(
                    'A data já está definida. Preencha a hora de saída, no horário de Istambul, para consultar os transportes.',
                    'The date is already set. Enter your departure time in Istanbul time to find transport options.',
                    'Tarih hazır. Ulaşım seçenekleri için İstanbul saatine göre kalkış saatini girin.',
                  ))[lang]
            }
          </small>
        </div>
      )}
      <div className="google-map-stage">
        <div
          ref={host}
          className="google-map"
          aria-label={
            w(
              'Google Maps com locais numerados e rotas',
              'Google Maps with numbered places and routes',
              'Numaralı yerler ve rotalarla Google Maps',
            )[lang]
          }
        />
        {(!ready || failure) && (
          <output className="google-map-loading">
            {failure
              ? w(
                  'O Google Maps não carregou. Confira a conexão e a autorização da Maps JavaScript API.',
                  'Google Maps did not load. Check your connection and Maps JavaScript API authorization.',
                  'Google Maps yüklenmedi. Bağlantıyı ve Maps JavaScript API iznini kontrol edin.',
                )[lang]
              : w(
                  'Abrindo Google Maps…',
                  'Opening Google Maps…',
                  'Google Maps açılıyor…',
                )[lang]}
          </output>
        )}
        {!!ready && (
          <div className="google-map-actions">
            <button
              onClick={fitAll}
              aria-label={
                w(
                  'Ver todas as paradas',
                  'Show all stops',
                  'Tüm durakları göster',
                )[lang]
              }
            >
              <Maximize size={20} />
            </button>
            {live && nav.fix && (
              <button
                aria-label={
                  w(
                    'Seguir minha posição',
                    'Follow my location',
                    'Konumumu takip et',
                  )[lang]
                }
                onClick={() => {
                  follow.current = true;
                  engine.current?.map.panTo(nav.fix!);
                }}
              >
                <LocateFixed size={20} />
              </button>
            )}
          </div>
        )}
      </div>
      {!failure && !needsTime && packet?.key !== routeKey && (
        <output className="google-route-status">
          <RefreshCw className="spin" size={17} />
          {
            w(
              'Calculando o trajeto pelo Google…',
              'Google is calculating the route…',
              'Google rotayı hesaplıyor…',
            )[lang]
          }
        </output>
      )}
      {currentError && (
        <div className="google-route-status" role="alert">
          <p>
            {currentError === 'empty'
              ? w(
                  'Nenhum trajeto disponível para essa preferência e horário. Experimente Todos ou outra saída.',
                  'No route is available for this preference and time. Try All or another departure.',
                  'Bu tercih ve saat için rota yok. Tümü veya başka kalkış deneyin.',
                )[lang]
              : w(
                  'Não foi possível consultar as rotas agora. Tente novamente ou abra este trecho no aplicativo Google Maps abaixo.',
                  'Routes could not be retrieved right now. Try again or open this section in the Google Maps app below.',
                  'Rotalar şu anda alınamadı. Tekrar deneyin veya aşağıdan bu etabı Google Maps uygulamasında açın.',
                )[lang]}
          </p>
          <button
            className="button subtle"
            onClick={() => setReload((v) => v + 1)}
          >
            <RefreshCw size={17} />
            {w('Tentar novamente', 'Try again', 'Tekrar dene')[lang]}
          </button>
        </div>
      )}
      {!!routes.length && (
        <div className="google-route-results">
          {section.mode === 'transit' &&
            preference !== 'ALL' &&
            !routes.some((route) =>
              matchesTransitPreference(route, preference),
            ) && (
              <p className="transit-schedule-note">
                {
                  w(
                    'O Google não encontrou esse meio de transporte para o trecho e horário escolhidos. Estas são as alternativas disponíveis.',
                    'Google did not return that transport mode for the selected leg and time. These are the available alternatives.',
                    'Google seçili etap ve saat için bu ulaşım türünü bulamadı. Mevcut alternatifler aşağıdadır.',
                  )[lang]
                }
              </p>
            )}
          <div className="google-results-heading">
            <b>
              {section.mode === 'transit'
                ? w(
                    'Opções encontradas',
                    'Available options',
                    'Bulunan seçenekler',
                  )[lang]
                : w(
                    'Caminhada com todas as paradas',
                    'Walk through every stop',
                    'Tüm duraklarla yürüyüş',
                  )[lang]}
            </b>
            <small>Google Maps</small>
          </div>
          <GoogleRouteOptions
            routes={routes}
            selected={routeIndex}
            lang={lang}
            onSelect={(index) => setChoice({ key: routeKey, index })}
          />
          {chosen && (
            <GoogleJourneyDirections
              route={chosen}
              section={section}
              points={points}
              lang={lang}
              selected={selected}
              onSelect={onSelect}
              onFocus={(point) => {
                follow.current = false;
                engine.current?.map.panTo(point);
                engine.current?.map.setZoom(17);
                host.current?.scrollIntoView({
                  behavior: 'smooth',
                  block: 'center',
                });
              }}
            />
          )}
          {chosen?.localizedValues?.transitFare && (
            <p className="google-fare">
              {w('Tarifa estimada', 'Estimated fare', 'Tahmini ücret')[lang]}:{' '}
              {chosen.localizedValues.transitFare}
            </p>
          )}
          {section.mode === 'transit' && (
            <p className="transit-schedule-note">
              {
                w(
                  'Horários em Istambul. Consulte novamente no dia; a oferta de linhas e horários pode mudar.',
                  'Times are in Istanbul. Check again on the day; services and schedules can change.',
                  'Saatler İstanbul’a göredir. Hatlar ve saatler değişebilir; yolculuk günü tekrar kontrol edin.',
                )[lang]
              }
            </p>
          )}
          {!!chosen?.warnings?.length && (
            <details className="google-route-warnings">
              <summary>
                {
                  w(
                    'Observações do Google',
                    'Notes from Google',
                    'Google notları',
                  )[lang]
                }
              </summary>
              {chosen.warnings.map((warning, i) => (
                <p key={i}>{warning}</p>
              ))}
            </details>
          )}
        </div>
      )}
    </div>
  );
}

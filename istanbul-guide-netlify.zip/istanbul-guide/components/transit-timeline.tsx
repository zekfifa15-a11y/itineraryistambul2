'use client';
import {
  Footprints,
  MapPin,
  BusFront,
  TrainFront,
  TramFront,
  Ship,
  ArrowDown,
} from 'lucide-react';
import { w, type Lang } from '@/lib/guide';
import type { Coordinate, GoogleRoute } from '@/lib/google-maps-sdk';
import {
  groupRouteSteps,
  transitStops,
  type TransitStopPoint,
} from '@/lib/google-route-presentation';

function Stop({
  point,
  arrival,
  lang,
  onFocus,
}: {
  point: TransitStopPoint;
  arrival?: boolean;
  lang: Lang;
  onFocus: (p: Coordinate) => void;
}) {
  const action = arrival
    ? w('DESÇA AQUI', 'GET OFF HERE', 'BURADA İNİN')[lang]
    : w('EMBARQUE AQUI', 'BOARD HERE', 'BURADA BİNİN')[lang];
  const name =
    point.name ||
    w('Parada informada pelo Google', 'Stop from Google', 'Google durağı')[
      lang
    ];
  return (
    <button
      id={`transit-stop-${point.label}`}
      className={`transit-stop ${arrival ? 'alight' : 'board'}`}
      disabled={!point.position}
      onClick={() => point.position && onFocus(point.position)}
      aria-label={`${action}: ${name} · ${point.label}`}
    >
      <span className="transit-stop-letter">{point.label}</span>
      <span className="transit-stop-name">
        <small>{action}</small>
        <strong>{name}</strong>
      </span>
      <span className="transit-stop-time">
        {point.time &&
          new Intl.DateTimeFormat(lang, {
            timeZone: 'Europe/Istanbul',
            hour: '2-digit',
            minute: '2-digit',
          }).format(point.time)}
        <MapPin size={16} />
      </span>
    </button>
  );
}
export function TransitTimeline({
  route,
  legIndex,
  destination,
  lang,
  onFocus,
}: {
  route: GoogleRoute;
  legIndex: number;
  destination: string;
  lang: Lang;
  onFocus: (p: Coordinate) => void;
}) {
  const groups = groupRouteSteps(route.legs?.[legIndex]?.steps ?? []);
  const stops = transitStops(route).filter((s) => s.legIndex === legIndex);
  return (
    <ol className="transit-timeline">
      {groups.map((group, index) => {
        const next = groups[index + 1];
        const nextStop = stops.find((s) => s.stepIndex === next?.index);
        const ride = group.steps[0];
        const transit = ride.transitDetails;
        const stop = stops.find((s) => s.stepIndex === group.index);
        const minutes = Math.ceil(
          group.steps.reduce(
            (sum, s) => sum + (s.staticDurationMillis || 0),
            0,
          ) / 60000,
        );
        const meters = group.steps.reduce(
          (sum, s) => sum + (s.distanceMeters || 0),
          0,
        );
        const vehicle = transit?.transitLine?.vehicle?.vehicleType || '';
        const Icon = vehicle.includes('BUS')
          ? BusFront
          : vehicle === 'TRAM' || vehicle === 'LIGHT_RAIL'
            ? TramFront
            : vehicle === 'FERRY'
              ? Ship
              : TrainFront;
        if (group.mode === 'transit' && stop)
          return (
            <li key={group.index} className="timeline-ride">
              <Stop point={stop.board} lang={lang} onFocus={onFocus} />
              <div className="transit-ride-info">
                <div className="ride-line">
                  <Icon size={22} />
                  <span className="transit-line-badge">
                    {transit?.transitLine?.shortName ||
                      transit?.transitLine?.name ||
                      w(
                        'Transporte público',
                        'Public transport',
                        'Toplu taşıma',
                      )[lang]}
                  </span>
                  <span>{transit?.transitLine?.vehicle?.name}</span>
                </div>
                {transit?.headsign && (
                  <p>
                    <ArrowDown size={16} />
                    {w('Sentido', 'Towards', 'Yön')[lang]}{' '}
                    <strong>{transit.headsign}</strong>
                  </p>
                )}
                <p className="ride-duration">
                  {minutes > 0 && `${minutes} min`}
                  {minutes > 0 && transit?.stopCount !== undefined && ' · '}
                  {transit?.stopCount !== undefined &&
                    `${transit.stopCount} ${w('paradas', 'stops', 'durak')[lang]}`}
                </p>
                <small>
                  {
                    w(
                      'Permaneça no transporte até a parada abaixo.',
                      'Stay on board until the stop below.',
                      'Aşağıdaki durağa kadar araçta kalın.',
                    )[lang]
                  }
                </small>
              </div>
              <Stop point={stop.alight} arrival lang={lang} onFocus={onFocus} />
            </li>
          );
        const target =
          nextStop?.board.name ||
          (index === groups.length - 1 ? destination : undefined);
        return (
          <li key={group.index} className="timeline-walk">
            <div className="walk-title">
              <Footprints size={21} />
              <strong>
                {group.mode === 'walking'
                  ? index > 0
                    ? w(
                        'Continue a pé',
                        'Continue on foot',
                        'Yürüyerek devam edin',
                      )[lang]
                    : w('Vá a pé', 'Walk', 'Yürüyün')[lang]
                  : w(
                      'Siga as orientações',
                      'Follow directions',
                      'Yönergeleri izleyin',
                    )[lang]}
              </strong>
            </div>
            {target && (
              <p>
                {w('Até', 'To', 'Hedef')[lang]} <strong>{target}</strong>
                {nextStop && (
                  <span className="walk-target-letter">
                    {nextStop.board.label}
                  </span>
                )}
              </p>
            )}
            <span className="walk-distance">
              {minutes > 0 && `${minutes} min`}
              {minutes > 0 && meters > 0 && ' · '}
              {meters > 0 && `${meters} m`}
            </span>
            <details className="walking-instructions">
              <summary>
                {
                  w(
                    'Ver ruas e conversões',
                    'Show streets and turns',
                    'Sokakları ve dönüşleri göster',
                  )[lang]
                }
              </summary>
              <ol>
                {group.steps.map((step, i) => (
                  <li key={i}>
                    {step.instructions ||
                      w(
                        'Siga o trajeto no mapa.',
                        'Follow the route on the map.',
                        'Haritadaki rotayı izleyin.',
                      )[lang]}
                  </li>
                ))}
              </ol>
            </details>
          </li>
        );
      })}
    </ol>
  );
}

'use client';
import { Children, isValidElement, type ReactNode } from 'react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
type Props = {
  children: ReactNode;
  value: string | number;
  onChange: (event: { target: { value: string } }) => void;
  className?: string;
  disabled?: boolean;
  'aria-label'?: string;
};
// Keep the guide's option labels while rendering an accessible, consistently themed popup.
export function GuideSelect({
  children,
  value,
  onChange,
  className,
  disabled,
  'aria-label': label,
}: Props) {
  const options = Children.toArray(children)
    .filter(
      isValidElement<{
        value: string | number;
        children: ReactNode;
        disabled?: boolean;
      }>,
    )
    .map((child) => ({
      value: String(child.props.value),
      label: child.props.children,
      disabled: child.props.disabled,
    }));
  return (
    <div data-slot="native-select-wrapper" className={className}>
      <Select
        value={String(value)}
        items={options}
        disabled={disabled}
        onValueChange={(v) => {
          if (v !== null) onChange({ target: { value: v } });
        }}
      >
        <SelectTrigger
          data-slot="native-select"
          className="guide-select-trigger"
          aria-label={label}
        >
          <SelectValue />
        </SelectTrigger>
        <SelectContent
          className="guide-select-popup"
          positionerClassName="guide-select-positioner"
          align="start"
          alignItemWithTrigger={false}
        >
          {options.map((option) => (
            <SelectItem
              key={option.value}
              value={option.value}
              disabled={option.disabled}
            >
              {option.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}

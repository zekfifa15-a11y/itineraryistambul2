'use client';
import { useCallback, useEffect, useMemo, useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import {
  ArrowUpRight,
  ArrowRight,
  MapPin,
  Navigation,
  Check,
  Compass,
  CalendarDays,
  GraduationCap,
  Utensils,
  ShoppingBag,
  Landmark,
  Ship,
  Home,
  Search,
  LocateFixed,
  Heart,
  Clock,
  Info,
  ChevronLeft,
  ChevronRight,
  Printer,
  CheckCheck,
  BookOpen,
} from 'lucide-react';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select';
import TripMap from '@/components/trip-map';
import {
  places,
  byId,
  days,
  universityPlans,
  universityOrigin,
  mapsUrl,
  distance,
  Lang,
  Place,
  Kind,
} from '@/lib/trip';
import photos from '@/lib/photo-list.json';
const photoById = Object.fromEntries(photos.map((p) => [p.id, p]));
const locales = { pt: 'pt-BR', en: 'en-GB', tr: 'tr-TR' };
const iconByKind = {
  food: Utensils,
  shop: ShoppingBag,
  sight: Landmark,
  transport: Ship,
  base: Home,
};
type Context = {
  registerTool: (
    tool: {
      name: string;
      title: string;
      description: string;
      inputSchema: object;
      annotations: object;
      execute: (input: unknown) => unknown;
    },
    options: { signal: AbortSignal },
  ) => unknown;
};
export default function TravelGuide() {
  const [lang, setLang] = useState<Lang>('pt');
  const t = (pt: string, en: string, tr: string) => ({ pt, en, tr })[lang];
  const [tab, setTab] = useState('itinerary');
  const [dayIndex, setDayIndex] = useState(1);
  const [uniIndex, setUniIndex] = useState(0);
  const [category, setCategory] = useState('all');
  const [search, setSearch] = useState('');
  const [localOnly, setLocalOnly] = useState(false);
  const [pendingOnly, setPendingOnly] = useState(false);
  const [selected, setSelected] = useState('galata');
  const [mapStyle, setMapStyle] = useState('route');
  const [mode, setMode] = useState('walking');
  const [visited, setVisited] = useState<Record<string, boolean>>({});
  const [saving, setSaving] = useState<Record<string, boolean>>({});
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState(false);
  const [location, setLocation] = useState<{ lat: number; lng: number }>();
  const [locStatus, setLocStatus] = useState('');
  useEffect(() => {
    try {
      const l = localStorage.getItem('istanbul-language');
      if (l === 'pt' || l === 'en' || l === 'tr')
        queueMicrotask(() => setLang(l));
    } catch {}
  }, []);
  useEffect(() => {
    document.documentElement.lang = locales[lang];
    try {
      localStorage.setItem('istanbul-language', lang);
    } catch {}
  }, [lang]);
  const refresh = useCallback(async () => {
    try {
      const res = await fetch('/api/progress', { cache: 'no-store' });
      if (!res.ok) throw Error();
      const data = (await res.json()) as { visited: Record<string, boolean> };
      setVisited(data.visited);
      setLoaded(true);
      setError(false);
    } catch {
      setError(true);
    }
  }, []);
  useEffect(() => {
    const timer = setTimeout(() => void refresh(), 0);
    const onFocus = () => void refresh();
    window.addEventListener('focus', onFocus);
    return () => {
      clearTimeout(timer);
      window.removeEventListener('focus', onFocus);
    };
  }, [refresh]);
  const mark = useCallback(async (id: string, done: boolean) => {
    if (!Object.hasOwn(byId, id) || byId[id].kind === 'base')
      throw Error('Invalid place');
    setSaving((s) => ({ ...s, [id]: true }));
    try {
      const res = await fetch('/api/progress', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, done }),
      });
      if (!res.ok) throw Error('Save failed');
      setVisited((s) => ({ ...s, [id]: done }));
      setError(false);
      return { id, done };
    } catch (e) {
      setError(true);
      throw e;
    } finally {
      setSaving((s) => ({ ...s, [id]: false }));
    }
  }, []);
  useEffect(() => {
    const ctx = (document as Document & { modelContext?: Context })
      .modelContext;
    if (!ctx?.registerTool) return;
    const lifecycle = new AbortController();
    const defs = [
      {
        name: 'get_istanbul_trip',
        title: 'Read Istanbul itinerary',
        description: 'Read places, daily itinerary and saved visit progress.',
        inputSchema: {
          type: 'object',
          properties: {},
          additionalProperties: false,
        },
        annotations: { readOnlyHint: true, untrustedContentHint: false },
        execute: async () => {
          const res = await fetch('/api/progress', { cache: 'no-store' });
          if (!res.ok) throw Error('Progress unavailable');
          return {
            places: places.map(({ id, name }) => ({ id, name })),
            days: days.map((d) => ({ date: d.date, stops: d.stops })),
            ...((await res.json()) as { visited: Record<string, boolean> }),
          };
        },
      },
      {
        name: 'set_istanbul_place_visited',
        title: 'Mark an Istanbul place visited',
        description:
          'Save or undo a place visit in the same checklist shown in this guide.',
        inputSchema: {
          type: 'object',
          properties: { id: { type: 'string' }, done: { type: 'boolean' } },
          required: ['id', 'done'],
          additionalProperties: false,
        },
        annotations: { readOnlyHint: false, untrustedContentHint: false },
        execute: async (input: unknown) => {
          if (!input || typeof input !== 'object') throw Error('Invalid input');
          const v = input as { id: unknown; done: unknown };
          if (typeof v.id !== 'string' || typeof v.done !== 'boolean')
            throw Error('Invalid input');
          return mark(v.id, v.done);
        },
      },
    ];
    for (const def of defs) {
      try {
        void Promise.resolve(
          ctx.registerTool(def, { signal: lifecycle.signal }),
        ).catch(() => {});
      } catch {}
    }
    return () => lifecycle.abort();
  }, [mark]);
  const day = days[dayIndex];
  const uni = universityPlans[uniIndex];
  const chosen = byId[selected] || byId.galata;
  const filtered = useMemo(
    () =>
      places
        .filter((p) => p.kind !== 'base')
        .filter(
          (p) =>
            category === 'all' ||
            (category === 'saved' && p.saved) ||
            p.kind === category,
        )
        .filter(
          (p) =>
            !search ||
            `${p.name} ${p.area} ${p.description[lang]}`
              .toLocaleLowerCase(locales[lang])
              .includes(search.toLocaleLowerCase(locales[lang])),
        )
        .filter(
          (p) =>
            !localOnly ||
            (p.kind === 'food' &&
              (p.rating ?? 0) > 4.4 &&
              !p.unmapped &&
              distance(byId.base, p) <= 2),
        )
        .filter((p) => !pendingOnly || !visited[p.id]),
    [category, search, lang, localOnly, pendingOnly, visited],
  );
  const routePlaces = useMemo(
    () =>
      tab === 'university'
        ? [byId.university, ...uni.ids.map((id) => byId[id])]
        : tab === 'explore'
          ? filtered
          : day.stops.map((s) => byId[s.id]),
    [tab, uni, filtered, day],
  );
  const mapPlaces = useMemo(() => {
    const list = routePlaces.filter((p) => !p.unmapped);
    const anchor = tab === 'university' ? byId.university : byId.base;
    return list.some((p) => p.id === anchor.id) ? list : [...list, anchor];
  }, [routePlaces, tab]);
  const completed = places.filter(
    (p) => p.kind !== 'base' && visited[p.id],
  ).length;
  const total = places.filter((p) => p.kind !== 'base').length;
  const dayDone = day.stops.filter(
    (s) => byId[s.id].kind !== 'base' && visited[s.id],
  ).length;
  const dayTotal = day.stops.filter((s) => byId[s.id].kind !== 'base').length;
  const selectDay = (i: number) => {
    setDayIndex(i);
    setSelected(days[i].stops.find((s) => !byId[s.id].unmapped)?.id || 'base');
  };
  const switchTab = (value: unknown) => {
    const v = String(value);
    setTab(v);
    setSelected(
      v === 'university'
        ? 'university'
        : v === 'explore'
          ? filtered[0]?.id || 'base'
          : day.stops[0]?.id || 'base',
    );
  };
  const locate = () => {
    if (!navigator.geolocation) {
      setLocStatus('unsupported');
      return;
    }
    setLocStatus('loading');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setLocStatus(
          distance(byId.base, {
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
          }) > 100
            ? 'far'
            : 'ready',
        );
      },
      () => setLocStatus('denied'),
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 },
    );
  };
  const labels: Record<Kind, string> = {
    sight: t('Atração', 'Sight', 'Görülecek yer'),
    food: t('Comer & beber', 'Food & drink', 'Yeme içme'),
    shop: t('Compras', 'Shopping', 'Alışveriş'),
    transport: t('Balsa & passeio', 'Ferry & cruise', 'Vapur ve tur'),
    base: t('Referência', 'Anchor', 'Başlangıç'),
  };
  function renderPhoto({
    photoId,
    place,
    large = false,
  }: {
    photoId: string;
    place: Place;
    large?: boolean;
  }) {
    const photo = photoById[photoId];
    if (!photo) return null;
    return (
      <figure className={large ? 'cover-photo' : 'place-photo'}>
        <a
          href={place.unmapped ? place.source : mapsUrl(place, mode)}
          target="_blank"
          rel="noreferrer"
          aria-label={`${t('Abrir rota para', 'Open directions to', 'Yol tarifini aç')}: ${place.name}`}
        >
          <Image
            unoptimized
            width={1280}
            height={800}
            src={photo.imageUrl}
            alt={photo.place}
            loading={large ? 'eager' : 'lazy'}
            onError={(e) => {
              e.currentTarget.style.opacity = '0';
            }}
          />
          <span className="photo-route">
            <MapPin size={13} />
            {t('Foto → rota', 'Photo → route', 'Fotoğraf → rota')}
            <ArrowUpRight size={13} />
          </span>
        </a>
        <figcaption>
          <a href={photo.sourceUrl} target="_blank" rel="noreferrer">
            {photo.photographer}
          </a>{' '}
          ·{' '}
          <a href={photo.licenseUrl} target="_blank" rel="noreferrer">
            {photo.license}
          </a>
        </figcaption>
      </figure>
    );
  }
  function renderPlaceCard({
    p,
    index,
    time,
  }: {
    p: Place;
    index: number;
    time?: string;
  }) {
    const Icon = iconByKind[p.kind];
    return (
      <article
        key={p.id}
        className={`place-card ${selected === p.id ? 'selected-card' : ''} ${visited[p.id] ? 'visited-card' : ''}`}
        id={`place-${p.id}`}
      >
        <div className="stop-rail">
          <span className="stop-number">
            {visited[p.id] ? <Check size={14} /> : index + 1}
          </span>
          {time && <time>{time}</time>}
        </div>
        <div className="place-body">
          <div className="place-meta">
            <span>
              <Icon size={12} />
              {labels[p.kind]}
            </span>
            {p.saved && (
              <span className="saved-tag">
                <Heart size={11} />
                {t('Sua lista', 'Your list', 'Listeniz')}
              </span>
            )}
            {p.rating && (
              <a
                href={p.source || mapsUrl(p)}
                target="_blank"
                rel="noreferrer"
                className={`rating ${p.rating <= 4.4 ? 'exception' : ''}`}
              >
                ★ {p.rating.toFixed(1)}
              </a>
            )}
          </div>
          <div className="place-title-row">
            <button className="place-title" onClick={() => setSelected(p.id)}>
              {p.name}
            </button>
            {p.kind !== 'base' && (
              <Checkbox
                checked={!!visited[p.id]}
                disabled={!loaded || !!saving[p.id]}
                onCheckedChange={(v) => {
                  void mark(p.id, !!v).catch(() => {});
                }}
                aria-label={`${visited[p.id] ? t('Desmarcar', 'Uncheck', 'İşareti kaldır') : t('Marcar como visitado', 'Mark visited', 'Ziyaret edildi olarak işaretle')}: ${p.name}`}
                className="visit-checkbox"
              />
            )}
          </div>
          <div className="place-area">
            {p.area}
            {!p.unmapped && p.kind !== 'base' && (
              <>
                {' '}
                · ≈{' '}
                {distance(
                  tab === 'university' ? byId.university : byId.base,
                  p,
                ).toFixed(1)}{' '}
                km {t('em linha reta', 'straight line', 'kuş uçuşu')}
              </>
            )}
          </div>
          <p>{p.description[lang]}</p>
          {p.photo && renderPhoto({ photoId: p.photo, place: p })}
          <div className="place-actions">
            {p.unmapped ? (
              <a
                href={p.source}
                target="_blank"
                rel="noreferrer"
                className="route-link"
              >
                <Ship size={14} />
                {t(
                  'Abrir passeio escolhido',
                  'Open selected cruise',
                  'Seçilen turu aç',
                )}
                <ArrowUpRight size={14} />
              </a>
            ) : (
              <a
                href={mapsUrl(p, mode)}
                target="_blank"
                rel="noreferrer"
                className="route-link"
              >
                <Navigation size={14} />
                {t('Ir de onde estou', 'Go from my location', 'Konumumdan git')}
                <ArrowUpRight size={14} />
              </a>
            )}
            <button
              className="text-button"
              onClick={() => {
                setSelected(p.id);
                document
                  .getElementById('trip-map-panel')
                  ?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
              }}
              disabled={p.unmapped}
            >
              {t('Ver no mapa', 'Show on map', 'Haritada göster')}
            </button>
          </div>
        </div>
      </article>
    );
  }
  return (
    <div className="travel-app">
      <header className="topbar">
        <Link href="/" className="brand" aria-label="İstanbul a dois">
          <span className="brand-icon">
            <Compass size={23} />
          </span>
          <span>
            İSTANBUL
            <span className="brand-sub">
              {t('A DOIS', 'TOGETHER', 'BİRLİKTE')}
            </span>
          </span>
        </Link>
        <div className="trip-ident">
          <span className="mini-dot" />
          Samuel & Zeynep
          <span className="trip-season">
            {t('OUTONO 2026', 'AUTUMN 2026', 'SONBAHAR 2026')}
          </span>
        </div>
        <div className="header-actions">
          <button
            className="icon-button print-button"
            onClick={() => window.print()}
            aria-label={t('Imprimir guia', 'Print guide', 'Rehberi yazdır')}
          >
            <Printer size={17} />
          </button>
          <Select
            value={lang}
            onValueChange={(v) => {
              if (v === 'pt' || v === 'en' || v === 'tr') setLang(v);
            }}
          >
            <SelectTrigger
              aria-label={t('Idioma', 'Language', 'Dil')}
              className="language-select"
            >
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="pt">PT · Português</SelectItem>
              <SelectItem value="en">EN · English</SelectItem>
              <SelectItem value="tr">TR · Türkçe</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </header>
      <div className="workspace">
        <section className="trip-intro">
          <div>
            <div className="eyebrow">
              {t(
                'SEU CADERNO DE VIAGEM',
                'YOUR TRAVEL NOTEBOOK',
                'SEYAHAT DEFTERİNİZ',
              )}
            </div>
            <h1>
              {t(
                'A cidade é de vocês.',
                'Make the city yours.',
                'Şehir sizin olsun.',
              )}
            </h1>
            <p>
              {t(
                'Duas margens. Novos sabores. Bons caminhos.',
                'Two shores. New flavors. Good journeys.',
                'İki kıyı. Yeni tatlar. Güzel yollar.',
              )}
            </p>
            <div className="trip-facts">
              <span>
                <CalendarDays size={14} />
                {t(
                  '20 out — 03 nov',
                  '20 Oct — 03 Nov',
                  '20 Eki — 03 Kas',
                )}{' '}
                2026
              </span>
              <a href={mapsUrl(byId.base)} target="_blank" rel="noreferrer">
                <Home size={14} />
                Galata · Airbnb
                <ArrowUpRight size={12} />
              </a>
              <span>
                <Utensils size={14} />
                {t('Sem frutos do mar', 'No seafood', 'Deniz ürünü yok')}
              </span>
            </div>
          </div>
          <div className="trip-progress">
            <div className="progress-kicker">
              <CheckCheck size={17} />
              {t('MEMÓRIAS CONQUISTADAS', 'MEMORIES MADE', 'BİRİKEN ANILAR')}
            </div>
            <div className="progress-count">
              {loaded ? completed : '—'}
              <span>/ {total}</span>
            </div>
            <div className="progress-track">
              <span style={{ width: `${(completed / total) * 100}%` }} />
            </div>
            <small>
              {t(
                'Marque os lugares que já visitaram.',
                'Check off the places you have visited.',
                'Gezdiğiniz yerleri işaretleyin.',
              )}
            </small>
          </div>
        </section>
        <Tabs value={tab} onValueChange={switchTab} className="main-tabs">
          <div className="nav-row">
            <TabsList className="nav-list" variant="line">
              <TabsTrigger value="itinerary">
                <CalendarDays size={16} />
                {t('Roteiro', 'Itinerary', 'Program')}
              </TabsTrigger>
              <TabsTrigger value="explore">
                <Compass size={16} />
                {t('Explorar', 'Explore', 'Keşfet')}
              </TabsTrigger>
              <TabsTrigger value="university">
                <GraduationCap size={17} />
                {t(
                  'Intervalo da Zeynep',
                  'Zeynep’s class break',
                  'Zeynep dersteyken',
                )}
                <span className="tab-pill">1h20</span>
              </TabsTrigger>
              <TabsTrigger value="practical">
                <BookOpen size={16} />
                {t('Essenciais', 'Essentials', 'Pratik bilgiler')}
              </TabsTrigger>
            </TabsList>
            <output className={`save-state ${error ? 'save-error' : ''}`}>
              {error ? (
                <button onClick={() => void refresh()}>
                  {t(
                    'Falha ao salvar/carregar · tentar novamente',
                    'Save/load failed · retry',
                    'Kayıt/yükleme başarısız · tekrar dene',
                  )}
                </button>
              ) : (
                <>
                  {loaded ? <Check size={13} /> : <Clock size={13} />}{' '}
                  {Object.values(saving).some(Boolean)
                    ? t('Salvando…', 'Saving…', 'Kaydediliyor…')
                    : loaded
                      ? t(
                          'Checklist salvo',
                          'Checklist saved',
                          'Liste kaydedildi',
                        )
                      : t(
                          'Carregando checklist…',
                          'Loading checklist…',
                          'Liste yükleniyor…',
                        )}
                </>
              )}
            </output>
          </div>
        </Tabs>
        {tab === 'itinerary' && (
          <nav
            className="date-rail"
            aria-label={t('Dias da viagem', 'Trip dates', 'Gezi günleri')}
          >
            {days.map((d, i) => (
              <button
                key={d.date}
                className={`date-item ${i === dayIndex ? 'active-date' : ''}`}
                aria-pressed={i === dayIndex}
                onClick={() => selectDay(i)}
              >
                <span>
                  {new Date(d.date + 'T12:00:00').toLocaleDateString(
                    locales[lang],
                    { weekday: 'short' },
                  )}
                </span>
                <strong>{d.date.slice(8)}</strong>
                <small>
                  {new Date(d.date + 'T12:00:00').toLocaleDateString(
                    locales[lang],
                    { month: 'short' },
                  )}
                </small>
                {d.stops.some((s) => visited[s.id]) && (
                  <span className="date-dot" />
                )}
              </button>
            ))}
          </nav>
        )}
        {tab === 'practical' ? (
          <section className="essentials">
            <div className="section-heading">
              <div className="eyebrow">
                {t('PARA VIAJAR BEM', 'TRAVEL WELL', 'İYİ BİR SEYAHAT İÇİN')}
              </div>
              <h2>
                {t(
                  'Os detalhes que fazem diferença.',
                  'The details that make a difference.',
                  'Fark yaratan ayrıntılar.',
                )}
              </h2>
            </div>
            <div className="essential-grid">
              <div className="essential-card">
                <Utensils />
                <h3>
                  {t(
                    'Orçamento para dois',
                    'Budget for two',
                    'İki kişilik bütçe',
                  )}
                </h3>
                <strong className="budget-number">
                  R$ 500 <span>/ {t('dia', 'day', 'gün')}</span>
                </strong>
                <p>
                  {t(
                    'Tratado como teto de alimentação do casal. Planejem cerca de 4.500 liras e mantenham margem; R$ 500 e 5.000 liras não são uma equivalência fixa.',
                    'Treated as the couple’s daily food ceiling. Plan around 4,500 lira and keep a buffer; R$500 and 5,000 lira are not a fixed conversion.',
                    'Çiftin günlük yemek üst sınırı olarak ele alındı. Yaklaşık 4.500 lira planlayıp pay bırakın; R$500 ile 5.000 lira sabit bir kur değildir.',
                  )}
                </p>
                <p>
                  {t(
                    'Sugestão de divisão, não preços dos locais: café 900 ₺, almoço 1.100 ₺, jantar 1.700 ₺, lanches 500 ₺ e margem 300 ₺. Ingressos, iate, transporte e compras ficam à parte.',
                    'Suggested allocation, not venue prices: breakfast ₺900, lunch ₺1,100, dinner ₺1,700, snacks ₺500 and buffer ₺300. Tickets, yacht, transport and shopping are separate.',
                    'Mekân fiyatı değil, önerilen dağılım: kahvaltı 900 ₺, öğle 1.100 ₺, akşam 1.700 ₺, atıştırmalık 500 ₺, pay 300 ₺. Bilet, yat, ulaşım ve alışveriş ayrı.',
                  )}
                </p>
                <a
                  href="https://wise.com/br/currency-converter/brl-to-try-rate"
                  target="_blank"
                  rel="noreferrer"
                >
                  {t(
                    'Conferir câmbio',
                    'Check exchange rate',
                    'Kuru kontrol et',
                  )}{' '}
                  ↗
                </a>
              </div>
              <div className="essential-card">
                <Ship />
                <h3>{t('Deslocamentos', 'Getting around', 'Ulaşım')}</h3>
                <p>
                  {t(
                    'T1: Karaköy → Sultanahmet ou Kabataş. T5: Eminönü → Fener/Balat. M2: Şişhane → Vezneciler para a faculdade. Compre e carregue Istanbulkart.',
                    'T1: Karaköy → Sultanahmet or Kabataş. T5: Eminönü → Fener/Balat. M2: Şişhane → Vezneciler for the faculty. Buy and top up an Istanbulkart.',
                    'T1: Karaköy → Sultanahmet veya Kabataş. T5: Eminönü → Fener/Balat. Fakülte için M2: Şişhane → Vezneciler. İstanbulkart alıp bakiye yükleyin.',
                  )}
                </p>
                <p>
                  {t(
                    'Use o modo transporte no Google Maps para cruzar o Bósforo. Confira a última balsa; as linhas no mapa do guia indicam ordem, não ruas ou navegação real.',
                    'Use Google Maps transit mode to cross the Bosphorus. Check the last ferry; guide map lines indicate order, not actual streets or navigation.',
                    'Boğaz geçişinde Google Maps toplu taşıma modunu kullanın. Son vapuru kontrol edin; rehberdeki çizgiler gerçek yolları değil ziyaret sırasını gösterir.',
                  )}
                </p>
                <div className="source-links">
                  <a
                    href="https://www.metro.istanbul/en/Hatlarimiz/HatDetay?hat=M2"
                    target="_blank"
                    rel="noreferrer"
                  >
                    Metro İstanbul ↗
                  </a>
                  <a
                    href="https://sehirhatlari.istanbul/en/timetables"
                    target="_blank"
                    rel="noreferrer"
                  >
                    Şehir Hatları ↗
                  </a>
                </div>
              </div>
              <div className="essential-card">
                <ShoppingBag />
                <h3>
                  {t(
                    'A geladeira do Airbnb',
                    'Stock the Airbnb fridge',
                    'Airbnb buzdolabını doldurun',
                  )}
                </h3>
                <p>
                  {t(
                    'CarrefourSA Necatibey para o dia a dia. Macrocenter Galataport para produtos especiais. Namlı Gurme para queijos e azeitonas. Procure também Migros, ŞOK e BİM no Maps para comparar preços perto de onde estiver.',
                    'CarrefourSA Necatibey for daily groceries. Macrocenter Galataport for special products. Namlı Gurme for cheese and olives. Also search Maps for Migros, ŞOK and BİM near you to compare prices.',
                    'Günlük alışveriş için CarrefourSA Necatibey. Özel ürünler için Macrocenter Galataport. Peynir ve zeytin için Namlı Gurme. Fiyat karşılaştırmak için yakınınızdaki Migros, ŞOK ve BİM’i de Maps’te arayın.',
                  )}
                </p>
                <button
                  className="route-link"
                  onClick={() => {
                    setCategory('shop');
                    setLocalOnly(false);
                    switchTab('explore');
                  }}
                >
                  {t(
                    'Ver mercados no mapa',
                    'See groceries on map',
                    'Marketleri haritada gör',
                  )}
                  <ArrowRight size={14} />
                </button>
              </div>
              <div className="essential-card phrase-card">
                <Heart />
                <h3>
                  {t(
                    'Sua frase em turco',
                    'Your Turkish phrase',
                    'Kullanabileceğiniz cümle',
                  )}
                </h3>
                <blockquote>
                  Deniz ürünleri yemiyorum. Balık, karides, midye ve kalamar
                  olmasın lütfen.
                </blockquote>
                <p>
                  {t(
                    '“Não como frutos do mar. Sem peixe, camarão, mexilhão e lula, por favor.” Incluímos peixe por precaução na seleção.',
                    '“I do not eat seafood. No fish, shrimp, mussels or squid, please.” Fish was also excluded from the selection as a precaution.',
                    '“Deniz ürünleri yemiyorum. Balık, karides, midye ve kalamar olmasın lütfen.” Seçimde tedbir olarak balık da dışarıda bırakıldı.',
                  )}
                </p>
                <p>
                  {t(
                    'Prefira kebab, köfte, pide, lahmacun, vegetais e pratos de carne ou frango. Não foi indicada alergia.',
                    'Choose kebab, köfte, pide, lahmacun, vegetables and meat or chicken dishes. No allergy was reported.',
                    'Kebap, köfte, pide, lahmacun, sebze ve et veya tavuk yemeklerini tercih edin. Alerji bildirilmedi.',
                  )}
                </p>
              </div>
              <div className="essential-card">
                <CalendarDays />
                <h3>
                  {t(
                    'Agenda sem surpresas',
                    'Plan around closures',
                    'Kapanışlara göre planlayın',
                  )}
                </h3>
                <p>
                  {t(
                    'Topkapı fecha terça; Dolmabahçe e İstanbul Modern fecham segunda. Grand Bazaar fecha domingo. 29/10 é Dia da República: confirme acessos e horários.',
                    'Topkapı closes Tuesday; Dolmabahçe and İstanbul Modern close Monday. Grand Bazaar closes Sunday. October 29 is Republic Day: check access and opening hours.',
                    'Topkapı salı; Dolmabahçe ve İstanbul Modern pazartesi kapalı. Kapalıçarşı pazar kapalı. 29 Ekim Cumhuriyet Bayramı: erişimi ve saatleri kontrol edin.',
                  )}
                </p>
                <p>
                  {t(
                    'Os 10 dias principais ficam entre 21 e 30/10. Chegada, partida e três dias extras completam 20/10–03/11. Datas são sugestões, não reservas.',
                    'The 10 core days run October 21–30. Arrival, departure and three extra days complete October 20–November 3. Dates are suggestions, not bookings.',
                    '10 ana gün 21–30 Ekim arasında. Varış, ayrılış ve üç ek günle 20 Ekim–3 Kasım tamamlanır. Tarihler öneridir, rezervasyon değildir.',
                  )}
                </p>
              </div>
              <div className="essential-card">
                <Info />
                <h3>
                  {t(
                    'Como usar este guia',
                    'How to use this guide',
                    'Rehber nasıl kullanılır',
                  )}
                </h3>
                <p>
                  {t(
                    'Toque numa foto ou em “Ir de onde estou” para abrir o Google Maps. O Google solicita a localização se necessário. Use “Localizar” para se ver no mapa deste guia.',
                    'Tap a photo or “Go from my location” to open Google Maps. Google asks for location if needed. Use “Locate me” to see yourself on this guide’s map.',
                    'Google Maps’i açmak için fotoğrafa veya “Konumumdan git”e dokunun. Google gerektiğinde konum ister. Bu haritada kendinizi görmek için “Konumumu bul”u kullanın.',
                  )}
                </p>
                <p>
                  {t(
                    'O checklist fica salvo na conta deste guia privado. Mapas, fotos e salvamento precisam de internet. Sua localização não é salva por este guia.',
                    'The checklist is saved to this private guide’s account. Maps, photos and saving need internet. This guide does not store your location.',
                    'Liste bu özel rehberin hesabına kaydedilir. Haritalar, fotoğraflar ve kayıt için internet gerekir. Bu rehber konumunuzu saklamaz.',
                  )}
                </p>
              </div>
            </div>
            <details className="sources-details">
              <summary>
                {t(
                  'Fontes, notas e créditos de fotos',
                  'Sources, ratings and photo credits',
                  'Kaynaklar, puanlar ve fotoğraf bilgileri',
                )}
              </summary>
              <p>
                {t(
                  'Pesquisa: 8–9 de setembro de 2026. Notas do Google reproduzidas pelas fontes vinculadas; não são dados ao vivo. Quando não foi possível validar, a nota foi omitida. Distâncias em linha reta e pins aproximados; confira as entradas no Google Maps. Fotos podem ter enquadramento recortado na exibição.',
                  'Research: September 8–9, 2026. Google ratings reproduced by linked sources; these are not live data. Unvalidated ratings are omitted. Distances are straight-line estimates and pins approximate; check entrances in Google Maps. Photos may be cropped in display.',
                  'Araştırma: 8–9 Eylül 2026. Bağlantılı kaynakların aktardığı Google puanları canlı veri değildir. Doğrulanamayan puanlar gösterilmedi. Mesafeler kuş uçuşu tahmini, işaretler yaklaşık; girişleri Google Maps’te kontrol edin. Fotoğraflar gösterimde kırpılabilir.',
                )}
              </p>
              <div className="credits-grid">
                {places
                  .filter((p) => p.source)
                  .map((p) => (
                    <a
                      key={p.id}
                      href={p.source}
                      target="_blank"
                      rel="noreferrer"
                    >
                      {p.name} ↗
                    </a>
                  ))}
              </div>
              <h4>{t('Fotografia', 'Photography', 'Fotoğraflar')}</h4>
              <div className="credits-grid">
                {photos.map((p) => (
                  <span key={p.id}>
                    <a href={p.sourceUrl} target="_blank" rel="noreferrer">
                      {p.place} · {p.photographer}
                    </a>{' '}
                    ·{' '}
                    <a href={p.licenseUrl} target="_blank" rel="noreferrer">
                      {p.license}
                    </a>
                  </span>
                ))}
              </div>
            </details>
          </section>
        ) : (
          <div className="guide-grid">
            <section className="itinerary-column">
              {tab === 'itinerary' && (
                <>
                  <div className="day-heading">
                    <div>
                      <span className="eyebrow">
                        {day.number
                          ? `${t('DIA', 'DAY', 'GÜN')} ${String(day.number).padStart(2, '0')} / 10`
                          : t('TEMPO EXTRA', 'EXTRA TIME', 'EK ZAMAN')}{' '}
                        ·{' '}
                        {new Date(day.date + 'T12:00:00').toLocaleDateString(
                          locales[lang],
                          { day: 'numeric', month: 'long' },
                        )}
                      </span>
                      <h2>{day.title[lang]}</h2>
                    </div>
                    <div className="day-arrows">
                      <button
                        className="icon-button"
                        disabled={dayIndex === 0}
                        onClick={() => selectDay(dayIndex - 1)}
                        aria-label={t(
                          'Dia anterior',
                          'Previous day',
                          'Önceki gün',
                        )}
                      >
                        <ChevronLeft size={17} />
                      </button>
                      <button
                        className="icon-button"
                        disabled={dayIndex === days.length - 1}
                        onClick={() => selectDay(dayIndex + 1)}
                        aria-label={t('Próximo dia', 'Next day', 'Sonraki gün')}
                      >
                        <ChevronRight size={17} />
                      </button>
                    </div>
                  </div>
                  <div className="day-cover">
                    {renderPhoto({
                      large: true,
                      photoId: day.photo,
                      place:
                        byId[
                          day.photo === 'blue-mosque'
                            ? 'blue'
                            : day.photo === 'hagia-sophia'
                              ? 'hagia'
                              : day.photo === 'basilica-cistern'
                                ? 'cistern'
                                : day.photo === 'dolmabahce'
                                  ? 'dolma'
                                  : day.photo
                        ] || byId.galata,
                    })}
                    <span className="cover-caption">
                      <MapPin size={13} />
                      {photoById[day.photo]?.place}
                    </span>
                  </div>
                  <div className="day-summary">
                    <div className="day-summary-top">
                      <span>{day.area}</span>
                      <span>
                        {dayDone}/{dayTotal} {t('feitos', 'done', 'tamamlandı')}
                      </span>
                    </div>
                    <p>{day.description[lang]}</p>
                    <small>
                      <Clock size={12} />
                      {t(
                        'Horários sugeridos · ajuste às reservas e ao ritmo de vocês',
                        'Suggested times · adjust to bookings and your pace',
                        'Saatler öneridir · rezervasyonlara ve temponuza göre ayarlayın',
                      )}
                    </small>
                  </div>
                </>
              )}
              {tab === 'explore' && (
                <>
                  <div className="day-heading">
                    <div>
                      <span className="eyebrow">
                        {t(
                          'A SUA COLEÇÃO',
                          'YOUR COLLECTION',
                          'KOLEKSİYONUNUZ',
                        )}
                      </span>
                      <h2>
                        {t(
                          'Um lugar para cada vontade.',
                          'A place for every mood.',
                          'Her isteğe bir yer.',
                        )}
                      </h2>
                    </div>
                  </div>
                  <div className="explore-controls">
                    <label className="search-box">
                      <Search size={17} />
                      <input
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        placeholder={t(
                          'Buscar lugar ou bairro',
                          'Search place or neighborhood',
                          'Yer veya semt ara',
                        )}
                      />
                    </label>
                    <Select
                      value={category}
                      onValueChange={(v) => setCategory(String(v))}
                    >
                      <SelectTrigger
                        aria-label={t('Categoria', 'Category', 'Kategori')}
                      >
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {[
                          [
                            'all',
                            t('Todos os lugares', 'All places', 'Tüm yerler'),
                          ],
                          [
                            'saved',
                            t(
                              'Sua lista original',
                              'Your saved list',
                              'Seçtiğiniz yerler',
                            ),
                          ],
                          ['food', labels.food],
                          ['sight', labels.sight],
                          ['shop', labels.shop],
                          ['transport', labels.transport],
                        ].map(([v, n]) => (
                          <SelectItem key={v} value={v}>
                            {n}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <label className="check-filter">
                      <Checkbox
                        checked={localOnly}
                        onCheckedChange={(v) => {
                          setLocalOnly(!!v);
                          if (v) setCategory('all');
                        }}
                      />
                      {t(
                        'Comida > 4,4 · até 2 km do Airbnb',
                        'Food > 4.4 · within 2 km of Airbnb',
                        'Yemek > 4,4 · Airbnb’ye 2 km içinde',
                      )}
                    </label>
                    <label className="check-filter">
                      <Checkbox
                        checked={pendingOnly}
                        onCheckedChange={(v) => setPendingOnly(!!v)}
                      />
                      {t(
                        'Só lugares ainda não visitados',
                        'Only unvisited places',
                        'Yalnızca ziyaret edilmeyenler',
                      )}
                    </label>
                    <small>
                      {filtered.length}{' '}
                      {t('lugares encontrados', 'places found', 'yer bulundu')}{' '}
                      ·{' '}
                      {t(
                        'Raio em linha reta; confira a rota a pé.',
                        'Straight-line radius; check walking directions.',
                        'Kuş uçuşu yarıçap; yürüyüş yolunu kontrol edin.',
                      )}
                    </small>
                  </div>
                </>
              )}
              {tab === 'university' && (
                <>
                  <div className="university-heading">
                    <span className="eyebrow">
                      <GraduationCap size={15} />
                      {t(
                        'ENQUANTO A ZEYNEP ESTUDA',
                        'WHILE ZEYNEP STUDIES',
                        'ZEYNEP DERSTEYKEN',
                      )}
                    </span>
                    <h2>
                      {t(
                        '80 minutos bem aproveitados.',
                        '80 minutes well spent.',
                        'İyi değerlendirilmiş 80 dakika.',
                      )}
                    </h2>
                    <p>
                      {t(
                        'Pequenas descobertas saindo da Faculdade de Letras, com tempo para voltar. Escolha apenas um plano por intervalo.',
                        'Small discoveries from the Faculty of Letters, with time to return. Choose only one plan per break.',
                        'Edebiyat Fakültesi’nden başlayıp dönüşe zaman bırakan küçük keşifler. Her arada yalnızca bir plan seçin.',
                      )}
                    </p>
                    <a
                      href={mapsUrl(byId.university)}
                      target="_blank"
                      rel="noreferrer"
                      className="university-address"
                    >
                      <MapPin size={16} />
                      Balabanağa · Ordu Cd. No:6 · Laleli
                      <ArrowUpRight size={15} />
                    </a>
                  </div>
                  <div className="uni-options">
                    {universityPlans.map((u, i) => (
                      <button
                        key={u.id}
                        className={`uni-option ${i === uniIndex ? 'active-uni' : ''}`}
                        aria-pressed={i === uniIndex}
                        onClick={() => {
                          setUniIndex(i);
                          setSelected(u.ids[0]);
                        }}
                      >
                        <span>{String(i + 1).padStart(2, '0')}</span>
                        {u.title[lang]}
                        <ArrowRight size={15} />
                      </button>
                    ))}
                  </div>
                  <div className="time-budget">
                    <div className="time-budget-title">
                      <strong>{uni.title[lang]}</strong>
                      <span>80 min</span>
                    </div>
                    <div className="time-bar">
                      <span style={{ flex: uni.walk }} />
                      <span style={{ flex: uni.visit }} />
                      <span style={{ flex: uni.buffer }} />
                    </div>
                    <div className="time-legend">
                      <span>
                        <i />
                        {uni.walk} min{' '}
                        {t('ida + volta', 'round trip', 'gidiş dönüş')}
                      </span>
                      <span>
                        <i />
                        {uni.visit} min {t('visita', 'visit', 'ziyaret')}
                      </span>
                      <span>
                        <i />
                        {uni.buffer} min {t('margem', 'buffer', 'pay')}
                      </span>
                    </div>
                    <p>{uni.description[lang]}</p>
                    <small>
                      {t(
                        'Estimativas de planejamento, não tempos medidos. Comece no portão combinado; siga o tempo real do Maps e guarde 15–20 min de folga.',
                        'Planning estimates, not measured travel times. Start at the agreed gate; follow Maps’ live timing and keep 15–20 min spare.',
                        'Bunlar ölçülmüş süre değil, planlama tahmini. Kararlaştırılan kapıdan başlayın; Maps’in güncel süresini izleyip 15–20 dk pay bırakın.',
                      )}
                    </small>
                    <div className="uni-route-actions">
                      <a
                        className="primary-button"
                        href={mapsUrl(
                          byId.university,
                          'walking',
                          universityOrigin,
                          uni.ids.map((id) => byId[id]),
                        )}
                        target="_blank"
                        rel="noreferrer"
                      >
                        <Navigation size={15} />
                        {t(
                          'Abrir circuito a pé',
                          'Open walking loop',
                          'Yürüyüş turunu aç',
                        )}
                        <ArrowUpRight size={15} />
                      </a>
                      <a
                        className="secondary-button"
                        href={mapsUrl(byId.university, 'walking')}
                        target="_blank"
                        rel="noreferrer"
                      >
                        {t('Voltar à Zeynep', 'Back to Zeynep', 'Zeynep’e dön')}
                        <ArrowRight size={15} />
                      </a>
                    </div>
                  </div>
                </>
              )}
              <div className="stops-heading">
                <h3>
                  {tab === 'itinerary'
                    ? t(
                        'Seu caminho, parada a parada',
                        'Your journey, stop by stop',
                        'Adım adım rotanız',
                      )
                    : tab === 'university'
                      ? t(
                          'Perto da faculdade',
                          'Near the faculty',
                          'Fakülte yakınında',
                        )
                      : t(
                          'Lugares para descobrir',
                          'Places to discover',
                          'Keşfedilecek yerler',
                        )}
                </h3>
                <span>
                  {tab === 'itinerary'
                    ? day.stops.length
                    : tab === 'university'
                      ? uni.ids.length
                      : filtered.length}
                </span>
              </div>
              <div className="place-list">
                {tab === 'itinerary'
                  ? day.stops.map((s, i) =>
                      renderPlaceCard({
                        p: byId[s.id],
                        index: i,
                        time: s.time,
                      }),
                    )
                  : tab === 'university'
                    ? uni.ids.map((id, i) =>
                        renderPlaceCard({ p: byId[id], index: i }),
                      )
                    : filtered.map((p, i) => renderPlaceCard({ p, index: i }))}
                {tab === 'explore' && filtered.length === 0 && (
                  <div className="empty-state">
                    <Search />
                    <h3>
                      {t(
                        'Nenhum lugar com esses filtros',
                        'No places match these filters',
                        'Bu filtrelere uygun yer yok',
                      )}
                    </h3>
                    <button
                      className="secondary-button"
                      onClick={() => {
                        setCategory('all');
                        setSearch('');
                        setLocalOnly(false);
                        setPendingOnly(false);
                      }}
                    >
                      {t(
                        'Limpar filtros',
                        'Clear filters',
                        'Filtreleri temizle',
                      )}
                    </button>
                  </div>
                )}
              </div>
            </section>
            <aside className="map-column" id="trip-map-panel">
              <div className="map-panel">
                <div className="map-heading">
                  <div>
                    <span className="eyebrow">
                      {t(
                        'ONDE A VIAGEM ACONTECE',
                        'WHERE THE JOURNEY HAPPENS',
                        'YOLCULUĞUN GEÇTİĞİ YER',
                      )}
                    </span>
                    <h3>
                      {tab === 'university'
                        ? t(
                            'Ao redor da faculdade',
                            'Around the faculty',
                            'Fakülte çevresi',
                          )
                        : t(
                            'Seu mapa de Istambul',
                            'Your Istanbul map',
                            'İstanbul haritanız',
                          )}
                    </h3>
                  </div>
                  <Select
                    value={mapStyle}
                    onValueChange={(v) => setMapStyle(String(v))}
                  >
                    <SelectTrigger
                      aria-label={t(
                        'Estilo de mapa',
                        'Map style',
                        'Harita stili',
                      )}
                    >
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="route">
                        {t(
                          'Mapa do roteiro',
                          'Itinerary map',
                          'Program haritası',
                        )}
                      </SelectItem>
                      <SelectItem value="google">Google Maps</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {mapStyle === 'route' ? (
                  <TripMap
                    places={mapPlaces}
                    active={selected}
                    visited={visited}
                    lang={lang}
                    onSelect={setSelected}
                    location={location}
                    sequence={tab !== 'explore'}
                  />
                ) : (
                  <div className="map-surface">
                    <iframe
                      className="google-map"
                      title={`Google Maps · ${chosen.name}`}
                      src={`https://maps.google.com/maps?q=${encodeURIComponent(chosen.unmapped ? byId.base.address + ', İstanbul' : chosen.name + ', ' + chosen.address + ', İstanbul')}&z=16&output=embed`}
                      loading="lazy"
                      referrerPolicy="no-referrer-when-downgrade"
                      allowFullScreen
                    />
                  </div>
                )}
                <div className="map-footnote">
                  <span className="legend-pin" />
                  {t('Paradas', 'Stops', 'Duraklar')}
                  <span className="legend-pin green" />
                  {t('Visitados', 'Visited', 'Gezilenler')}
                  <span className="legend-dash" />
                  {t('Ordem sugerida', 'Suggested order', 'Önerilen sıra')}
                </div>
                <div className="map-explainer">
                  {mapStyle === 'route'
                    ? t(
                        'Pins aproximados. Linhas indicam sequência, não trajetos pelas ruas.',
                        'Approximate pins. Lines show sequence, not street routes.',
                        'Yaklaşık işaretler. Çizgiler sokak rotasını değil sırayı gösterir.',
                      )
                    : t(
                        'Google Maps mostra o lugar selecionado. Volte ao mapa do roteiro para ver todos os pontos.',
                        'Google Maps shows the selected place. Switch to the itinerary map to see all stops.',
                        'Google Maps seçilen yeri gösterir. Tüm duraklar için program haritasına dönün.',
                      )}
                </div>
                <div className="selected-place">
                  <div className="selected-place-label">
                    <MapPin size={13} />
                    {t('LUGAR SELECIONADO', 'SELECTED PLACE', 'SEÇİLEN YER')}
                  </div>
                  <h3>{chosen.name}</h3>
                  <p>{chosen.address}</p>
                  {!chosen.unmapped && (
                    <a
                      href={mapsUrl(chosen, mode)}
                      target="_blank"
                      rel="noreferrer"
                      className="primary-button"
                    >
                      <Navigation size={15} />
                      {t(
                        'Ir de onde estou',
                        'Go from my location',
                        'Konumumdan git',
                      )}
                      <ArrowUpRight size={15} />
                    </a>
                  )}
                  {chosen.unmapped && (
                    <a
                      className="primary-button"
                      href={chosen.source}
                      target="_blank"
                      rel="noreferrer"
                    >
                      {t(
                        'Conferir embarque no passeio',
                        'Check cruise meeting point',
                        'Tur buluşma yerini kontrol et',
                      )}
                      <ArrowUpRight size={15} />
                    </a>
                  )}
                </div>
                <div className="map-tools">
                  <Select
                    value={mode}
                    onValueChange={(v) => setMode(String(v))}
                  >
                    <SelectTrigger
                      aria-label={t(
                        'Modo de transporte',
                        'Travel mode',
                        'Ulaşım şekli',
                      )}
                    >
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="walking">
                        {t('A pé', 'Walking', 'Yürüyüş')}
                      </SelectItem>
                      <SelectItem value="transit">
                        {t(
                          'Transporte público',
                          'Public transport',
                          'Toplu taşıma',
                        )}
                      </SelectItem>
                      <SelectItem value="driving">
                        {t('Carro / táxi', 'Car / taxi', 'Araba / taksi')}
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  <button
                    className="secondary-button locate-button"
                    onClick={locate}
                    disabled={locStatus === 'loading'}
                  >
                    <LocateFixed size={15} />
                    {locStatus === 'loading'
                      ? t('Localizando…', 'Locating…', 'Bulunuyor…')
                      : t('Localizar', 'Locate me', 'Konumumu bul')}
                  </button>
                </div>
                {locStatus && (
                  <output className="location-status">
                    {locStatus === 'ready'
                      ? t(
                          'Localização exibida no mapa. O Google Maps usa sua posição atual ao abrir a rota.',
                          'Location shown on the map. Google Maps uses your current position when opening directions.',
                          'Konum haritada gösterildi. Google Maps rotayı açarken güncel konumunuzu kullanır.',
                        )
                      : locStatus === 'far'
                        ? t(
                            'Você está longe de Istambul. O mapa continua mostrando a viagem; o Maps pode pedir uma origem próxima.',
                            'You are far from Istanbul. The map keeps showing your trip; Maps may need a closer origin.',
                            'İstanbul’dan uzaktasınız. Harita gezinizi göstermeye devam eder; Maps daha yakın başlangıç isteyebilir.',
                          )
                        : locStatus === 'denied' || locStatus === 'unsupported'
                          ? t(
                              'Localização indisponível. Abra a rota no Google Maps e selecione “Sua localização” ou digite uma origem.',
                              'Location unavailable. Open Google Maps directions and select “Your location” or enter an origin.',
                              'Konum kullanılamıyor. Google Maps’te “Konumunuz”u seçin veya başlangıç girin.',
                            )
                          : t(
                              'Aguardando permissão de localização…',
                              'Waiting for location permission…',
                              'Konum izni bekleniyor…',
                            )}
                  </output>
                )}
              </div>
              <div className="route-plan">
                <span className="eyebrow">
                  <Navigation size={13} />
                  {t(
                    'ROTAS NO GOOGLE MAPS',
                    'GOOGLE MAPS DIRECTIONS',
                    'GOOGLE MAPS ROTALARI',
                  )}
                </span>
                <h3>
                  {t(
                    'O próximo passo é seu.',
                    'Your next move.',
                    'Sıradaki adım sizin.',
                  )}
                </h3>
                <p>
                  {t(
                    'Cada rota individual começa na sua localização atual. Para sequências a pé, abra os trechos abaixo. Confira travessias em transporte público.',
                    'Each individual route starts at your current location. For walking sequences, open the sections below. Check crossings in public transport mode.',
                    'Her tekil rota güncel konumunuzdan başlar. Yürüyüş dizileri için aşağıdaki bölümleri açın. Geçişleri toplu taşıma modunda kontrol edin.',
                  )}
                </p>
                {tab === 'itinerary' && (
                  <div className="segment-list">
                    {day.stops.map((s, i) => {
                      if (
                        i === 0 ||
                        byId[s.id].unmapped ||
                        byId[day.stops[i - 1].id].unmapped
                      )
                        return null;
                      const prev = byId[day.stops[i - 1].id],
                        dest = byId[s.id];
                      const far =
                        distance(prev, dest) > 2 ||
                        (prev.lng > 29.005 !== dest.lng > 29.005 &&
                          distance(prev, dest) > 1);
                      return (
                        <a
                          key={s.id}
                          href={mapsUrl(
                            dest,
                            far ? 'transit' : 'walking',
                            `${prev.name}, ${prev.address}, İstanbul`,
                          )}
                          target="_blank"
                          rel="noreferrer"
                        >
                          <span className="segment-mode">
                            {far ? (
                              <Ship size={13} />
                            ) : (
                              <Navigation size={13} />
                            )}
                          </span>
                          <span>
                            {prev.name}
                            <small>→ {dest.name}</small>
                          </span>
                          <ArrowUpRight size={13} />
                        </a>
                      );
                    })}
                  </div>
                )}
                <a
                  className="return-home"
                  href={mapsUrl(
                    tab === 'university' ? byId.university : byId.base,
                    tab === 'university' ? 'walking' : mode,
                  )}
                  target="_blank"
                  rel="noreferrer"
                >
                  <Home size={16} />
                  {tab === 'university'
                    ? t(
                        'Voltar à faculdade',
                        'Return to faculty',
                        'Fakülteye dön',
                      )
                    : t(
                        'Voltar ao Airbnb',
                        'Return to Airbnb',
                        'Airbnb’ye dön',
                      )}
                  <ArrowUpRight size={15} />
                </a>
              </div>
              <div className="little-note">
                <Info size={16} />
                <p>
                  {t(
                    'As notas são uma consulta de setembro de 2026. Horários, preços e disponibilidade podem mudar até a viagem.',
                    'Ratings are a September 2026 snapshot. Hours, prices and availability may change before your trip.',
                    'Puanlar Eylül 2026 araştırmasına aittir. Saatler, fiyatlar ve müsaitlik geziye kadar değişebilir.',
                  )}
                </p>
              </div>
            </aside>
          </div>
        )}
        <footer className="footer">
          <span>
            İSTANBUL ·{' '}
            {t(
              'FEITO PARA VOCÊS',
              'MADE FOR YOU TWO',
              'İKİNİZ İÇİN HAZIRLANDI',
            )}
          </span>
          <button onClick={() => switchTab('practical')}>
            {t(
              'Fontes & créditos',
              'Sources & credits',
              'Kaynaklar ve fotoğraflar',
            )}
            <ArrowUpRight size={13} />
          </button>
          <span>Samuel & Zeynep · 2026</span>
        </footer>
      </div>
    </div>
  );
}

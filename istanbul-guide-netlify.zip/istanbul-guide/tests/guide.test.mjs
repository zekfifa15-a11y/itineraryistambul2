import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import ts from 'typescript';
const temp=await fs.mkdtemp(path.join(os.tmpdir(),'istanbul-guide-test-'));
for(const name of ['trip','university-extra','guide']){
 const source=await fs.readFile(new URL(`../lib/${name}.ts`,import.meta.url),'utf8');
 const js=ts.transpile(source,{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}).replaceAll("'./trip'","'./trip.mjs'").replaceAll("'./university-extra'","'./university-extra.mjs'");
 await fs.writeFile(path.join(temp,name+'.mjs'),js);
}
const {guidePlaces,poi,tripPlans,universityPlans,legsFor,googleDirections,googleEmbed,distance}=await import(pathToFileURL(path.join(temp,'guide.mjs')));
const photos=JSON.parse(await fs.readFile(new URL('../lib/guide-photos.json',import.meta.url),'utf8'));
assert.equal(tripPlans.length,15);assert.equal(tripPlans.filter(d=>d.number).length,10);
assert.equal(new Set(guidePlaces.map(p=>p.id)).size,guidePlaces.length);
assert.ok(!poi.galata&&!poi.dukkan&&!poi.mero);
for(const p of guidePlaces){
 for(const lang of ['pt','en','tr'])assert.ok(p.description[lang].length>10,p.id+' '+lang);
 if(p.kind==='food')assert.ok(p.rating>4.6,`${p.id} must be strictly >4.6`);
 if(p.kind!=='base'){assert.ok(photos[p.id]?.url,`Photo missing: ${p.id}`);assert.ok(photos[p.id].source,`Photo source missing: ${p.id}`)}
 if(!p.unmapped){assert.ok(p.lat>40&&p.lat<42);assert.ok(p.lng>28&&p.lng<30)}
}
const activePhotoUrls=guidePlaces.filter(p=>p.kind!=='base').map(p=>photos[p.id].url);assert.equal(new Set(activePhotoUrls).size,activePhotoUrls.length,'Every place must have its own photo');
for(const plan of [...tripPlans,...universityPlans]){
 for(const stop of plan.stops)assert.ok(poi[stop.id],`Unknown stop: ${stop.id}`);
 const legs=legsFor(plan);
 if(plan.stops.length){assert.equal(legs[0].from,plan.start);assert.equal(legs.at(-1).to,plan.end)}
 for(let i=1;i<legs.length;i++)assert.equal(legs[i-1].to,legs[i].from,'Discontinuous route');
 for(const leg of legs){if(poi[leg.from].unmapped||poi[leg.to].unmapped)assert.equal(leg.mode,'unknown');if(leg.mode==='walking')assert.ok(distance(poi[leg.from],poi[leg.to])<=2)}
}
for(const plan of universityPlans){assert.equal(plan.start,'university');assert.equal(plan.end,'university');assert.equal(plan.budget.walk+plan.budget.visit+plan.budget.buffer,80);assert.ok(plan.budget.buffer>=15)}
assert.deepEqual(tripPlans[7].stops.map(s=>s.id),['salacak','uskudar','kuzguncuk','patata']);
assert.equal(legsFor(tripPlans[7])[0].mode,'transit');
assert.deepEqual(tripPlans[10].stops.map(s=>s.id),['cruise']);
assert.ok(tripPlans[2].stops.some(s=>s.id==='cistern'));
assert.ok(!tripPlans[8].stops.some(s=>s.id==='suleymaniye'));
const current=new URL(googleDirections(undefined,poi.tomtom));assert.equal(current.searchParams.has('origin'),false);assert.equal(current.searchParams.get('api'),'1');
const fixed=new URL(googleDirections(poi.base,poi.tomtom));assert.ok(!fixed.searchParams.get('origin').includes('Airbnb'));assert.ok(fixed.searchParams.get('destination').includes('Tomtom'));
const embed=new URL(googleEmbed(poi.base,poi.tomtom,'walking','tr'));assert.equal(embed.searchParams.get('dirflg'),'w');assert.equal(embed.searchParams.get('hl'),'tr');assert.equal(embed.searchParams.get('output'),'embed');
console.log(`Validated ${guidePlaces.length} places, ${activePhotoUrls.length} individual photos, strict ratings, 15 days, 8 faculty loops, route continuity and Maps links.`);
await fs.rm(temp,{recursive:true,force:true});

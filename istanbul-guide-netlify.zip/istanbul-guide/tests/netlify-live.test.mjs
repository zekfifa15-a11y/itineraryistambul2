import assert from 'node:assert/strict';
const base = 'http://localhost:8888';
const get = async (path) => {
  const response = await fetch(base + path);
  assert.equal(response.status, 200);
  return response.json();
};
const change = async (path, method, body, origin = base) =>
  fetch(
    new Request(base + path, {
      method: method === 'PATCH' ? 'PATCH' : 'PUT',
      headers: { 'Content-Type': 'application/json', Origin: origin },
      body: JSON.stringify(body),
    }),
  );
const progress = await get('/api/progress');
const planner = await get('/api/planner');
const original = progress.visited.saint ?? false;
const wasTrashed = planner.trash.includes('saint');
try {
  const responses = await Promise.all([
    change('/api/progress', 'PUT', { id: 'saint', done: !original }),
    change('/api/planner', 'PATCH', {
      action: wasTrashed ? 'restore' : 'trash',
      id: 'saint',
    }),
  ]);
  assert.ok(responses.every((response) => response.status === 200));
  assert.equal((await get('/api/progress')).visited.saint, !original);
  assert.equal(
    (await get('/api/planner')).trash.includes('saint'),
    !wasTrashed,
  );
  assert.equal(
    (
      await change(
        '/api/progress',
        'PUT',
        { id: 'saint', done: true },
        'https://other.example',
      )
    ).status,
    403,
  );
  assert.equal(
    (await change('/api/planner', 'PATCH', { action: 'trash', id: 'base' }))
      .status,
    400,
  );
  assert.equal(typeof (await get('/api/maps-config')).googleEmbedKey, 'string');
  console.log(
    'Real Netlify Functions + local Blobs: endpoints, parallel saves, immediate readback, origin/input checks and Google configuration passed.',
  );
} finally {
  assert.equal(
    (await change('/api/progress', 'PUT', { id: 'saint', done: original }))
      .status,
    200,
  );
  assert.equal(
    (
      await change('/api/planner', 'PATCH', {
        action: wasTrashed ? 'trash' : 'restore',
        id: 'saint',
      })
    ).status,
    200,
  );
  assert.deepEqual(await get('/api/progress'), progress);
  assert.deepEqual(await get('/api/planner'), planner);
  console.log('Original checklist and planner restored.');
}

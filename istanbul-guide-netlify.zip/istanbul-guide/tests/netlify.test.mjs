import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
import ts from 'typescript';

const workspace = fileURLToPath(new URL('../work/', import.meta.url));
await fs.mkdir(workspace, { recursive: true });
const dir = await fs.mkdtemp(path.join(workspace, 'netlify-test-'));
try {
  for (const file of [
    'lib/trip',
    'lib/university-extra',
    'lib/guide',
    'lib/practical',
    'lib/planner',
    'netlify/lib/api',
    'netlify/lib/state',
  ]) {
    const target = path.join(dir, file + '.mjs');
    await fs.mkdir(path.dirname(target), { recursive: true });
    const source = await fs.readFile(
      new URL('../' + file + '.ts', import.meta.url),
      'utf8',
    );
    const js = ts
      .transpile(source, {
        module: ts.ModuleKind.ESNext,
        target: ts.ScriptTarget.ES2022,
      })
      .replace(/(['"])(\.\.?\/[^'"]+)\1/g, "'$2.mjs'");
    await fs.writeFile(target, js);
  }
  const { createRepository } = await import(
    pathToFileURL(path.join(dir, 'netlify/lib/state.mjs'))
  );
  const { planner, progress } = await import(
    pathToFileURL(path.join(dir, 'netlify/lib/api.mjs'))
  );
  const seed = JSON.parse(
    await fs.readFile(
      new URL('../netlify/data/initial-state.json', import.meta.url),
      'utf8',
    ),
  );
  let data,
    revision = 0;
  const store = {
    async getWithMetadata() {
      return data
        ? { data: structuredClone(data), etag: String(revision) }
        : null;
    },
    async setJSON(_key, next, conditions) {
      if (
        conditions.onlyIfNew
          ? !!data
          : conditions.onlyIfMatch !== String(revision)
      )
        return { modified: false };
      data = structuredClone(next);
      revision++;
      return { modified: true };
    },
  };
  const repo = createRepository(store, seed);
  const otherBrowser = createRepository(store, {
    version: 1,
    visited: {},
    edits: { trash: [], additions: {}, custom: [] },
  });
  const request = (route, method = 'GET', body, origin) =>
    new Request('https://guide.netlify.app/api/' + route, {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(origin ? { Origin: origin } : {}),
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
  const patch = (body) => planner(request('planner', 'PATCH', body), repo);
  const put = (body) => progress(request('progress', 'PUT', body), repo);
  const first = await progress(request('progress'), repo);
  assert.equal(first.status, 200);
  assert.equal(first.headers.get('Cache-Control'), 'no-store');
  assert.deepEqual((await first.json()).visited, seed.visited);
  assert.deepEqual(
    (await otherBrowser.read()).visited,
    seed.visited,
    'Seed is stored once and survives changed deploy seed',
  );
  const custom = {
    id: 'custom-netlify-test',
    custom: true,
    name: 'Netlify persistence test',
    address: 'Beyoglu',
    lat: 41.027,
    lng: 28.98,
    area: 'Beyoglu',
    kind: 'sight',
    description: { pt: 'Teste', en: 'Test', tr: 'Test' },
  };
  assert.equal(
    (await patch({ action: 'create', plan: '2026-10-21', place: custom }))
      .status,
    200,
  );
  assert.equal((await put({ id: custom.id, done: true })).status, 200);
  assert.equal((await patch({ action: 'trash', id: custom.id })).status, 200);
  let state = await otherBrowser.read();
  assert.ok(state.edits.trash.includes(custom.id));
  assert.equal(state.visited[custom.id], true);
  assert.equal((await patch({ action: 'restore', id: custom.id })).status, 200);
  assert.equal(
    (await patch({ action: 'add', plan: '2026-10-22', id: custom.id })).status,
    200,
  );
  state = await otherBrowser.read();
  assert.ok(!state.edits.trash.includes(custom.id));
  assert.ok(state.edits.additions['2026-10-22'].includes(custom.id));
  const concurrent = await Promise.all([
    put({ id: 'tomtom', done: true }),
    patch({ action: 'trash', id: 'hagia' }),
    progress(
      request('progress', 'PUT', { id: 'saint', done: true }),
      otherBrowser,
    ),
  ]);
  assert.ok(concurrent.every((r) => r.status === 200));
  state = await repo.read();
  assert.equal(state.visited.tomtom, true);
  assert.equal(state.visited.saint, true);
  assert.ok(
    state.edits.trash.includes('hagia'),
    'Concurrent mutations do not overwrite each other',
  );
  assert.equal((await put({ id: 'tomtom', done: false })).status, 200);
  assert.equal((await otherBrowser.read()).visited.tomtom, false);
  for (const body of [
    null,
    { id: 'base', done: true },
    { id: '__proto__', done: true },
    { id: 'missing', done: true },
    { id: 'tomtom', done: 'true' },
  ])
    assert.equal((await put(body)).status, 400);
  for (const body of [
    null,
    { action: 'trash', id: 'university' },
    { action: 'add', id: 'hagia', plan: 'invalid' },
    {
      action: 'create',
      plan: '2026-10-21',
      place: { ...custom, kind: 'food', rating: 4.6 },
    },
  ])
    assert.equal((await patch(body)).status, 400);
  assert.equal(
    (
      await progress(
        request(
          'progress',
          'PUT',
          { id: 'tomtom', done: true },
          'https://other.example',
        ),
        repo,
      )
    ).status,
    403,
  );
  assert.equal(
    (
      await planner(
        request(
          'planner',
          'PATCH',
          { action: 'trash', id: 'hagia' },
          'https://other.example',
        ),
        repo,
      )
    ).status,
    403,
  );
  assert.equal(
    (await planner(request('planner', 'POST', {}), repo)).status,
    405,
  );
  const failing = createRepository(
    {
      ...store,
      async setJSON() {
        return { modified: false };
      },
    },
    seed,
  );
  assert.equal(
    (
      await progress(
        request('progress', 'PUT', { id: 'hagia', done: true }),
        failing,
      )
    ).status,
    503,
  );
  assert.equal(
    (await repo.read()).visited.hagia,
    undefined,
    'Failed saves never report success',
  );
  console.log(
    'Netlify APIs: migration, reload/second browser, create/check/trash/restore/add, concurrent writes, invalid inputs, origin protection and retry exhaustion passed.',
  );
} finally {
  assert.ok(
    path.resolve(dir).startsWith(path.resolve(workspace) + path.sep),
    'Unsafe cleanup path',
  );
  await fs.rm(dir, { recursive: true, force: true });
}

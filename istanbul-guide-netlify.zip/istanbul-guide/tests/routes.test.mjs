import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import ts from 'typescript';

const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'istanbul-routes-'));
const nativeFetch = globalThis.fetch;
try {
  for (const name of [
    'trip',
    'university-extra',
    'guide',
    'practical',
    'planner',
    'route-plan',
    'google-route-request',
    'walking-route',
  ]) {
    const source = await fs.readFile(
      new URL(`../lib/${name}.ts`, import.meta.url),
      'utf8',
    );
    const js = ts
      .transpile(source, {
        module: ts.ModuleKind.ESNext,
        target: ts.ScriptTarget.ES2022,
      })
      .replace(/(['"])(\.\/[\w-]+)\1/g, "'$2.mjs'");
    await fs.writeFile(path.join(dir, name + '.mjs'), js);
  }
  const { poi, universityPlans, distance } = await import(
    pathToFileURL(path.join(dir, 'guide.mjs'))
  );
  const { initialPlans, optimizePlan, emptyEdits } = await import(
    pathToFileURL(path.join(dir, 'planner.mjs'))
  );
  const {
    routeForPlan,
    googleRouteEmbed,
    googleRouteLinks,
    mapPointLabel,
    sectionDepartureTime,
  } = await import(pathToFileURL(path.join(dir, 'route-plan.mjs')));
  const { infoFor } = await import(
    pathToFileURL(path.join(dir, 'practical.mjs'))
  );
  const numbered = [poi.base, poi.saint, poi.camondo, poi.base];
  assert.equal(mapPointLabel('saint', numbered), '1');
  assert.equal(mapPointLabel('camondo', numbered), '2');
  assert.equal(mapPointLabel('base', numbered), '⌂');
  assert.equal(
    mapPointLabel('university', [poi.university, poi.saint, poi.university]),
    'U',
  );
  assert.equal(sectionDepartureTime(initialPlans[0]), '17:00');
  assert.equal(sectionDepartureTime(initialPlans[1]), '09:00');
  assert.equal(
    sectionDepartureTime({ ...initialPlans[1], startTime: '18:30' }),
    '18:30',
  );
  assert.equal(sectionDepartureTime({ ...initialPlans[1], startTime: '' }), '');
  const scheduled = {
    ...initialPlans[1],
    stops: [{ id: 'saint', time: '12:00' }],
  };
  const expectedMinutes = 12 * 60 + infoFor(poi.saint).duration;
  assert.equal(
    sectionDepartureTime(scheduled, { points: [poi.saint] }),
    `${Math.floor(expectedMinutes / 60)
      .toString()
      .padStart(2, '0')}:${(expectedMinutes % 60).toString().padStart(2, '0')}`,
  );
  const hamamDay = optimizePlan(
    initialPlans.find((p) => p.date === '2026-11-02'),
    emptyEdits,
    poi,
  );
  assert.equal(hamamDay.stops.at(-1).id, 'hamam');
  assert.equal(
    sectionDepartureTime(hamamDay, { points: [poi.hamam] }),
    '',
    'An unscheduled return asks for its time instead of querying morning transport',
  );
  for (const day of initialPlans) {
    assert.equal(day.end, 'base', 'Every daily itinerary returns to Airbnb');
    const empty = { ...day, stops: [] };
    assert.equal(
      routeForPlan(empty, poi, poi.university).points.at(-1).id,
      'base',
      'An empty day still supports the return home',
    );
  }
  const { getWalkingRouteThrough } = await import(
    pathToFileURL(path.join(dir, 'walking-route.mjs'))
  );
  const { googleRouteRequest, matchesTransitPreference } = await import(
    pathToFileURL(path.join(dir, 'google-route-request.mjs'))
  );
  const sampleSection = {
    mode: 'walking',
    points: [poi.base, poi.saint, poi.camondo, poi.base],
  };
  const walkRequest = googleRouteRequest(sampleSection, 'pt', 'BUS');
  assert.equal(walkRequest.travelMode, 'WALKING');
  assert.equal(walkRequest.intermediates.length, 2);
  assert.equal(walkRequest.optimizeWaypointOrder, false);
  assert.deepEqual(
    walkRequest.intermediates.map((p) => p.location),
    [poi.saint, poi.camondo].map((p) => ({ lat: p.lat, lng: p.lng })),
  );
  for (const mode of ['ALL', 'BUS', 'TRAIN', 'SUBWAY', 'LIGHT_RAIL']) {
    const request = googleRouteRequest(
      { mode: 'transit', points: [poi.base, poi.university] },
      'tr',
      mode,
      '2026-10-21T10:00',
    );
    assert.equal(request.travelMode, 'TRANSIT');
    assert.equal(request.intermediates, undefined);
    assert.equal(request.computeAlternativeRoutes, true);
    assert.equal(
      request.departureTime.toISOString(),
      '2026-10-21T07:00:00.000Z',
    );
    assert.deepEqual(
      request.transitPreference,
      mode === 'ALL' ? undefined : { allowedTransitModes: [mode] },
    );
  }
  const tramRoute = {
    legs: [
      {
        steps: [
          {
            transitDetails: {
              transitLine: { vehicle: { vehicleType: 'TRAM' } },
            },
          },
        ],
      },
    ],
  };
  assert.equal(matchesTransitPreference(tramRoute, 'LIGHT_RAIL'), true);
  assert.equal(matchesTransitPreference(tramRoute, 'BUS'), false);
  assert.equal(
    googleRouteRequest(
      { mode: 'unknown', points: [poi.base, poi.university] },
      'en',
      'ALL',
    ),
    undefined,
  );
  for (const original of [...initialPlans, ...universityPlans]) {
    const plan = optimizePlan(original, emptyEdits, poi);
    for (const base of [poi[plan.start], poi.base, poi.university]) {
      const result = routeForPlan(plan, poi, base);
      assert.equal(result.points[0].id, base.id);
      assert.equal(
        result.points.at(-1).id,
        plan.stops.length || base.id !== plan.end ? plan.end : base.id,
      );
      for (const stop of plan.stops)
        assert.ok(
          result.points.some((p) => p.id === stop.id),
          `Missing ${stop.id}`,
        );
      assert.deepEqual(
        result.sections.flatMap((s) => s.legs),
        result.legs,
        'Every leg appears exactly once',
      );
      assert.deepEqual(
        result.legs.map((l) => l.to.id),
        result.points.slice(1).map((p) => p.id),
      );
      for (const section of result.sections) {
        if (section.mode === 'unknown') {
          assert.equal(googleRouteEmbed(section, 'test-key', 'pt'), undefined);
          assert.ok(section.points.some((p) => p.unmapped));
          continue;
        }
        const url = new URL(googleRouteEmbed(section, 'test-key', 'tr'));
        assert.equal(url.pathname, '/maps/embed/v1/directions');
        assert.equal(url.searchParams.get('mode'), section.mode);
        assert.equal(url.searchParams.get('language'), 'tr');
        assert.equal(
          url.searchParams.has('waypoints'),
          section.points.length > 2,
        );
        if (section.mode === 'transit') assert.equal(section.points.length, 2);
        assert.equal(
          googleRouteEmbed(section, '', 'pt'),
          undefined,
          'Never emit a broken no-key official embed',
        );
        const links = googleRouteLinks(section);
        const externalEdges = links.flatMap((link) => {
          assert.ok(link.url.length < 2048);
          assert.ok(
            link.points.length <= 5,
            'Mobile limit is three intermediate stops',
          );
          const query = new URL(link.url).searchParams;
          const coordinates = [
            query.get('origin'),
            ...(query.get('waypoints')?.split('|') || []),
            query.get('destination'),
          ];
          assert.deepEqual(
            coordinates,
            link.points.map((p) => `${p.lat},${p.lng}`),
          );
          return link.points
            .slice(1)
            .map((p, i) => `${link.points[i].id}__${p.id}`);
        });
        assert.deepEqual(
          externalEdges,
          section.legs.map((l) => l.id),
        );
      }
    }
  }
  const day = initialPlans.find((p) => p.date === '2026-10-29');
  const before = optimizePlan(day, emptyEdits, poi);
  const removedId = before.stops[1].id;
  const after = optimizePlan(
    day,
    { ...emptyEdits, trash: [removedId], additions: { [day.id]: ['saint'] } },
    poi,
  );
  const changed = routeForPlan(after, poi, poi.base);
  assert.ok(!changed.points.some((p) => p.id === removedId));
  assert.ok(changed.points.some((p) => p.id === 'saint'));
  assert.deepEqual(
    changed.legs.map((l) => l.to.id),
    [...after.stops.map((s) => s.id), after.end],
  );
  const current = {
    ...poi.uskudar,
    id: 'current',
    lat: poi.uskudar.lat + 0.0002,
  };
  const asianPlan = {
    ...before,
    start: 'base',
    stops: [{ id: 'uskudar', time: '09:00' }],
    end: 'base',
  };
  const asian = routeForPlan(asianPlan, poi, current);
  assert.equal(
    asian.legs[0].mode,
    'walking',
    'GPS on Asian shore can walk to nearby Üsküdar',
  );
  assert.equal(asian.legs[1].mode, 'transit', 'Return crosses the strait');
  const remaining = routeForPlan(
    before,
    poi,
    { ...poi.base, id: 'current' },
    'auto',
    { [before.stops[0].id]: true },
  );
  assert.ok(!remaining.points.some((p) => p.id === before.stops[0].id));
  assert.equal(remaining.points.at(-1).id, before.end);
  const allDone = routeForPlan(
    before,
    poi,
    current,
    'auto',
    Object.fromEntries(before.stops.map((s) => [s.id, true])),
  );
  assert.deepEqual(
    allDone.points.map((p) => p.id),
    ['current', before.end],
  );
  const extra = Object.fromEntries(
    Array.from({ length: 48 }, (_, i) => [
      `custom-${i}`,
      { ...poi.saint, id: `custom-${i}`, lat: poi.saint.lat + i / 100000 },
    ]),
  );
  const long = routeForPlan(
    {
      ...before,
      stops: Object.keys(extra).map((id) => ({ id, time: '09:00' })),
    },
    { ...poi, ...extra },
    poi.base,
    'walking',
  );
  assert.ok(long.sections.every((s) => s.points.length <= 22));
  assert.equal(long.sections.flatMap((s) => s.legs).length, 49);

  const requests = [];
  let malformed = false;
  globalThis.fetch = async (url) => {
    const address =
      typeof url === 'string' ? url : url instanceof URL ? url.href : url.url;
    requests.push(address);
    const coords = new URL(address).pathname
      .split('/')
      .at(-1)
      .split(';')
      .map((p) => p.split(',').map(Number));
    return Response.json({
      code: 'Ok',
      waypoints: coords.map(() => ({ distance: 2 })),
      routes: [
        {
          distance: 500,
          duration: 450,
          geometry: { coordinates: coords },
          legs: coords.slice(1).map((p, i) => ({
            distance: 200,
            duration: 180,
            steps: [
              {
                geometry: {
                  coordinates: malformed ? [[NaN, 41]] : [coords[i], p],
                },
              },
            ],
          })),
        },
      ],
    });
  };
  const points = [poi.base, poi.saint, poi.tomtom, poi.base];
  const answer = await getWalkingRouteThrough(
    points,
    new AbortController().signal,
  );
  assert.equal(answer.legs.length, points.length - 1);
  assert.ok(
    requests[0].includes(points.map((p) => `${p.lng},${p.lat}`).join(';')),
  );
  await getWalkingRouteThrough(points, new AbortController().signal);
  assert.equal(requests.length, 1, 'Unchanged chain reuses cache');
  await getWalkingRouteThrough(
    [poi.base, poi.tomtom, poi.saint, poi.base],
    new AbortController().signal,
  );
  assert.equal(requests.length, 2, 'Changed order invalidates route');
  await getWalkingRouteThrough(
    [poi.base, poi.saint, poi.base],
    new AbortController().signal,
  );
  assert.equal(requests.length, 3, 'Removed stop invalidates route');
  malformed = true;
  await assert.rejects(
    getWalkingRouteThrough(
      [poi.base, poi.camondo, poi.base],
      new AbortController().signal,
    ),
    /Invalid leg geometry/,
  );
  globalThis.fetch = nativeFetch;

  if (process.argv.includes('--live')) {
    for (const sample of [
      [poi.base, poi.saint, poi.camondo, poi.base],
      [poi.university, poi.kalender, poi.university],
    ]) {
      assert.ok(sample.every(Boolean), 'Sample destinations exist');
      const route = await getWalkingRouteThrough(
        sample,
        new AbortController().signal,
      );
      assert.equal(route.legs.length, sample.length - 1);
      assert.ok(route.distance > 0 && route.duration > 0);
      for (const p of sample)
        assert.ok(
          route.coordinates.some(
            ([lng, lat]) => distance(p, { lat, lng }) < 0.15,
          ),
          'Street route reaches every waypoint',
        );
      console.log(
        `Live routing: ${sample.map((p) => p.name).join(' → ')}; ${Math.round(route.distance)}m, ${route.legs.length} legs.`,
      );
    }
  }
  console.log(
    'Routes: all days and faculty loops preserve all points, origins and returns; Google supported endpoint, mobile chunks, add/remove, visited stops, live Asian shore, waypoint limits, cache order and malformed geometry passed.',
  );
} finally {
  globalThis.fetch = nativeFetch;
  await fs.rm(dir, { recursive: true, force: true });
}

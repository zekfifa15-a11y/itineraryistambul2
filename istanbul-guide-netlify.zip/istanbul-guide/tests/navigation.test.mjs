import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import ts from 'typescript';
const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'istanbul-navigation-'));
const nativeFetch = globalThis.fetch;
try {
  for (const name of [
    'trip',
    'university-extra',
    'guide',
    'navigation',
    'walking-route',
  ]) {
    const source = await fs.readFile(
      new URL(`../lib/${name}.ts`, import.meta.url),
      'utf8',
    );
    const js = ts
      .transpile(source, {
        module: ts.ModuleKind.ESNext,
        target: ts.ScriptTarget.ES2022,
      })
      .replace(/(['"])(\.\/[\w-]+)\1/g, "'$2.mjs'");
    await fs.writeFile(path.join(dir, name + '.mjs'), js);
  }
  const { validFix, shouldRefreshRoute, compassHeading } = await import(
    pathToFileURL(path.join(dir, 'navigation.mjs'))
  );
  const { poi, guidePlaces, googleEmbed, googlePlaceEmbed, googleDirections } =
    await import(pathToFileURL(path.join(dir, 'guide.mjs')));
  const { getWalkingRoute } = await import(
    pathToFileURL(path.join(dir, 'walking-route.mjs'))
  );
  const now = Date.now(),
    a = {
      lat: 41.026,
      lng: 28.977,
      accuracy: 8,
      timestamp: now - 20000,
      heading: null,
    },
    b = { ...a, lat: 41.0264, timestamp: now };
  assert.equal(validFix({ ...a, lat: NaN }), false);
  assert.equal(validFix({ ...a, accuracy: -1 }), false);
  assert.equal(shouldRefreshRoute(undefined, b, now), true);
  assert.equal(shouldRefreshRoute(a, b, now), true);
  assert.equal(
    shouldRefreshRoute(a, { ...b, timestamp: a.timestamp + 3000 }, now),
    false,
    'Do not repeatedly request routes for GPS jitter',
  );
  assert.equal(
    shouldRefreshRoute(undefined, { ...b, accuracy: 150 }, now),
    false,
  );
  assert.equal(
    shouldRefreshRoute(undefined, { ...b, timestamp: now - 40000 }, now),
    false,
  );
  assert.equal(compassHeading({ alpha: 90, absolute: true }), 270);
  assert.equal(
    compassHeading({ alpha: 90, absolute: false }),
    null,
    'Relative orientation cannot claim north',
  );
  assert.equal(
    compassHeading({ alpha: null, webkitCompassHeading: 350 }, 90),
    80,
  );
  assert.equal(
    compassHeading({
      alpha: null,
      webkitCompassHeading: 42,
      webkitCompassAccuracy: -1,
    }),
    null,
  );
  for (const to of guidePlaces.filter((p) => !p.unmapped)) {
    for (const from of [poi.base, poi.university])
      for (const mode of ['walking', 'transit']) {
        const embed = new URL(googleEmbed(from, to, mode, 'pt'));
        assert.equal(
          embed.searchParams.get('saddr'),
          `${from.lat},${from.lng}`,
        );
        assert.equal(embed.searchParams.get('daddr'), `${to.lat},${to.lng}`);
        assert.equal(
          embed.searchParams.get('dirflg'),
          mode === 'walking' ? 'w' : 'r',
        );
        const external = new URL(googleDirections(from, to, mode));
        assert.ok(external.searchParams.get('origin'));
        assert.equal(external.searchParams.get('travelmode'), mode);
      }
    const place = new URL(googlePlaceEmbed(to, 'tr'));
    assert.ok(place.searchParams.get('q'));
    assert.equal(place.searchParams.get('output'), 'embed');
    assert.equal(place.searchParams.get('hl'), 'tr');
  }
  let calls = 0;
  globalThis.fetch = async (url) => {
    calls++;
    assert.ok(String(url).includes('/routed-foot/'));
    return Response.json({
      code: 'Ok',
      routes: [
        {
          distance: 600,
          duration: 500,
          geometry: {
            coordinates: [
              [28.977, 41.026],
              [28.978, 41.027],
            ],
          },
        },
      ],
      waypoints: [{ distance: 4 }, { distance: 6 }],
    });
  };
  const target = { lat: 41.028, lng: 28.978 };
  await getWalkingRoute(a, target, new AbortController().signal);
  await getWalkingRoute(a, target, new AbortController().signal);
  assert.equal(calls, 1, 'Identical points reuse route');
  await getWalkingRoute(b, target, new AbortController().signal);
  assert.equal(calls, 2, 'Moving origin must invalidate cached route');
  const controller = new AbortController();
  controller.abort();
  await assert.rejects(
    getWalkingRoute(a, { ...target, lat: 41.029 }, controller.signal),
    { name: 'AbortError' },
  );
  globalThis.fetch = async () =>
    Response.json({
      code: 'Ok',
      routes: [
        {
          distance: 100,
          duration: 100,
          geometry: {
            coordinates: [
              [28.977, 41.026],
              [28.978, 41.027],
            ],
          },
        },
      ],
      waypoints: [{ distance: 900 }],
    });
  await assert.rejects(
    getWalkingRoute(a, { ...target, lat: 41.03 }, new AbortController().signal),
    /Route unavailable/,
  );
  console.log(
    'Navigation: GPS precision/staleness, compass validity, throttling, all destination URLs from both bases, cache invalidation, cancellation and remote snap validation passed.',
  );
} finally {
  globalThis.fetch = nativeFetch;
  await fs.rm(dir, { recursive: true, force: true });
}

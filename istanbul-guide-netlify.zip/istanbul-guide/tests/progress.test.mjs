import assert from 'node:assert/strict';
const root = 'http://localhost:3000';
let r = await fetch(root + '/api/progress');
assert.equal(r.status, 200);
const original = (await r.json()).visited.tomtom ?? false;
async function put(body, extra = {}) {
  return fetch(root + '/api/progress', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', ...extra },
    body: JSON.stringify(body),
  });
}
try {
  r = await put({ id: 'tomtom', done: true });
  assert.equal(r.status, 200);
  r = await fetch(root + '/api/progress');
  assert.equal((await r.json()).visited.tomtom, true);
  r = await put({ id: 'tomtom', done: false });
  assert.equal(r.status, 200);
  r = await fetch(root + '/api/progress');
  assert.equal((await r.json()).visited.tomtom, false);
  for (const body of [
    { id: 'unknown', done: true },
    { id: 'base', done: true },
    { id: 'tomtom', done: 'yes' },
    null,
  ]) {
    r = await put(body);
    assert.equal(r.status, 400);
  }
  r = await put(
    { id: 'tomtom', done: true },
    { Origin: 'https://example.org' },
  );
  assert.equal(r.status, 403);
  console.log(
    'Progress: save, read back, undo, invalid input and cross-origin rejection passed.',
  );
} finally {
  await put({ id: 'tomtom', done: original });
}

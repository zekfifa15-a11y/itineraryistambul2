import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import ts from 'typescript';
const tmp = await fs.mkdtemp(path.join(os.tmpdir(), 'istanbul-planner-'));
try {
  for (const name of [
    'trip',
    'university-extra',
    'guide',
    'practical',
    'planner',
  ]) {
    const source = await fs.readFile(
      new URL(`../lib/${name}.ts`, import.meta.url),
      'utf8',
    );
    const js = ts
      .transpile(source, {
        module: ts.ModuleKind.ESNext,
        target: ts.ScriptTarget.ES2022,
      })
      .replace(/(['"])(\.\/[\w-]+)\1/g, "'$2.mjs'");
    await fs.writeFile(path.join(tmp, name + '.mjs'), js);
  }
  const { initialPlans, optimizePlan, emptyEdits, validateCustom } =
    await import(pathToFileURL(path.join(tmp, 'planner.mjs')));
  const { poi, universityPlans, legsFor, googleDirections } = await import(
    pathToFileURL(path.join(tmp, 'guide.mjs'))
  );
  const { infoFor } = await import(
    pathToFileURL(path.join(tmp, 'practical.mjs'))
  );
  assert.equal(initialPlans.length, 14);
  assert.equal(initialPlans[0].date, '2026-10-21');
  assert.equal(initialPlans.at(-1).date, '2026-11-03');
  assert.equal(initialPlans.filter((p) => p.number).length, 10);
  for (const plan of initialPlans) {
    const result = optimizePlan(plan, emptyEdits);
    assert.deepEqual(
      result.skipped,
      [],
      `${plan.date}: saved itinerary must fit opening hours`,
    );
    const legs = legsFor(result);
    for (let i = 1; i < legs.length; i++)
      assert.equal(legs[i - 1].to, legs[i].from);
    for (const stop of result.stops) {
      const info = infoFor(poi[stop.id]);
      assert.ok(
        !info.closed?.includes(new Date(plan.date + 'T12:00:00Z').getUTCDay()),
      );
      if (stop.time !== '—') {
        const [h, m] = stop.time.split(':').map(Number);
        assert.ok(h * 60 + m >= (info.open ?? 0));
        if (info.close) assert.ok(h * 60 + m + info.duration <= info.close);
      }
    }
    console.log(
      plan.date,
      result.stops.map((s) => `${s.time} ${s.id}`).join(' → '),
    );
  }
  assert.ok(universityPlans.length >= 6);
  assert.ok(
    new Set(
      universityPlans
        .flatMap((p) => p.stops.map((s) => s.id))
        .filter((id) => poi[id].kind === 'sight'),
    ).size >= 6,
  );
  const seed = {
    ...initialPlans[0],
    id: 'test',
    date: '2026-10-22',
    stops: [
      { id: 'valens', time: '—' },
      { id: 'camondo', time: '—' },
    ],
  };
  const sorted = optimizePlan(seed, emptyEdits);
  assert.equal(
    sorted.stops[0].id,
    'camondo',
    'nearby stop first, regardless of input order',
  );
  const removed = optimizePlan(seed, { ...emptyEdits, trash: ['camondo'] });
  assert.deepEqual(
    removed.stops.map((s) => s.id),
    ['valens'],
  );
  assert.ok(
    legsFor(removed).every((l) => l.from !== 'camondo' && l.to !== 'camondo'),
  );
  const added = optimizePlan(
    { ...seed, stops: [{ id: 'valens', time: '—' }] },
    { ...emptyEdits, additions: { test: ['camondo', 'camondo'] } },
  );
  assert.deepEqual(
    added.stops.map((s) => s.id),
    ['camondo', 'valens'],
  );
  const sunday = optimizePlan(
    { ...seed, date: '2026-10-25', stops: [{ id: 'tomtom', time: '—' }] },
    emptyEdits,
  );
  assert.deepEqual(sunday.skipped, [{ id: 'tomtom', reason: 'closed' }]);
  const empty = optimizePlan(universityPlans[0], {
    ...emptyEdits,
    trash: [universityPlans[0].stops[0].id],
  });
  assert.equal(legsFor(empty).length, 0);
  const custom = {
    ...poi.camondo,
    id: 'custom-valid-123',
    custom: true,
    kind: 'sight',
    name: 'Custom test',
    lat: 41.028,
    lng: 28.977,
  };
  assert.equal(validateCustom(custom), true);
  assert.equal(validateCustom({ ...custom, lat: 500 }), false);
  assert.equal(validateCustom({ ...custom, kind: 'food', rating: 4.6 }), false);
  assert.equal(
    validateCustom({ ...custom, imageUrl: 'javascript:alert(1)' }),
    false,
  );
  const url = new URL(googleDirections(poi.base, custom, 'driving'));
  assert.equal(url.searchParams.get('travelmode'), 'walking');
  assert.equal(url.searchParams.get('destination'), '41.028,28.977');
  console.log(
    'Planner: dates, hours, nearest order, add/remove, weekly closure, empty routes, six-plus sights and custom validation passed.',
  );
} finally {
  await fs.rm(tmp, { recursive: true, force: true });
}

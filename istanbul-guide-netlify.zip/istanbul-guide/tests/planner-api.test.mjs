import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
const root = 'http://localhost:3000';
const patch = (body, headers = {}) =>
  fetch(root + '/api/planner', {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json', ...headers },
    body: JSON.stringify(body),
  });
const id = 'custom-local-test-20260909';
const place = {
  id,
  custom: true,
  name: 'Test local only',
  address: 'Istanbul',
  area: 'Beyoglu',
  lat: 41.026,
  lng: 28.977,
  kind: 'sight',
  description: {
    pt: 'Teste local apenas',
    en: 'Local test only',
    tr: 'Sadece yerel test',
  },
};
try {
  const init = await fetch(root + '/api/planner');
  assert.equal(init.status, 200);
  assert.equal(
    (await patch({ action: 'create', plan: '2026-10-21', place })).status,
    200,
  );
  let data = await (await fetch(root + '/api/planner')).json();
  assert.ok(data.custom.some((p) => p.id === id));
  assert.ok(data.additions['2026-10-21'].includes(id));
  assert.equal(
    (
      await fetch(root + '/api/progress', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, done: true }),
      })
    ).status,
    200,
  );
  await patch({ action: 'trash', id });
  data = await (await fetch(root + '/api/planner')).json();
  assert.ok(data.trash.includes(id));
  assert.equal(
    (await (await fetch(root + '/api/progress')).json()).visited[id],
    true,
    'Trashing must preserve visits',
  );
  await patch({ action: 'restore', id });
  data = await (await fetch(root + '/api/planner')).json();
  assert.ok(!data.trash.includes(id));
  await patch({ action: 'add', plan: '2026-10-22', id });
  data = await (await fetch(root + '/api/planner')).json();
  assert.ok(data.additions['2026-10-22'].includes(id));
  for (const body of [
    null,
    { action: 'trash', id: 'base' },
    { action: 'add', id: '__proto__', plan: '2026-10-21' },
    { action: 'create', plan: '2026-10-21', place: { ...place, lat: 100 } },
    {
      action: 'create',
      plan: '2026-10-21',
      place: { ...place, kind: 'food', rating: 4.6 },
    },
    { action: 'add', id, plan: '2026-10-20' },
  ])
    assert.equal((await patch(body)).status, 400, JSON.stringify(body));
  assert.equal(
    (await patch({ action: 'trash', id }, { Origin: 'https://example.org' }))
      .status,
    403,
  );
  console.log(
    'Planner API: create, reload, custom check, trash, restore, add, invalid inputs and origin protection passed.',
  );
} finally {
  // Only the four known test keys and one visit are removed from the local test DB.
  const sql = `DELETE FROM trip_edits WHERE key IN ('custom:${id}','trash:${id}','add:2026-10-21:${id}','add:2026-10-22:${id}'); DELETE FROM visits WHERE place_id='${id}';`;
  execFileSync(
    process.execPath,
    [
      'node_modules/wrangler/bin/wrangler.js',
      'd1',
      'execute',
      'DB',
      '--local',
      '--config',
      'work/local-wrangler.json',
      '--persist-to',
      '.wrangler/state',
      '--command',
      sql,
    ],
    { stdio: 'pipe' },
  );
}

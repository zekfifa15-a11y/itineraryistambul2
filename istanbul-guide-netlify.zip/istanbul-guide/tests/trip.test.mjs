import assert from 'node:assert/strict';
import {
  places,
  byId,
  days,
  universityPlans,
  mapsUrl,
  distance,
  universityOrigin,
} from '../lib/trip.ts';
assert.equal(new Set(places.map((p) => p.id)).size, places.length);
assert.equal(days.length, 15);
assert.equal(days.filter((d) => d.number).length, 10);
for (const d of days)
  for (const s of d.stops) assert.ok(byId[s.id], `Unknown stop ${s.id}`);
for (const p of places) {
  for (const lang of ['pt', 'en', 'tr'])
    assert.ok(p.description[lang].length > 20);
  if (!p.unmapped) {
    assert.ok(p.lat > 40 && p.lat < 42);
    assert.ok(p.lng > 28 && p.lng < 30);
  }
}
for (const plan of universityPlans) {
  assert.equal(plan.walk + plan.visit + plan.buffer, 80);
  assert.ok(plan.buffer >= 20);
  assert.ok(plan.ids.every((id) => byId[id]));
  const u = new URL(
    mapsUrl(
      byId.university,
      'walking',
      universityOrigin,
      plan.ids.map((id) => byId[id]),
    ),
  );
  assert.equal(u.searchParams.get('origin'), universityOrigin);
  assert.match(u.searchParams.get('destination'), /Edebiyat/);
  assert.equal(
    u.searchParams.get('waypoints').split('|').length,
    plan.ids.length,
  );
}
const local = places.filter(
  (p) =>
    p.kind === 'food' &&
    (p.rating ?? 0) > 4.4 &&
    !p.unmapped &&
    distance(byId.base, p) <= 2,
);
assert.ok(local.some((p) => p.id === 'tomtom'));
assert.ok(local.some((p) => p.id === 'pera-antakya'));
assert.ok(
  !local.some(
    (p) => p.id === 'yesim' || p.id === 'cortile' || p.id === 'patata',
  ),
);
const current = new URL(mapsUrl(byId.tomtom));
assert.equal(current.searchParams.get('origin'), null);
assert.match(current.searchParams.get('destination'), /39 A/);
assert.equal(
  new URL(mapsUrl(byId.moda, 'transit')).searchParams.get('travelmode'),
  'transit',
);
assert.ok(days[9].stops.some((s) => s.id === 'pera-antakya'));
assert.ok(days[9].stops.some((s) => s.id === 'tomtom'));
assert.ok(days[10].stops.some((s) => s.id === 'cruise'));
assert.ok(!days[10].stops.some((s) => s.id === 'eminonu'));
assert.ok(byId.cruise.unmapped);
const forbidden = {
  topkapi: 2,
  dolma: 1,
  modern: 1,
  grand: 0,
  kitchen: 0,
  helvetia: 0,
  'pera-pizza': 0,
  tomtom: 0,
};
for (const d of days)
  for (const s of d.stops)
    if (s.id in forbidden)
      assert.notEqual(
        new Date(d.date + 'T12:00:00Z').getUTCDay(),
        forbidden[s.id],
        `${s.id} scheduled on a closed day`,
      );
console.log(
  `${places.length} places, 15 dates, 10 main days, ${universityPlans.length} university loops and Google Maps links validated.`,
);

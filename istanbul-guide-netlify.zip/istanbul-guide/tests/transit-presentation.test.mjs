import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import ts from 'typescript';
const source = await fs.readFile(
  new URL('../lib/google-route-presentation.ts', import.meta.url),
  'utf8',
);
const code = ts.transpile(source, {
  module: ts.ModuleKind.ESNext,
  target: ts.ScriptTarget.ES2022,
});
const { groupRouteSteps, transitStops, stepMode } = await import(
  'data:text/javascript;base64,' + Buffer.from(code).toString('base64')
);
const walk = (m) => ({ travelMode: 'WALKING', distanceMeters: m });
const tram = {
  travelMode: 'TRANSIT',
  transitDetails: {
    departureStop: {
      name: 'Beyoğlu (Tünel)',
      location: { lat: 41.028, lng: 28.975 },
    },
    arrivalStop: { name: 'Odakule', location: { lat: 41.032, lng: 28.977 } },
    transitLine: { shortName: 'T2', color: '#8BA59E' },
  },
};
const bus = {
  travelMode: 'TRANSIT',
  startLocation: { lat: 41.033, lng: 28.978 },
  endLocation: { lat: 41.04, lng: 28.98 },
};
const steps = [walk(100), walk(250), tram, walk(98), bus, walk(20)];
const groups = groupRouteSteps(steps);
assert.deepEqual(
  groups.map((g) => g.mode),
  ['walking', 'transit', 'walking', 'transit', 'walking'],
);
assert.deepEqual(
  groups.map((g) => g.index),
  [0, 2, 3, 4, 5],
);
assert.equal(
  groups[0].steps.reduce((sum, s) => sum + s.distanceMeters, 0),
  350,
);
assert.equal(
  stepMode({ transitDetails: {} }),
  'transit',
  'Missing travelMode must not turn a transit ride into walking',
);
assert.equal(
  stepMode({}),
  'unknown',
  'An unspecified mode must not be invented',
);
const stops = transitStops({ legs: [{ steps }, { steps: [tram] }] });
assert.deepEqual(
  stops.flatMap((s) => [s.board.label, s.alight.label]),
  ['A', 'B', 'C', 'D', 'E', 'F'],
);
assert.deepEqual(
  stops.map((s) => [s.legIndex, s.stepIndex]),
  [
    [0, 2],
    [0, 4],
    [1, 0],
  ],
);
assert.deepEqual(
  stops[0].board.position,
  tram.transitDetails.departureStop.location,
);
assert.deepEqual(stops[1].alight.position, bus.endLocation);
assert.equal(
  transitStops({ legs: [{ steps: [{ travelMode: 'TRANSIT' }] }] })[0].board
    .position,
  undefined,
);
assert.deepEqual(transitStops({ legs: [{ steps: [walk(100)] }] }), []);
console.log(
  'Transit presentation: grouped walks, transfers, ordered boarding/exit labels, station coordinates and missing-data handling passed.',
);

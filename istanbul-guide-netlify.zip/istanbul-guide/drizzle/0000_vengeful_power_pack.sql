CREATE TABLE `visits` (
	`place_id` text PRIMARY KEY NOT NULL,
	`done` integer DEFAULT 0 NOT NULL,
	`updated_at` text NOT NULL
);

import { createRoot } from 'react-dom/client';
import JourneyApp from '../../components/journey-app';
import './fonts.css';
import '../../app/globals.css';

createRoot(document.getElementById('root')!).render(<JourneyApp />);

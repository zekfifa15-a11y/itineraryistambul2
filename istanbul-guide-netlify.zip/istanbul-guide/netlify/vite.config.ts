import { fileURLToPath } from 'node:url';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/postcss';

const path = (relative: string) =>
  fileURLToPath(new URL(relative, import.meta.url));

// Reuse the complete guide and the same image component without the Worker runtime.
export default defineConfig({
  root: path('./web/'),
  publicDir: path('../public/'),
  plugins: [react()],
  resolve: {
    alias: {
      '@': path('../'),
      'next/image': 'vinext/shims/image',
    },
  },
  define: {
    'process.env.__VINEXT_IMAGE_REMOTE_PATTERNS': JSON.stringify('[]'),
    'process.env.__VINEXT_IMAGE_DOMAINS': JSON.stringify('[]'),
    'process.env.__VINEXT_IMAGE_DEVICE_SIZES': JSON.stringify(
      '[640,750,828,1080,1200,1920,2048,3840]',
    ),
    'process.env.__VINEXT_IMAGE_SIZES': JSON.stringify(
      '[32,48,64,96,128,256,384]',
    ),
    'process.env.__VINEXT_IMAGE_DANGEROUSLY_ALLOW_SVG': JSON.stringify('false'),
    'process.env.__VINEXT_IMAGE_DANGEROUSLY_ALLOW_LOCAL_IP':
      JSON.stringify('false'),
    'process.env.__VINEXT_IMAGE_UNOPTIMIZED': JSON.stringify('true'),
    'process.env.__VINEXT_DEPLOYMENT_ID': 'undefined',
    'process.env.NEXT_DEPLOYMENT_ID': 'undefined',
  },
  css: { postcss: { plugins: [tailwindcss()] } },
  build: { outDir: path('../dist-netlify/'), emptyOutDir: true },
  server: { fs: { allow: [path('../')] } },
});

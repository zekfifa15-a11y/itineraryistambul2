import type { Edits } from '../../lib/planner';

export type TripState = {
  version: 1;
  visited: Record<string, boolean>;
  edits: Edits;
};
export type StateStore = {
  getWithMetadata: (
    key: string,
    options: { type: 'json' },
  ) => Promise<{ data: TripState; etag: string } | null>;
  setJSON: (
    key: string,
    value: TripState,
    options: { onlyIfMatch: string } | { onlyIfNew: true },
  ) => Promise<{ modified: boolean }>;
};
export class InvalidMutation extends Error {}

const stateKey = 'state-v1';
export function createRepository(store: StateStore, initial: TripState) {
  return {
    async read() {
      const entry = await store.getWithMetadata(stateKey, { type: 'json' });
      if (entry) return entry.data;
      const first = structuredClone(initial);
      if ((await store.setJSON(stateKey, first, { onlyIfNew: true })).modified)
        return first;
      const winner = await store.getWithMetadata(stateKey, { type: 'json' });
      if (!winner) throw new Error('Could not initialize trip state');
      return winner.data;
    },
    async update(mutate: (state: TripState) => void) {
      for (let attempt = 0; attempt < 8; attempt++) {
        const entry = await store.getWithMetadata(stateKey, { type: 'json' });
        const next = structuredClone(entry ? entry.data : initial);
        // Reapply this small mutation to the newest state after any concurrent write.
        mutate(next);
        const saved = await store.setJSON(
          stateKey,
          next,
          entry ? { onlyIfMatch: entry.etag } : { onlyIfNew: true },
        );
        if (saved.modified) return next;
      }
      throw new Error('Concurrent edits; please retry');
    },
  };
}
export type Repository = ReturnType<typeof createRepository>;

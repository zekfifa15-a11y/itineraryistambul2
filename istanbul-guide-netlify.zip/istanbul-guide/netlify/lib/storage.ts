import { getStore } from '@netlify/blobs';
import seed from '../data/initial-state.json';
import { createRepository, type StateStore, type TripState } from './state';
import { withLocalLock } from './local-lock';

export function repository() {
  const store = getStore({ name: 'istanbul-a-dois', consistency: 'strong' });
  const repo = createRepository(store as StateStore, seed as TripState);
  const localLock = process.env.ISTANBUL_LOCAL_STORAGE_LOCK_DIR;
  if (!localLock) return repo;
  return {
    read: () => withLocalLock(localLock, () => repo.read()),
    update: (mutate: Parameters<typeof repo.update>[0]) =>
      withLocalLock(localLock, () => repo.update(mutate)),
  };
}

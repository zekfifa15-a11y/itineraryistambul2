import { mkdir, open, unlink } from 'node:fs/promises';
import { join } from 'node:path';
import { setTimeout } from 'node:timers/promises';

// Netlify's local Blobs simulator checks ETags before an asynchronous file write.
// Serialize local operations across function workers; production uses atomic CAS.
export async function withLocalLock<T>(
  directory: string,
  run: () => Promise<T>,
): Promise<T> {
  await mkdir(directory, { recursive: true });
  const path = join(directory, 'trip-state.lock');
  const deadline = Date.now() + 15000;
  while (Date.now() < deadline) {
    let handle;
    try {
      handle = await open(path, 'wx');
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'EEXIST') throw error;
      await setTimeout(40);
      continue;
    }
    try {
      return await run();
    } finally {
      await handle.close();
      await unlink(path);
    }
  }
  throw new Error(
    'Local storage is busy. Restart Netlify Dev if a previous process stopped during a save.',
  );
}

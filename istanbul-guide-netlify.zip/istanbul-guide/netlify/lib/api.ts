import { poi, universityPlans } from '../../lib/guide';
import { initialPlans, validateCustom } from '../../lib/planner';
import { InvalidMutation, type Repository, type TripState } from './state';

const reply = (value: unknown, status = 200, headers = {}) =>
  Response.json(value, {
    status,
    headers: { 'Cache-Control': 'no-store', ...headers },
  });
const validOrigin = (request: Request) =>
  !request.headers.get('origin') ||
  request.headers.get('origin') === new URL(request.url).origin;
async function input(request: Request) {
  const raw = await request.text();
  if (raw.length > 20_000) throw new InvalidMutation('Input too large');
  const value = JSON.parse(raw);
  if (!value || typeof value !== 'object' || Array.isArray(value))
    throw new InvalidMutation('Invalid input');
  return value as Record<string, unknown>;
}
const lookupFor = (state: TripState) => ({
  ...poi,
  ...Object.fromEntries(state.edits.custom.map((p) => [p.id, p])),
});
const placeExists = (state: TripState, id: unknown): id is string => {
  const lookup = lookupFor(state);
  return (
    typeof id === 'string' &&
    Object.hasOwn(lookup, id) &&
    lookup[id].kind !== 'base'
  );
};
const fail = (error: unknown) =>
  reply(
    {
      error:
        error instanceof InvalidMutation || error instanceof SyntaxError
          ? 'Invalid input or place'
          : 'Could not save changes',
    },
    error instanceof InvalidMutation || error instanceof SyntaxError
      ? 400
      : 503,
  );

export async function progress(request: Request, repo: Repository) {
  try {
    if (request.method === 'GET')
      return reply({ visited: (await repo.read()).visited });
    if (request.method !== 'PUT')
      return reply({ error: 'Method not allowed' }, 405, { Allow: 'GET, PUT' });
    if (!validOrigin(request)) return reply({ error: 'Invalid origin' }, 403);
    const { id, done } = await input(request);
    await repo.update((state) => {
      if (typeof done !== 'boolean' || !placeExists(state, id))
        throw new InvalidMutation('Invalid place or status');
      state.visited[id] = done;
    });
    return reply({ id, done });
  } catch (error) {
    return fail(error);
  }
}

export async function planner(request: Request, repo: Repository) {
  try {
    if (request.method === 'GET') return reply((await repo.read()).edits);
    if (request.method !== 'PATCH')
      return reply({ error: 'Method not allowed' }, 405, {
        Allow: 'GET, PATCH',
      });
    if (!validOrigin(request)) return reply({ error: 'Invalid origin' }, 403);
    const { action, id, plan, place } = await input(request);
    const updated = await repo.update((state) => {
      const validPlan =
        typeof plan === 'string' &&
        [...initialPlans, ...universityPlans].some((p) => p.id === plan);
      const { edits } = state;
      if (
        (action === 'trash' || action === 'restore') &&
        placeExists(state, id)
      ) {
        edits.trash = edits.trash.filter((value) => value !== id);
        if (action === 'trash') edits.trash.push(id);
      } else if (action === 'add' && placeExists(state, id) && validPlan) {
        edits.additions[plan] = [
          ...new Set([...(edits.additions[plan] || []), id]),
        ];
        edits.trash = edits.trash.filter((value) => value !== id);
      } else if (action === 'create' && validPlan && validateCustom(place)) {
        const existing = edits.custom.findIndex(
          (value) => value.id === place.id,
        );
        if (existing < 0) edits.custom.push(place);
        else edits.custom[existing] = place;
        edits.additions[plan] = [
          ...new Set([...(edits.additions[plan] || []), place.id]),
        ];
      } else throw new InvalidMutation('Invalid action or place');
    });
    return reply(updated.edits);
  } catch (error) {
    return fail(error);
  }
}

export default async function handler(request: Request) {
  if (request.method !== 'GET')
    return Response.json(
      { error: 'Method not allowed' },
      { status: 405, headers: { Allow: 'GET' } },
    );
  return Response.json(
    {
      googleEmbedKey:
        process.env.GOOGLE_MAPS_BROWSER_KEY ||
        process.env.GOOGLE_MAPS_EMBED_KEY ||
        null,
    },
    { headers: { 'Cache-Control': 'no-store' } },
  );
}

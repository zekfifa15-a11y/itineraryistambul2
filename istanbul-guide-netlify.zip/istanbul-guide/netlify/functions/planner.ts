import { planner } from '../lib/api';
import { repository } from '../lib/storage';
export default async function handler(request: Request) {
  try {
    return await planner(request, repository());
  } catch {
    return Response.json(
      { error: 'Planner unavailable' },
      { status: 503, headers: { 'Cache-Control': 'no-store' } },
    );
  }
}

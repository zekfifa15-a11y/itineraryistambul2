import { progress } from '../lib/api';
import { repository } from '../lib/storage';
export default async function handler(request: Request) {
  try {
    return await progress(request, repository());
  } catch {
    return Response.json(
      { error: 'Progress temporarily unavailable' },
      { status: 503, headers: { 'Cache-Control': 'no-store' } },
    );
  }
}

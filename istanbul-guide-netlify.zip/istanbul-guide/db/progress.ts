import { env } from 'cloudflare:workers';
type Binding = {
  prepare: (sql: string) => {
    bind: (...values: unknown[]) => {
      run: () => Promise<unknown>;
      first: () => Promise<unknown>;
    };
    all: <T>() => Promise<{ results: T[] }>;
  };
};
function db() {
  const binding = (env as unknown as { DB?: Binding }).DB;
  if (!binding) throw new Error('Database unavailable');
  return binding;
}
export async function readProgress() {
  const { results } = await db()
    .prepare('SELECT place_id, done FROM visits')
    .all<{ place_id: string; done: number }>();
  return Object.fromEntries(results.map((r) => [r.place_id, !!r.done]));
}
export async function writeProgress(id: string, done: boolean) {
  await db()
    .prepare(
      'INSERT INTO visits (place_id, done, updated_at) VALUES (?, ?, ?) ON CONFLICT(place_id) DO UPDATE SET done = excluded.done, updated_at = excluded.updated_at',
    )
    .bind(id, done ? 1 : 0, new Date().toISOString())
    .run();
}
export async function customPlaceExists(id: string) {
  return !!(await db()
    .prepare('SELECT key FROM trip_edits WHERE key = ?')
    .bind('custom:' + id)
    .first());
}

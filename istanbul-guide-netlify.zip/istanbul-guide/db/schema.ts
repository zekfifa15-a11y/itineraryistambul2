// Add Drizzle tables here when the site needs a database.
import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
export const visits = sqliteTable('visits', {
  placeId: text('place_id').primaryKey(),
  done: integer('done').notNull().default(0),
  updatedAt: text('updated_at').notNull(),
});
export const tripEdits=sqliteTable('trip_edits',{key:text('key').primaryKey(),value:text('value').notNull(),updatedAt:text('updated_at').notNull()});

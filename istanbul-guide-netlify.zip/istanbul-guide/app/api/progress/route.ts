import { readProgress, writeProgress, customPlaceExists } from '@/db/progress';
import { poi as byId } from '@/lib/guide';
export async function GET() {
  try {
    return Response.json(
      { visited: await readProgress() },
      { headers: { 'Cache-Control': 'no-store' } },
    );
  } catch {
    return Response.json(
      { error: 'Progress temporarily unavailable' },
      { status: 503 },
    );
  }
}
export async function PUT(req: Request) {
  const origin = req.headers.get('origin');
  if (origin && origin !== new URL(req.url).origin)
    return Response.json({ error: 'Invalid origin' }, { status: 403 });
  let value: unknown;
  try {
    value = await req.json();
  } catch {
    return Response.json({ error: 'Invalid JSON' }, { status: 400 });
  }
  if (!value || typeof value !== 'object')
    return Response.json({ error: 'Invalid input' }, { status: 400 });
  const { id, done } = value as { id: unknown; done: unknown };
  if (
    typeof id !== 'string' ||
    typeof done !== 'boolean' ||
    (Object.hasOwn(byId, id) && byId[id].kind === 'base')
  )
    return Response.json({ error: 'Invalid place or status' }, { status: 400 });
  try {
    if (
      !Object.hasOwn(byId, id) &&
      (!/^custom-[a-z0-9-]{8,64}$/.test(id) || !(await customPlaceExists(id)))
    )
      return Response.json({ error: 'Invalid place' }, { status: 400 });
    await writeProgress(id, done);
    return Response.json({ id, done });
  } catch {
    return Response.json({ error: 'Could not save progress' }, { status: 503 });
  }
}

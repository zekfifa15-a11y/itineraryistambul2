import { env } from 'cloudflare:workers';
export async function GET() {
  const config = env as unknown as {
    GOOGLE_MAPS_BROWSER_KEY?: string;
    GOOGLE_MAPS_EMBED_KEY?: string;
  };
  // A Maps browser key goes to Google; restrict its referrers in Google Cloud.
  const key = config.GOOGLE_MAPS_BROWSER_KEY || config.GOOGLE_MAPS_EMBED_KEY;
  return Response.json(
    { googleEmbedKey: key || null },
    { headers: { 'Cache-Control': 'no-store' } },
  );
}

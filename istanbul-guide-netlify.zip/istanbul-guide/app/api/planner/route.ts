import { env } from 'cloudflare:workers';
import { poi, universityPlans } from '@/lib/guide';
import {
  initialPlans,
  validateCustom,
  type Edits,
  type CustomPlace,
} from '@/lib/planner';
const db = () => (env as unknown as { DB: D1Database }).DB;
async function read() {
  const { results } = await db()
    .prepare('SELECT key,value FROM trip_edits')
    .all<{ key: string; value: string }>();
  const edits: Edits = { trash: [], additions: {}, custom: [] };
  for (const r of results) {
    const v = JSON.parse(r.value);
    if (r.key.startsWith('custom:')) edits.custom.push(v as CustomPlace);
    if (r.key.startsWith('trash:') && v) edits.trash.push(r.key.slice(6));
    if (r.key.startsWith('add:') && v) {
      const [, plan, id] = r.key.split(':');
      (edits.additions[plan] ??= []).push(id);
    }
  }
  return edits;
}
export async function GET() {
  try {
    return Response.json(await read(), {
      headers: { 'Cache-Control': 'no-store' },
    });
  } catch {
    return Response.json({ error: 'Planner unavailable' }, { status: 503 });
  }
}
export async function PATCH(req: Request) {
  if (
    req.headers.get('origin') &&
    req.headers.get('origin') !== new URL(req.url).origin
  )
    return Response.json({ error: 'Invalid origin' }, { status: 403 });
  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ error: 'Invalid input' }, { status: 400 });
  }
  if (!body || typeof body !== 'object')
    return Response.json({ error: 'Invalid input' }, { status: 400 });
  try {
    const edits = await read();
    const lookup = {
      ...poi,
      ...Object.fromEntries(edits.custom.map((p) => [p.id, p])),
    };
    const { action, id, plan, place } = body;
    const validId =
      typeof id === 'string' &&
      Object.hasOwn(lookup, id) &&
      lookup[id].kind !== 'base';
    const validPlan =
      typeof plan === 'string' &&
      [...initialPlans, ...universityPlans].some((p) => p.id === plan);
    const statements: D1PreparedStatement[] = [];
    const put = (key: string, value: unknown) =>
      statements.push(
        db()
          .prepare(
            'INSERT INTO trip_edits (key,value,updated_at) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at',
          )
          .bind(key, JSON.stringify(value), new Date().toISOString()),
      );
    if ((action === 'trash' || action === 'restore') && validId)
      put('trash:' + id, action === 'trash');
    else if (action === 'add' && validId && validPlan) {
      put(`add:${plan}:${id}`, true);
      put('trash:' + id, false);
    } else if (action === 'create' && validPlan && validateCustom(place)) {
      put('custom:' + place.id, place);
      put(`add:${plan}:${place.id}`, true);
    } else
      return Response.json(
        { error: 'Invalid action or place' },
        { status: 400 },
      );
    await db().batch(statements);
    return Response.json(await read(), {
      headers: { 'Cache-Control': 'no-store' },
    });
  } catch {
    return Response.json({ error: 'Could not save changes' }, { status: 503 });
  }
}

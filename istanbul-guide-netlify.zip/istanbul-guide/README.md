# İstanbul · A dois

Guia de viagem de Samuel e Zeynep, com roteiro, Google Maps, transporte público, calendário e checklist em português, inglês e turco.

**Para publicar no Netlify, siga [NETLIFY.md](NETLIFY.md).** O projeto inclui o site e as Functions que salvam o roteiro e as visitas. Importe esta pasta inteira; não envie somente os arquivos visuais pelo Netlify Drop.

- Prévia Netlify: `pnpm run dev:netlify` → `http://localhost:8888/`.
- Build Netlify: `pnpm run build:netlify`.
- A chave Google é fornecida pela variável `GOOGLE_MAPS_BROWSER_KEY` no servidor.
- Caminhadas aparecem tracejadas em verde; transporte público aparece em roxo contínuo. Letras identificam embarque e desembarque, e números identificam os locais do roteiro.

Santa Maria Draperis está incluída em 29/10. As informações de visita remetem à [paróquia](https://www.istanbulofm.org/p/schedule.html); confirme o acesso antes de ir.

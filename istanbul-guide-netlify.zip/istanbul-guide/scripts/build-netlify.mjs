import { build } from 'vite';
import { fileURLToPath } from 'node:url';
import { buildFunctions } from './netlify-functions.mjs';

await buildFunctions();
await build({
  configFile: fileURLToPath(
    new URL('../netlify/vite.config.ts', import.meta.url),
  ),
});

import { build } from 'vite';
import { fileURLToPath } from 'node:url';

export async function buildFunctions() {
  const root = fileURLToPath(new URL('../', import.meta.url));
  // Standalone bundles work on Windows and on Netlify without dependency symlinks.
  for (const name of ['progress', 'planner', 'maps-config']) {
    await build({
      configFile: false,
      root,
      publicDir: false,
      ssr: { noExternal: true },
      build: {
        ssr: `netlify/functions/${name}.ts`,
        target: 'node24',
        outDir: 'netlify/generated-functions',
        emptyOutDir: false,
        minify: false,
        rolldownOptions: {
          output: { format: 'esm', entryFileNames: `${name}.mjs` },
        },
      },
    });
  }
}

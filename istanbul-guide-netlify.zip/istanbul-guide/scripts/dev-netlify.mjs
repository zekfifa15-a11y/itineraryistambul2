import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { buildFunctions } from './netlify-functions.mjs';

await buildFunctions();
const child = spawn(
  process.execPath,
  [
    fileURLToPath(
      new URL('../node_modules/netlify-cli/bin/run.js', import.meta.url),
    ),
    'dev',
    '--offline',
  ],
  {
    cwd: fileURLToPath(new URL('../', import.meta.url)),
    stdio: 'inherit',
    windowsHide: true,
    env: {
      ...process.env,
      NODE_ENV: 'development',
      ISTANBUL_LOCAL_STORAGE_LOCK_DIR: fileURLToPath(
        new URL(`../.netlify/locks/session-${process.pid}/`, import.meta.url),
      ),
    },
  },
);
child.on('error', (error) => {
  console.error(error.message);
  process.exitCode = 1;
});
child.on('exit', (code) => {
  process.exitCode = code ?? 1;
});

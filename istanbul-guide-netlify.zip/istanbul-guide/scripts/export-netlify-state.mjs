import { mkdir, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

const source = new URL(process.argv[2] || 'http://localhost:3000/');
if (!['http:', 'https:'].includes(source.protocol))
  throw new Error('Use the URL of the current guide.');
const responses = await Promise.all(
  ['progress', 'planner'].map(async (route) => {
    const response = await fetch(new URL(`/api/${route}`, source), {
      signal: AbortSignal.timeout(30000),
    });
    if (!response.ok)
      throw new Error(`Could not export ${route}: HTTP ${response.status}`);
    return response.json();
  }),
);
const [{ visited }, edits] = responses;
if (
  !visited ||
  typeof visited !== 'object' ||
  Array.isArray(visited) ||
  !Object.values(visited).every((v) => typeof v === 'boolean') ||
  !Array.isArray(edits.custom) ||
  !Array.isArray(edits.trash) ||
  !edits.additions ||
  typeof edits.additions !== 'object'
)
  throw new Error(
    'The guide returned an invalid snapshot. Nothing was replaced.',
  );
const target = new URL('../netlify/data/initial-state.json', import.meta.url);
await mkdir(new URL('./', target), { recursive: true });
await writeFile(
  target,
  JSON.stringify({ version: 1, visited, edits }, null, 2) + '\n',
);
console.log(
  `Saved ${Object.values(visited).filter(Boolean).length} visits and ${edits.custom.length} custom places to ${fileURLToPath(target)}. Existing Netlify data is never overwritten by this seed.`,
);

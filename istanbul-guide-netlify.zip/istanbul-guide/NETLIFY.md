# Publicar İstanbul · A dois no Netlify

Esta versão usa os mesmos componentes, estilos, fontes e fotos do guia. Mapa do Google, idiomas, calendário, rotas, GPS, checklist, lixeira e inclusão de lugares continuam disponíveis. O Netlify Blobs guarda os dados do casal no servidor, inclusive após novas publicações.

## Caminho mais simples: importar um repositório

1. Coloque **todo o conteúdo desta pasta** em um repositório Git privado. A pasta escolhida deve conter `package.json` e `netlify.toml`.
2. No Netlify, use **Add new project → Import an existing project** e selecione esse repositório.
3. O arquivo `netlify.toml` configura automaticamente o comando `pnpm run build:netlify`, a pasta `dist-netlify` e as três Functions. Use Node 24.
4. Em **Project configuration → Environment variables**, adicione `GOOGLE_MAPS_BROWSER_KEY` com a chave de API Google já usada no guia. Disponibilize a variável às **Functions** (ou a todos os escopos). Não use a chave secreta de assinatura de URL.
5. Publique o projeto. Nas restrições de sites da chave no Google Cloud, permita `https://SEU-PROJETO.netlify.app/*` e qualquer domínio próprio que usar. Maps JavaScript API e Routes API precisam continuar habilitadas.
6. Abra o endereço HTTPS do Netlify. No celular, permita localização e orientação quando iniciar o acompanhamento.

O guia tem um roteiro e checklist compartilhados por quem o acessa. Para mantê-lo pessoal, ative a proteção de acesso disponível no seu projeto Netlify antes de compartilhar o endereço. Não há uma nova tela de login dentro do guia.

**Não envie apenas `dist-netlify` pelo Netlify Drop.** A publicação precisa incluir as Functions; só arrastar a pasta visual não mantém o salvamento dos dados. Use a importação Git acima ou a CLI abaixo.

## Publicar pelo computador, sem Git

Com Node 24 e pnpm 11.19 instalados, abra um terminal na pasta do projeto:

```sh
pnpm install --frozen-lockfile
pnpm exec netlify login
pnpm exec netlify sites:create
```

Escolha o nome do projeto e vincule a pasta quando a CLI oferecer essa opção. Se o projeto já existir no Netlify, substitua `sites:create` por `pnpm exec netlify link` e selecione-o. Adicione a variável `GOOGLE_MAPS_BROWSER_KEY` no painel do projeto, como explicado acima. Depois:

```sh
pnpm run deploy:netlify
```

Esse comando compila e publica os arquivos visuais e as Functions juntos. Não é preciso criar um banco manualmente: o Netlify fornece as credenciais do Blobs às Functions.

## Dados já preservados

`netlify/data/initial-state.json` contém o snapshot exportado do guia local em 10/09/2026, incluindo os quatro lugares visitados. Esse conteúdo inicial é usado **uma única vez**, quando o armazenamento do Netlify está vazio. Novas publicações não substituem o checklist nem as edições já salvas no Netlify.

Se quiser atualizar a cópia inicial antes da primeira publicação, com o guia original aberto em `http://localhost:3000/`:

```sh
pnpm run export:netlify
```

O roteiro publicado anteriormente no Sites é independente. A exportação usa a versão local atual e não tenta acessar dados de uma hospedagem indisponível. Preferências locais do navegador, como idioma, são específicas de cada endereço. A chave é configurada somente no servidor e atende todos os dispositivos; não há configuração de chave na interface do guia.

## Verificação e desenvolvimento

```sh
pnpm run test:netlify
pnpm run build:netlify
pnpm run dev:netlify
```

O Netlify Dev abre `http://localhost:8888/` e usa um armazenamento local separado da produção. Para o mapa local, coloque `GOOGLE_MAPS_BROWSER_KEY` em um arquivo `.env`, que fica fora do Git. Os scripts já compilam as Functions junto com suas dependências, permitindo o uso no Windows sem criar links simbólicos de pacotes. Ao editar o código do servidor, reinicie o comando de desenvolvimento para recompilá-lo.

O caminho original do Sites foi preservado: `pnpm run dev` e `pnpm run build` continuam usando Vinext/Cloudflare. O adaptador Netlify está isolado em `netlify/`, sem alterar os componentes do guia.

## Referências oficiais

- [Vite no Netlify](https://docs.netlify.com/build/frameworks/framework-setup-guides/vite/)
- [Netlify Functions](https://docs.netlify.com/build/functions/get-started/)
- [Netlify Blobs e persistência entre publicações](https://docs.netlify.com/build/data-and-storage/netlify-blobs/)
- [Publicação pela CLI](https://cli.netlify.com/commands/deploy/)
- [Fonte Geist e licença OFL](https://github.com/google/fonts/tree/main/ofl/geist)
